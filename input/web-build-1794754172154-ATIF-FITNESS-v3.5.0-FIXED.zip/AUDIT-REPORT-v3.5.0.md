# AUDIT REPORT — ATIF FITNESS v3.5.0

**GIFs included: 35 / 35**

**Base:** Uploaded `ATIF-FITNESS-v3.5.0-source-updated_6_mpfe.zip` (392K, versionCode 19) — continued, not restarted. The GIF player code in that ZIP was verified in code before any GIF was added.
**Application ID:** `com.atif.fitness` (unchanged)
**Version:** `versionCode = 19`, `versionName = "3.5.0"`
**Backup JSON version:** `3.5.0` (grep `"3.0.2"` = 0 in Kotlin; the one "3.0.2" text match is a food calorie value, not a version)
**PPL x2 plan:** preserved. **Gradle wrapper:** 8.9 (AGP 8.7 minimum). **INTERNET permission:** removed (GIFs are packaged assets).
**GIF folder:** `app/src/main/assets/exercise_gifs/` — total 3.4 MB, 35 files, 0 missing, 0 extra.

## Player verification (done in code, before downloading GIFs)

- Coil Compose 2.7.0 + Coil GIF 2.7.0 dependencies in `app/build.gradle.kts`.
- `ExerciseGifDemo` in `MainActivity.kt`: `ImageLoader` with `GifDecoder.Factory()`, `AsyncImage` from `file:///android_asset/exercise_gifs/<gifFileName>`, 16:9, autoplay loop, Play/Pause button, drawable stopped on leaving the screen (`DisposableEffect`).
- `gifFileName` is set for all 35 exercises by `exerciseGifFileName()` (lowercase, non-alphanumerics to underscores).
- No code loads `m.youtube.com/results` or any WebView (grep count 0). Missing GIF falls back to the stick-figure `AnimationCard` + text "GIF not available for this exercise yet".
- Braces/parens balanced (string literals/comments stripped): MainActivity.kt 911/911 braces, 2567/2567 parens; Language.kt 7/7, 431/431; TtsPlaybackService.kt 47/47, 118/118. Kotlin files are byte-identical to the uploaded base ZIP (diff = 0 lines) — no code was changed in this run except the reports below.
- Translation, TTS, voice-guided workout, streak, CSV, favourites, tools, modes, graphs, backup/restore all retained. Old backups still restore (restore parser has no version rejection).

## GIF asset inventory — all verified on disk

Every file below was checked independently after download: `file` says "GIF image data, version 89a", size > 0, `ffprobe` shows 180x180 and the frame count listed. All GIFs are ExerciseDB V1 180p animations from `https://static.exercisedb.dev/media/<id>.gif`.

| Exercise | GIF file name | ExerciseDB name used | gifUrl | Size KB | Frames | Included? |
|---|---|---|---|---|---:|---:|
| Barbell Bench Press | `barbell_bench_press.gif` | barbell bench press | `https://static.exercisedb.dev/media/EIeI8Vf.gif` | 121.5 | 12 | Yes |
| Incline Dumbbell Press | `incline_dumbbell_press.gif` | Dumbbell Incline Bench Press | `https://static.exercisedb.dev/media/B3Rxp6L.gif` | 87.4 | 12 | Yes |
| Cable Chest Fly | `cable_chest_fly.gif` | Cable Crossover | `https://static.exercisedb.dev/media/0CXGHya.gif` | 66.3 | 12 | Yes |
| Rope Triceps Pushdown | `rope_triceps_pushdown.gif` | cable pushdown (with rope attachment) | `https://static.exercisedb.dev/media/dU605di.gif` | 82.3 | 12 | Yes |
| Overhead Cable Extension | `overhead_cable_extension.gif` | cable overhead triceps extension (rope attachment) | `https://static.exercisedb.dev/media/2IxROQ1.gif` | 59.8 | 12 | Yes |
| Lat Pulldown | `lat_pulldown.gif` | cable lat pulldown full range of motion | `https://static.exercisedb.dev/media/LEprlgG.gif` | 125.7 | 12 | Yes |
| Chest Supported Row | `chest_supported_row.gif` | dumbbell incline row | `https://static.exercisedb.dev/media/7vG5o25.gif` | 107.1 | 12 | Yes |
| Single Arm Cable Row | `single_arm_cable_row.gif` | Cable Seated Single-Arm Alternate Row | `https://static.exercisedb.dev/media/vpp9Ku2.gif` | 65.6 | 12 | Yes |
| Reverse Pec Deck | `reverse_pec_deck.gif` | Machine Seated Reverse Fly | `https://static.exercisedb.dev/media/myfUsKf.gif` | 134.3 | 12 | Yes |
| EZ Bar Curl | `ez_bar_curl.gif` | EZ-Bar Curl | `https://static.exercisedb.dev/media/6TG6x2w.gif` | 73.8 | 12 | Yes |
| Incline Dumbbell Curl | `incline_dumbbell_curl.gif` | dumbbell incline curl | `https://static.exercisedb.dev/media/ae9UoXQ.gif` | 99.0 | 12 | Yes |
| Dumbbell Shoulder Press | `dumbbell_shoulder_press.gif` | Alternating Seated Dumbbell Shoulder Press | `https://static.exercisedb.dev/media/q7qkONO.gif` | 142.2 | 24 | Yes |
| Dumbbell Lateral Raise | `dumbbell_lateral_raise.gif` | dumbbell lateral raise | `https://static.exercisedb.dev/media/DsgkuIt.gif` | 85.6 | 12 | Yes |
| Barbell Squat | `barbell_squat.gif` | Barbell Full Squat | `https://static.exercisedb.dev/media/iYzB0Cz.gif` | 58.1 | 12 | Yes |
| Leg Press | `leg_press.gif` | sled 45° leg press | `https://static.exercisedb.dev/media/10Z2DXU.gif` | 112.4 | 12 | Yes |
| Lying Leg Curl | `lying_leg_curl.gif` | Machine Lying Leg Curl | `https://static.exercisedb.dev/media/17lJ1kr.gif` | 112.1 | 12 | Yes |
| Standing Calf Raise | `standing_calf_raise.gif` | bodyweight standing calf raise | `https://static.exercisedb.dev/media/bJYHBIN.gif` | 60.7 | 12 | Yes |
| Incline Smith Machine Press | `incline_smith_machine_press.gif` | smith incline bench press | `https://static.exercisedb.dev/media/5v7KYld.gif` | 119.1 | 12 | Yes |
| Flat Machine Chest Press | `flat_machine_chest_press.gif` | Machine Chest Press | `https://static.exercisedb.dev/media/DOoWcnA.gif` | 112.8 | 12 | Yes |
| Pec Deck Fly | `pec_deck_fly.gif` | Machine Seated Fly | `https://static.exercisedb.dev/media/v3xmPAR.gif` | 118.8 | 12 | Yes |
| Straight Bar Triceps Pushdown | `straight_bar_triceps_pushdown.gif` | cable pushdown | `https://static.exercisedb.dev/media/3ZflifB.gif` | 93.0 | 12 | Yes |
| Overhead Rope Extension | `overhead_rope_extension.gif` | cable overhead triceps extension (rope attachment) | `https://static.exercisedb.dev/media/2IxROQ1.gif` | 59.8 | 12 | Yes |
| Pull-ups / Assisted Pull-ups | `pull_ups_assisted_pull_ups.gif` | assisted pull-up | `https://static.exercisedb.dev/media/kiJ4Z2K.gif` | 96.2 | 12 | Yes |
| T-Bar Row | `t_bar_row.gif` | Machine T Bar Row | `https://static.exercisedb.dev/media/aaXr7ld.gif` | 79.2 | 12 | Yes |
| Straight Arm Pulldown | `straight_arm_pulldown.gif` | cable straight arm pulldown | `https://static.exercisedb.dev/media/x69MAlq.gif` | 62.2 | 12 | Yes |
| Cable Rear Delt Fly | `cable_rear_delt_fly.gif` | Cable Crossover Reverse Fly | `https://static.exercisedb.dev/media/aqvSOQE.gif` | 113.1 | 12 | Yes |
| Hammer Curl | `hammer_curl.gif` | dumbbell hammer curl | `https://static.exercisedb.dev/media/2NpxjC1.gif` | 76.5 | 12 | Yes |
| Preacher Curl | `preacher_curl.gif` | barbell preacher curl | `https://static.exercisedb.dev/media/qOgPVf6.gif` | 114.7 | 12 | Yes |
| Machine Shoulder Press | `machine_shoulder_press.gif` | Machine Shoulder Press | `https://static.exercisedb.dev/media/67n3r98.gif` | 79.4 | 12 | Yes |
| Cable Lateral Raise | `cable_lateral_raise.gif` | cable lateral raise | `https://static.exercisedb.dev/media/goJ6ezq.gif` | 125.0 | 12 | Yes |
| Romanian Deadlift | `romanian_deadlift.gif` | barbell romanian deadlift | `https://static.exercisedb.dev/media/wQ2c4XD.gif` | 86.6 | 12 | Yes |
| Bulgarian Split Squat | `bulgarian_split_squat.gif` | dumbbell single leg split squat | `https://static.exercisedb.dev/media/qx4fgX7.gif` | 97.1 | 12 | Yes |
| Leg Extension | `leg_extension.gif` | Machine Leg Extension | `https://static.exercisedb.dev/media/my33uHU.gif` | 139.5 | 12 | Yes |
| Seated Leg Curl | `seated_leg_curl.gif` | Machine Seated Leg Curl | `https://static.exercisedb.dev/media/Zg3XY7P.gif` | 138.0 | 12 | Yes |
| Seated Calf Raise | `seated_calf_raise.gif` | Machine Seated Calf Raise | `https://static.exercisedb.dev/media/bOOdeyc.gif` | 105.6 | 12 | Yes |

Total GIF size: 3410.5 KB (3.4 MB).

## Same-movement variants used (no wrong movement substituted)

Where ExerciseDB V1 has no entry with the app's exact name, the GIF used is the same movement under a different name or equipment variant. No GIF shows a different exercise:
- Cable Chest Fly → Cable Crossover (standing cable crossover = cable chest fly).
- Chest Supported Row → dumbbell incline row (prone row on incline bench, chest supported).
- Single Arm Cable Row → Cable Seated Single-Arm Alternate Row (seated single-arm cable row).
- Reverse Pec Deck → Machine Seated Reverse Fly (same machine, rear-delt reverse fly); no "pec deck" entry exists in V1.
- Dumbbell Shoulder Press → Alternating Seated Dumbbell Shoulder Press (seated, alternating arms); no plain entry exists.
- Barbell Squat → Barbell Full Squat (standard barbell back squat).
- Leg Press → sled 45° leg press.
- Lying Leg Curl → Machine Lying Leg Curl. Standing Calf Raise → bodyweight standing calf raise.
- Incline Smith Machine Press → smith incline bench press. Flat Machine Chest Press → Machine Chest Press.
- Pec Deck Fly → Machine Seated Fly (pec-deck/butterfly machine). Straight Bar Triceps Pushdown → cable pushdown (standard straight-bar pushdown; V-bar/rope/reverse-grip variants rejected).
- Pull-ups / Assisted Pull-ups → assisted pull-up (leverage machine).
- Cable Rear Delt Fly → Cable Crossover Reverse Fly; no "cable rear delt fly" entry exists.
- Romanian Deadlift → barbell romanian deadlift. Bulgarian Split Squat → dumbbell single leg split squat (instructions confirm rear foot elevated on a bench — the Bulgarian pattern); no "bulgarian" entry exists.
- Overhead Cable Extension and Overhead Rope Extension use the same ExerciseDB entry ("cable overhead triceps extension (rope attachment)") — the two app exercises are the same rope overhead movement, so the identical GIF file is stored under both filenames (same md5).
- Two dead CDN links were found during matching and NOT used: `o6LqKKP` (barbell romanian deadlift, Cloudflare "Not Found" HTML) and `5ipN0iE` / `N3EirIW` (assisted pull-up variants, HTTP 404). Replacements above were verified as real GIFs.

## Licence / attribution

All 35 GIFs are from ExerciseDB V1 (AscendAPI), free tier: 1,500 exercises, 180p GIFs, no API key. Free use is restricted to personal / prototype / educational / non-commercial projects and requires AscendAPI attribution — see `GIF-SOURCES.md`. Do not use these GIFs in a commercial release without checking that licence. The free-exercise-db MP4 fallback (MIT code, 317 exercises, 34/35 matched, URLs HEAD-checked 200) was mapped as a backup and was NOT needed — no MP4 was downloaded or converted.

## Partial / not included

- **GIF resolution is 180p** (ExerciseDB V1 free tier). Higher resolutions are a paid ExerciseDB tier. On a phone screen the 16:9 player upscales them; quality is acceptable for a form demo, not HD.
- **TTS / translation / background playback** were verified present from v3.4.0 and unchanged; they were not re-tested on a device here.
- **Not included:** cloud sync, social feed, Wear OS, web dashboard, barcode food DB, real LLM AI coach, camera form checking — each needs a backend, a separate platform, or a large ML model.

## Static verification (this environment)

- `unzip -t` on the uploaded base ZIP: no errors. Final ZIP integrity checked after packaging (see below).
- GIFs: 35/35 present, all GIF89a, 180x180, 12 frames each except Dumbbell Shoulder Press (24 frames), 60–142 KB each, 3.4 MB total. No missing, no extra, no 0-byte, no HTML, no renamed MP4.
- `app/build.gradle.kts`: versionCode 19, versionName "3.5.0". Manifest: no INTERNET permission; foreground-service + WAKE_LOCK entries present for TTS.
- Font `app/src/main/res/font/noto_nastaliq_urdu.ttf` present. Gradle wrapper 8.9 present.

No Android Gradle compilation was run in this environment. No APK installation or on-device test was run.
