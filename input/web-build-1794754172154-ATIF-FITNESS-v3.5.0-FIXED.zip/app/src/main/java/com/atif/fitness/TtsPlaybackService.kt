package com.atif.fitness

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import androidx.core.app.NotificationCompat
import java.util.Locale

/**
 * v3.4.0 — offline foreground service for TTS playback.
 *
 * Purpose: keep exercise explanations / voice-guided announcements playing
 * when the screen turns off. The in-activity TTS in MainActivity stops when
 * the activity process is backgrounded; this service runs in the foreground
 * with a media notification, a partial wake lock and audio focus, so the
 * system is far less likely to kill playback on screen-off.
 *
 * No network, no backend, no new user data. Audio is generated on-device
 * by Android TextToSpeech. Not verified on a real device in this environment:
 * Bluetooth routing, screen-off survival and notification behaviour still
 * need on-device testing (see AUDIT-REPORT-v3.4.0.md).
 */
class TtsPlaybackService : Service() {

    companion object {
        const val ACTION_SPEAK = "com.atif.fitness.ACTION_SPEAK"
        const val ACTION_STOP = "com.atif.fitness.ACTION_STOP"
        const val EXTRA_TEXT = "text"
        const val EXTRA_LANGUAGE = "language"
        const val EXTRA_RATE = "rate"
        const val CHANNEL_ID = "atif_tts_playback"
        const val NOTIFICATION_ID = 101

        fun start(context: Context, text: String, language: String, rate: Float) {
            val intent = Intent(context, TtsPlaybackService::class.java).apply {
                action = ACTION_SPEAK
                putExtra(EXTRA_TEXT, text)
                putExtra(EXTRA_LANGUAGE, language)
                putExtra(EXTRA_RATE, rate)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun stop(context: Context) {
            val intent = Intent(context, TtsPlaybackService::class.java).apply { action = ACTION_STOP }
            context.startService(intent)
        }
    }

    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var sentences: List<String> = emptyList()
    private var sentenceIndex = 0
    private var generation = 0
    private var readyRetries = 0
    private var wakeLock: PowerManager.WakeLock? = null
    private var audioManager: AudioManager? = null
    private var focusRequest: AudioFocusRequest? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        createChannel()
        audioManager = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "AtifFitness:TtsPlayback")
        wakeLock?.acquire(10 * 60 * 1000L)
        tts = TextToSpeech(this) { status -> ttsReady = status == TextToSpeech.SUCCESS }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForeground(NOTIFICATION_ID, buildNotification("ATIF FITNESS — voice guidance"))
        when (intent?.action) {
            ACTION_STOP -> {
                stopSpeaking()
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_SPEAK -> {
                val text = intent.getStringExtra(EXTRA_TEXT).orEmpty()
                val language = intent.getStringExtra(EXTRA_LANGUAGE) ?: AppLanguage.EN
                val rate = intent.getFloatExtra(EXTRA_RATE, 1.0f)
                requestAudioFocus()
                speakSentences(text, language, rate)
            }
        }
        return START_NOT_STICKY
    }

    private fun speakSentences(text: String, language: String, rate: Float) {
        sentences = text.split(Regex("(?<=[.!?۔])\\s+")).filter { it.isNotBlank() }
        sentenceIndex = 0
        generation++
        readyRetries = 0
        speakCurrent(language, rate)
    }

    private fun speakCurrent(language: String, rate: Float) {
        val engine = tts ?: return
        if (sentenceIndex !in sentences.indices) { stopSelf(); return }
        if (!ttsReady) {
            // TTS engine initialises asynchronously; retry briefly instead of dropping the speech.
            if (readyRetries < 10) {
                readyRetries++
                android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({ speakCurrent(language, rate) }, 300)
            } else stopSelf()
            return
        }
        val locale = when (language) {
            AppLanguage.UR -> Locale("ur", "PK")
            else -> Locale.US
        }
        val result = engine.setLanguage(locale)
        if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
            stopSelf()
            return
        }
        engine.setSpeechRate(rate)
        val gen = generation
        engine.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(id: String?) {}
            override fun onError(id: String?) {}
            override fun onDone(id: String?) {
                if (gen == generation) {
                    sentenceIndex++
                    speakCurrent(language, rate)
                }
            }
        })
        engine.speak(sentences[sentenceIndex], TextToSpeech.QUEUE_FLUSH, null, "atif-bg-$gen-$sentenceIndex")
    }

    /** Pause = stop current utterance but keep the sentence index, so resume continues from the same sentence. */
    fun pauseSpeaking() {
        tts?.stop()
    }

    fun resumeSpeaking(language: String, rate: Float) {
        speakCurrent(language, rate)
    }

    private fun stopSpeaking() {
        generation++
        sentences = emptyList()
        sentenceIndex = 0
        tts?.stop()
        abandonAudioFocus()
    }

    private fun requestAudioFocus() {
        val am = audioManager ?: return
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val req = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK)
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .build()
                )
                .setOnAudioFocusChangeListener { focus ->
                    if (focus == AudioManager.AUDIOFOCUS_LOSS) pauseSpeaking()
                }
                .build()
            focusRequest = req
            am.requestAudioFocus(req)
        } else {
            @Suppress("DEPRECATION")
            am.requestAudioFocus(null, AudioManager.STREAM_MUSIC, AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK)
        }
    }

    private fun abandonAudioFocus() {
        val am = audioManager ?: return
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            focusRequest?.let { am.abandonAudioFocusRequest(it) }
        } else {
            @Suppress("DEPRECATION")
            am.abandonAudioFocus(null)
        }
        focusRequest = null
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Voice guidance",
                NotificationManager.IMPORTANCE_LOW
            ).apply { description = "ATIF FITNESS voice-guided workout announcements" }
            (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager)
                .createNotificationChannel(channel)
        }
    }

    private fun buildNotification(text: String): Notification {
        val openIntent = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val stopIntent = PendingIntent.getService(
            this, 1,
            Intent(this, TtsPlaybackService::class.java).apply { action = ACTION_STOP },
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("ATIF FITNESS")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentIntent(openIntent)
            .addAction(android.R.drawable.ic_media_pause, "Stop", stopIntent)
            .setOngoing(true)
            .build()
    }

    override fun onDestroy() {
        stopSpeaking()
        tts?.stop()
        tts?.shutdown()
        tts = null
        try { wakeLock?.release() } catch (_: Exception) { }
        wakeLock = null
        super.onDestroy()
    }
}
