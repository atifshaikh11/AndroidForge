# ATIF FITNESS v3.5.0

Native Android Kotlin + Jetpack Compose fitness tracker. This release is based directly on the uploaded v3.4.0 source ZIP. The application ID remains `com.atif.fitness`; the existing PPL x2 plan and existing app features are retained.

## v3.5.0 changes — built-in offline exercise GIF player

- Added Coil Compose 2.7.0 and Coil GIF 2.7.0.
- Added `gifFileName` to the `Exercise` data class. All 35 built-in exercises receive a deterministic filename under `app/src/main/assets/exercise_gifs/`.
- Replaced the old YouTube/WebView exercise demonstration control with a `WATCH DEMO` card, 16:9 GIF display area, and Play/Pause control.
- GIF requests use an `ImageLoader` configured with `GifDecoder.Factory()`. Playback starts automatically; the drawable is stopped when paused or when the exercise screen leaves composition.
- If the matching asset is absent or fails to decode, the existing stick-figure `AnimationCard` is shown with the exact message `GIF not available for this exercise yet`. No browser or YouTube fallback exists.
- Removed the app's `INTERNET` permission. GIF playback is designed to use packaged assets only.
- Version metadata: `versionCode = 19`, `versionName = "3.5.0"`; backup JSON version is `3.5.0`.

## GIF asset status

**35 of 35 GIF files are included in this source ZIP** (`app/src/main/assets/exercise_gifs/`, 3.4 MB total). Every GIF was downloaded from ExerciseDB V1, verified on disk (`file` = GIF89a, `ffprobe` = 180x180, 12 frames each except Dumbbell Shoulder Press with 24 frames), and matched to the correct exercise — same-movement variants are documented in `AUDIT-REPORT-v3.5.0.md`. No placeholder, empty, or fabricated GIFs. Licence: ExerciseDB V1 free tier, non-commercial use only, AscendAPI attribution required — see `GIF-SOURCES.md`.

## v3.5.0 changes in this build (GIFs added)

- Downloaded all 35 real GIFs from ExerciseDB V1 (`https://static.exercisedb.dev/media/<id>.gif`) and placed them in `app/src/main/assets/exercise_gifs/`.
- Rewrote `AUDIT-REPORT-v3.5.0.md` with the per-exercise inventory (gifUrl, size, frames) and `GIF-SOURCES.md` with source/licence details.
- No Kotlin code was changed in this build — the player, version (3.5.0 / code 19), backup version (3.5.0) and Gradle wrapper (8.9) were already correct in the uploaded base and are byte-identical to it.

## Existing features retained

The source was continued from v3.4.0 rather than recreated. The existing PPL x2 plan, translation, TTS, streak, CSV export, favourites, gym tools, training modes, graphs, backup/restore, workout logging, routines, and progress features remain in the source. No ExoPlayer, cloud media, social feature, or Wear OS feature was added.

## Build and test status

No Android Gradle compilation was run. No APK or device test was run.
