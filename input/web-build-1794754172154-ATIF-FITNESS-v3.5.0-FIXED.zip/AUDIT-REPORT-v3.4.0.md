# AUDIT REPORT — ATIF FITNESS v3.4.0

**Package:** `com.atif.fitness` (unchanged) · **versionCode 18** · **versionName "3.4.0"**
**Base:** v3.3.1 source ZIP `ATIF-FITNESS-v3.3.1-source_8_92o4.zip` (325K, versionCode 17) — upgraded in place, not rebuilt from scratch.
**Date:** 2026-11-15
**Verification method:** static checks only (see the last section). No Android Gradle compilation was run in this environment. No APK installation or on-device test was run.

## v3.3.1 baseline — independently verified before the upgrade

- `unzip -t` on the v3.3.1 ZIP: no errors. Extracted 824K.
- `app/build.gradle.kts`: namespace/applicationId `com.atif.fitness`, compileSdk/targetSdk 35, minSdk 26, versionCode 17, versionName "3.3.1".
- `MainActivity.kt`: 92,786 bytes, 1,007 lines, braces 872/872, parens 2,133/2,133 (balanced).
- Backup version in v3.3.1 was already "3.3.0" (grep `"3.0.2"` = 0) — the v3.2.0 bug was already fixed in v3.3.0. It is now "3.4.0".
- TextToSpeech: 7 references; `speak()` splits into sentences; pause = stop, resume = speak current sentence. No foreground service, no Notification, no AudioFocus, no NotificationChannel, no `startForeground` in v3.3.1.
- Manifest: INTERNET + VIBRATE only. Font `app/src/main/res/font/noto_nastaliq_urdu.ttf` (558K) present.
- Strings: `values/strings.xml` 12 keys, `values-ur/strings.xml` 12 keys — translation known incomplete.
- `Language.kt`: `AppLanguage` with EN/UR/ROMAN; `ExerciseLanguages` mapped only exercise display names (28 Urdu, 28 Roman — Roman names were Latin/English spellings); `explanation()` wrapped the *English* cues/breathing/mistakes with Urdu/Roman connectors — it did not translate the cues themselves.
- Exercises counted in the plan: **35 built-in exercises** (Sat 5, Sun 6, Mon 6, Tue 5, Wed 6, Thu 7). Each has 3 cues (Barbell Squat and Romanian Deadlift have 4), 2 mistakes (Bench Press, Squat, Romanian Deadlift have 3), 1 breathing string — about 210 English instruction strings to translate.
- Existing features confirmed in code: streak + milestones, CSV export, favourites, plate/warm-up/Epley 1RM tools, unit preference (kg/lb chips, but display conversion was not applied), Exam/Ramadan/Travel modes, readiness check, pain note, weekly report, 5 tabs, RPE, numeric keyboards, persisted rest timer, routine editor, custom exercises, 11 Pakistani foods, water tracker, body measurements, progress photo picker, JSON backup export/restore, volume graph (last 7 dates, numbered bars, no date labels), PRs, plateau check.

## Added in v3.4.0

| # | Feature | Evidence |
|---|---|---|
| 1 | **Complete exercise translation — 35/35 exercises** | `Language.kt` → `ExerciseLanguages.translations`: 35 entries, each with `ur` and `roman` `ExerciseTranslationData` (name, cues, breathing, mistakes). Count: 35 unique exercise keys, 70 translation objects, 70 `cues=listOf(`, 70 `breathing=`, 70 `mistakes=listOf(`. Exercise detail now displays `ExerciseLanguages.cues/breathing/mistakes(e, language)`; `explanation()` returns fully translated text; the next-exercise announcement uses the translated name. |
| 2 | **UI translation — 157 keys** | `AppLanguage.ui`: 157 unique keys (English → Urdu + Roman Urdu). Main screens route literals through `AppLanguage.text(key, language)` — 81 + 31 + 11 routed `Text()` occurrences; `Header` translates title/subtitle. `values/strings.xml` and `values-ur/strings.xml` expanded from 12 to **48 keys each** (33 of the 48 Urdu values differ from English; the rest are proper names/symbols such as "ATIF FITNESS"). Numbers/units (kg, reps, g) stay English in all languages. |
| 3 | **Background TTS playback** | New `TtsPlaybackService.kt` (243 lines): foreground service (`mediaPlayback` type), notification channel `atif_tts_playback`, media notification with Stop action, partial wake lock (10 min), audio-focus request/abandon (API 26+ `AudioFocusRequest`, fallback below), sentence-level queueing with `UtteranceProgressListener`; pause keeps the sentence index, resume continues from the current sentence; retries briefly if the TTS engine is not ready yet. Manifest adds FOREGROUND_SERVICE, FOREGROUND_SERVICE_MEDIA_PLAYBACK, WAKE_LOCK and the `<service>` entry. Exercise detail has "Play in background" / "Stop background" buttons wired to `MainActivity.startBackgroundSpeech()` / `stopBackgroundSpeech()`. In-activity Play/Pause/Resume unchanged. |
| 4 | **KG/LB conversion applied** | New `WeightUnits` object (stored values stay kg): `displayKg` / `displayKgString` / `kgToLb` / `lbToKg` / `current()` (reads `atif_tools` unit first, falls back to `atif`). Wired into Progress total volume + PRs, ExerciseDetail last performance, WorkoutScreen "Last:" line, gym-tool labels and 1RM result. The stale note "full display/input conversion is not yet applied" is removed. |
| 5 | **Favourites in backup/restore** | Backup JSON now also stores `favorites` (JSONArray), `unit`, `trainingMode`; restore brings them back (favourites via `saveFavorites()`, unit only if "kg"/"lb", trainingMode if present). |
| 6 | **Custom food + calorie target** | Nutrition screen: "ADD YOUR OWN FOOD" (name, kcal, protein, carbs, fat) saved in `atif_custom_foods` prefs, appears in quick-add; "CALORIE TARGET" card — target ≈ body weight × 33 kcal + 300 kcal surplus, with progress vs today's logged kcal. Labelled a planning estimate, not a prescription. |
| 7 | **Body-weight weekly-average graph** | New `WeightHistoryCard` in Profile: weight changes are recorded (one entry per date, `atif_weight_history`, last 365 entries) and the last 8 weekly averages are graphed with week labels. |
| 8 | **Per-exercise strength graph with date labels** | New `ExerciseStrengthCard` in Progress: exercise selector + best completed set per session (last 10 sessions), bars labelled month-day, weights shown in the selected unit. |
| 9 | **Workout templates** | Home screen "WORKOUT TEMPLATES": Empty workout and Copy last workout (reuses the exercises of the most recent logged day). The workout screen already supports add/replace and persists the routine. |
| 10 | **Weekly report share** | `WeeklyReportCard` now has a "Share weekly report" button (ACTION_SEND text intent via chooser: sessions, working sets, volume, top 5 PRs). |
| 11 | **Gradle wrapper included** | `gradlew`, `gradlew.bat`, `gradle/wrapper/gradle-wrapper.jar`, `gradle/wrapper/gradle-wrapper.properties` (Gradle 8.7.0). The wrapper JAR SHA-256 `cb0da6751c2b753a16ac168bb354870ebb1e162e9083f116729cec9c781156b8` was verified against `https://services.gradle.org/distributions/gradle-8.7-wrapper.jar.sha256` — exact match. The properties file's distribution URL was corrected from the 8.7-rc-4 pre-release to the final `gradle-8.7-bin.zip`. Build with `./gradlew assembleDebug` (Android SDK 35 required) or the AndroidForge cloud build. |
| 12 | **Known-bug fixes** | Backup JSONObject version "3.4.0" (grep `"3.0.2"` = 0 in all Kotlin files). README header now "ATIF FITNESS v3.4.0" with a v3.4.0 changelog; stale "Phase 3.1 (v3.0.1)" header and stale limitations text corrected. |
| 13 | **Preserved** | Package `com.atif.fitness`, PPL x2 plan (unchanged), streak, CSV export, favourites, plate/warm-up/1RM, Exam/Ramadan/Travel modes, readiness, weekly report, all existing features. Old backups (3.0.2, 3.1.0, 3.2.0, 3.3.1) still restore — the restore parser has no version rejection and was not changed. |

## Partial (incomplete by design or by scope)

- **A few strings remain English:** equipment and muscle names, user-entered data (custom exercise names, notes, imported history), dynamic values (dates, counts, "SET 1"), and a few long coach-tip subtitles. These are data or dynamic text, not static UI.
- **Translation quality is human-reviewed at the sentence level only:** Urdu and Roman Urdu translations were produced for this release and checked for completeness/counts, not by a professional translator. Exercise instructions should be spot-checked by a native Urdu speaker before a public release.
- **Background TTS is implemented but not device-tested:** screen-off survival, notification behaviour, Bluetooth routing and the wake-lock duration still need an on-device test. If the system kills the service, playback stops.
- **TTS pause/resume is sentence-level, not mid-word:** Android TTS has no native pause/resume cursor API. Resume restarts the current sentence.
- **The legacy YouTube demonstration WebView still needs internet** (existing feature, unchanged). TTS itself makes no network requests.
- **Volume graph (last 7 dates) still uses numbered bars** — the new per-exercise strength graph has date labels; the old volume graph was left as-is to avoid breaking existing code.

## Not included (with reason)

- **Cloud sync / Google sign-in** — needs a backend, accounts and a privacy policy; cannot be done safely in one offline ZIP.
- **Social feed / friends / leaderboard / trainer mode** — needs a backend and moderation; out of scope for an offline build.
- **Wear OS app** — separate platform/module, separate build target.
- **Web dashboard** — separate platform/hosting.
- **Barcode food database** — needs a product database / network lookup; the offline alternative (custom food add) was included instead.
- **Real LLM AI coach** — needs a model download (large) or a cloud API; the existing rule-based Coach guidance is retained.
- **Camera-based form checking** — needs an on-device pose-estimation ML model (large) and camera permission; not safe to add in one offline ZIP.

## Static verification (this environment)

- `unzip -t` on the v3.4.0 ZIP: no errors (run at packaging time; see below).
- `MainActivity.kt`: 111,011 bytes, 1,166 lines; braces 900/900, parens 2,538/2,538, brackets 37/37 (string literals and line comments stripped before counting); 0 odd-quote lines.
- `Language.kt`: 60,056 bytes, 397 lines; braces 7/7, parens 433/433 (string literals and line comments stripped before counting); 0 odd-quote lines; 35 unique exercise keys, 157 unique UI keys, no duplicate keys.
- `TtsPlaybackService.kt`: 9,314 bytes, 243 lines; braces 47/47, parens 118/118 (string literals and line comments stripped before counting); 0 odd-quote lines.
- `app/build.gradle.kts`: versionCode 18, versionName "3.4.0".
- Backup version: `"3.4.0"` present; `"3.0.2"` = 0 in all Kotlin files.
- Manifest: FOREGROUND_SERVICE, FOREGROUND_SERVICE_MEDIA_PLAYBACK, WAKE_LOCK permissions; `<service android:name=".TtsPlaybackService" android:foregroundServiceType="mediaPlayback" />` present.
- Font: `app/src/main/res/font/noto_nastaliq_urdu.ttf` present (558K).
- Strings: `values/strings.xml` 48 keys, `values-ur/strings.xml` 48 keys.
- Gradle wrapper: `gradlew` (executable), `gradlew.bat`, `gradle/wrapper/gradle-wrapper.jar` (SHA-256 verified against services.gradle.org), `gradle/wrapper/gradle-wrapper.properties` (Gradle 8.7.0).
- Scope check: every `AppLanguage.text(..., language)` call is inside a composable that receives `language` (three helper cards — `AnimationCard`, `GymToolsAndReadinessCard`, `TrainingMilestonesCard` — were given a `language` parameter and their callers pass it; this was caught and fixed during this audit pass).

No Android Gradle compilation was run in this environment. No APK installation or on-device test was run.
