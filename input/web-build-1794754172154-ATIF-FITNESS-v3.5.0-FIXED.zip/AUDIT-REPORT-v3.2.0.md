# ATIF FITNESS v3.2.0 — Source Audit

## Added in this batch
- Training streak counter based on distinct local workout-log dates. A streak remains active when the latest logged day is today or yesterday.
- Milestone achievements for 1, 10, 25, 50 and 100 logged training dates, plus 10,000 kg of completed-set volume.
- CSV export of workout history, including date, day, exercise, set index, weight, reps, set type, completion, RPE, duration and note.

## Validation performed
- ZIP archive integrity checked.
- Source-level checks confirm the new component is included in Progress and the CSV export control is included in Profile.
- Version metadata is 3.2.0 / versionCode 15.

## Not verified
- No Android Gradle compilation was run in this environment.
- No APK installation or on-device UI test was run.
- Streak logic and CSV export still require real-device testing, including date boundaries and CSV opening in a spreadsheet app.

## Existing limitations retained
- Workout data remains local SharedPreferences JSON, not Room/cloud sync.
- Cloud sync, account login, social feed, wearable integration, web dashboard, barcode food database, offline video library, camera form detection and a real LLM coach are not included.
- Unit preference does not convert every stored/displayed weight value.
