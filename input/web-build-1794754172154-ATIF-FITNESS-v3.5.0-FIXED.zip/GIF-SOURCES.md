# GIF SOURCES — ATIF FITNESS v3.5.0

## Included assets

`app/src/main/assets/exercise_gifs/` — **35 / 35 GIFs included**, 3.4 MB total.
Every GIF is a 180p animated GIF (180x180, 12 frames, except Dumbbell Shoulder Press with 24 frames), verified on disk with `file` (GIF89a) and `ffprobe` (frame count). See `AUDIT-REPORT-v3.5.0.md` for the per-exercise table with gifUrl, size and frame count.

## Primary source — ExerciseDB V1 (AscendAPI) — used for all 35 GIFs

- Docs: https://oss.exercisedb.dev/docs
- API used: `GET https://oss.exercisedb.dev/api/v1/exercises?name=<exercise>&limit=25`
- GIF files: `https://static.exercisedb.dev/media/<exerciseId>.gif`
- Catalogue: 1,500 exercises, 180p GIFs, no API key required.
- Licence: free tier is restricted to personal / prototype / educational / non-commercial use and requires AscendAPI attribution. Do not use these GIFs in a commercial release without checking that licence.
- Note: the API's cursor/page/offset pagination parameters are ignored (the same first page is returned); matching was done with targeted `?name=` searches (max 25 results per query). Two CDN links listed by the API were dead (Cloudflare "Not Found" / HTTP 404) and were not used; replacements were verified as real GIFs.

## Fallback source — free-exercise-db-with-videos (NOT used, mapped only)

- Repository: https://github.com/harshvishu/free-exercise-db-with-videos (main branch; the old amiinwani URL 404s)
- Data: `data/exercises.json` (733 KB, 317 exercises, 593 MP4 videos: 290 male / 303 female) on Cloudflare R2.
- Mapping: 34 / 35 app exercises matched (Bulgarian Split Squat has no entry); all 66 unique MP4 URLs HEAD-checked HTTP 200. Full mapping in the build notes (`/tmp/fed_mapping.json`, not shipped).
- Licence: code + metadata MIT (Copyright © 2026 Arham Wani). Video licence is vague — README credits say demo videos are "from an animated exercise video set, redistributed here with the maintainer's rights", with no separate video licence or attribution wording. Do not bundle those videos into a shipped APK without resolving that.
- This fallback was not needed: ExerciseDB V1 covered all 35 exercises, so no MP4 was downloaded and no ffmpeg conversion was run.

## Important

- Never rename an MP4 to `.gif`. Convert with ffmpeg (palette method, width 320, 10 fps, max 3 s loop) and validate the result with `file` + `ffprobe` before including it.
- A filename in the code is not an included asset — only a file verified on disk counts. In this release all 35 are verified on disk.
