# ATIF FITNESS v3.1.0 — Integrated offline feature batch audit

## Scope
This release adds several feasible local/offline features together. It does not claim to complete the entire master list.

## Added in source
- Favourite exercise toggle and favourites-only filter (stored locally).
- Gym tools: plate loading calculator (greedy plate selection), warm-up ramp suggestion, Epley estimated 1RM.
- Saved unit preference (kg/lb selector). Important: this is currently a preference only; logger values remain kg and no automatic conversion is applied.
- Training mode selector: Normal, Exam, Ramadan, Travel. Provides guidance; it does not rewrite workouts automatically.
- Readiness check based on sleep, energy and soreness; saved locally. It is a heuristic, not medical advice.
- Pain/injury note saved locally.
- Weekly report from logged sessions, completed sets and volume.

## Known limitations
- Plate calculator uses user-entered plate inventory and a greedy descending selection. If the target cannot be made exactly, it reports the remainder.
- Warm-up percentages are generic suggestions and must be adjusted to the lift, athlete and readiness.
- 1RM uses Epley estimate and is less reliable for high-rep sets.
- Weekly report uses the device's calendar week and locally saved workout dates.
- Unit selector does not yet convert every display or stored weight.
- Favorites are stored locally; backup/restore does not currently include favorites or training preferences.
- No cloud, account, social feed, leaderboard, wearable, web dashboard, camera pose estimation, offline video pack, barcode database, or genuine LLM coach in this release.

## Existing code audit carry-forward
- Exercise library remains a small curated built-in list plus user-created entries, not 1000+.
- YouTube tutorial lookup is online WebView search, not offline video.
- Routine editor and sets/reps persistence exist in source; actual migration/install compatibility still requires device testing.
- Nutrition entries use approximate/manual food values.
- Progression and plateau are heuristics, not validated AI.
- Local JSON backup/restore exists; cloud sync does not.

## QA
- ZIP integrity and targeted static feature-string checks: to be verified after archive creation.
- Kotlin/Android compilation: not run in this environment.
- Runtime/device testing: pending AndroidForge build and install.
