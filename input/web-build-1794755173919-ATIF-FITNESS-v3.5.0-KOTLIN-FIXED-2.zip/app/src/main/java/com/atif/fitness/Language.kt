package com.atif.fitness

import java.util.Locale

/** Local in-app language support. Roman Urdu is intentionally independent of Android locale. */
object AppLanguage {
    const val EN = "en"
    const val UR = "ur"
    const val ROMAN = "roman"
    fun current(prefs: android.content.SharedPreferences): String = prefs.getString("app_language", EN) ?: EN
    /** v3.4.0 — UI map is checked first, then the legacy short maps, then the key itself. */
    fun text(key: String, language: String): String = when (language) {
        UR -> ui[key]?.ur ?: urdu[key] ?: key
        ROMAN -> ui[key]?.roman ?: roman[key] ?: key
        else -> key
    }
    private val urdu = mapOf(
        "Home" to "ہوم", "Workout" to "ورک آؤٹ", "Progress" to "پیش رفت", "Nutrition" to "غذا", "Profile" to "پروفائل",
        "Language" to "زبان", "English" to "English", "اردو" to "اردو", "Roman Urdu" to "رومن اردو",
        "Listen to explanation" to "ورزش کی وضاحت سنیں", "Play" to "چلائیں", "Pause" to "روکیں", "Stop" to "بند کریں",
        "Voice-guided workout" to "آواز کے ساتھ ورک آؤٹ", "HOW TO PERFORM" to "ورزش کرنے کا طریقہ", "BREATHING" to "سانس لینے کا طریقہ",
        "COMMON MISTAKES" to "عام غلطیاں", "SET LOGGER" to "سیٹ ریکارڈ", "Save exercise log" to "ورزش محفوظ کریں",
        "Start workout" to "ورک آؤٹ شروع کریں", "Profile & body tracking" to "پروفائل اور جسمانی ریکارڈ", "DATA & BACKUP" to "ڈیٹا اور بیک اپ",
        "Export workout backup" to "ورک آؤٹ بیک اپ برآمد کریں", "Restore from backup" to "بیک اپ بحال کریں",
        "No exercises match your search." to "آپ کی تلاش سے کوئی ورزش نہیں ملی۔", "Rest finished, start next set" to "آرام مکمل، اگلا سیٹ شروع کریں",
        "Next exercise" to "اگلی ورزش", "seconds left" to "سیکنڈ باقی", "Rest" to "آرام"
    )
    private val roman = mapOf(
        "Home" to "Home", "Workout" to "Workout", "Progress" to "Progress", "Nutrition" to "Ghiza", "Profile" to "Profile",
        "Language" to "Zabaan", "English" to "English", "اردو" to "Urdu", "Roman Urdu" to "Roman Urdu",
        "Listen to explanation" to "Exercise ki wazahat suno", "Play" to "Chalao", "Pause" to "Roko", "Stop" to "Band karo",
        "Voice-guided workout" to "Awaz ke sath workout", "HOW TO PERFORM" to "Exercise ka tareeqa", "BREATHING" to "Saans lene ka tareeqa",
        "COMMON MISTAKES" to "Aam ghaltiyan", "SET LOGGER" to "Set record", "Save exercise log" to "Exercise save karo",
        "Start workout" to "Workout shuru karo", "Profile & body tracking" to "Profile aur body tracking", "DATA & BACKUP" to "Data aur backup",
        "Export workout backup" to "Workout backup export karo", "Restore from backup" to "Backup restore karo",
        "No exercises match your search." to "Tumhari search se koi exercise nahi mili.", "Rest finished, start next set" to "Rest khatam, agla set shuru karo",
        "Next exercise" to "Agli exercise", "seconds left" to "seconds baqi", "Rest" to "Aaram"
    )
    /** v3.4.0 — full UI string map (108 keys), generated for the v3.4.0 translation pass. */
    val ui: Map<String, UiTranslation> = mapOf(
"YOUR FITNESS DASHBOARD" to UiTranslation(ur="آپ کا فٹنس ڈیش بورڈ", roman="Tumhara fitness dashboard"),
"Build muscle. Track progress." to UiTranslation(ur="مسلز بنائیں۔ پیش رفت ٹریک کریں۔", roman="Muscle banao. Progress track karo."),
"Intermediate · Muscle gain · 6 days/week" to UiTranslation(ur="انٹرمیڈیٹ · مسل گین · ہفتے میں 6 دن", roman="Intermediate · Muscle gain · Haftay mein 6 din"),
"Continue training" to UiTranslation(ur="ٹریننگ جاری رکھیں", roman="Training jaari rakho"),
"Start workout" to UiTranslation(ur="ورزش شروع کریں", roman="Workout shuru karo"),
"WEEKLY PLAN" to UiTranslation(ur="ہفتہ وار پلان", roman="Haftay ka plan"),
"FRIDAY · REST & RECOVERY" to UiTranslation(ur="جمعہ · آرام اور بحالی", roman="Jumma · Aaram aur recovery"),
"Light walk, adequate food, hydration and 7-9 hours of sleep." to UiTranslation(ur="ہلکی چہل قدمی، مناسب کھانا، پانی اور 7-9 گھنٹے نیند۔", roman="Halki walk, munasib khana, paani aur 7-9 ghantay neend."),
"Workout plan" to UiTranslation(ur="ورزش کا منصوبہ", roman="Workout plan"),
"Search exercises" to UiTranslation(ur="ورزشیں تلاش کریں", roman="Exercise dhoondo"),
"Search exercise library" to UiTranslation(ur="ورزش لائبریری تلاش کریں", roman="Exercise library mein dhoondo"),
"60-90 minute target · Warm up before working sets" to UiTranslation(ur="60-90 منٹ کا ہدف · ورکنگ سیٹس سے پہلے وارم اپ کریں", roman="60-90 minute ka target · Working sets se pehle warm up karo"),
"Rest guide: 2-3 min for compound lifts; 60-120 sec for isolation. Keep most sets 1-3 reps in reserve." to UiTranslation(ur="آرام کی ہدایت: کمپاؤنڈ لفٹس کے لیے 2-3 منٹ؛ آئسولیشن کے لیے 60-120 سیکنڈ۔ زیادہ تر سیٹس میں 1-3 ریپس ریزرو رکھیں۔", roman="Rest guide: Compound lifts ke liye 2-3 min; isolation ke liye 60-120 sec. Zyada tar sets mein 1-3 reps reserve rakho."),
"HOW TO PERFORM" to UiTranslation(ur="کرنے کا طریقہ", roman="Kaisay karna hai"),
"BREATHING" to UiTranslation(ur="سانس لینا", roman="Saans lena"),
"COMMON MISTAKES" to UiTranslation(ur="عام غلطیاں", roman="Aam ghaltiyan"),
"Use a controlled range of motion. Stop if you feel sharp pain." to UiTranslation(ur="کنٹرول شدہ رینج آف موشن استعمال کریں۔ اگر تیز درد محسوس ہو تو رک جائیں۔", roman="Controlled range of motion use karo. Agar tez dard mehsoos ho to ruk jao."),
"SET LOGGER" to UiTranslation(ur="سیٹ لاگر", roman="Set logger"),
"Previous session" to UiTranslation(ur="پچھلا سیشن", roman="Pichla session"),
"Last performance" to UiTranslation(ur="آخری کارکردگی", roman="Aakhri performance"),
"Add set" to UiTranslation(ur="سیٹ شامل کریں", roman="Set add karo"),
"Repeat last" to UiTranslation(ur="آخری دہرائیں", roman="Aakhri repeat karo"),
"Remove" to UiTranslation(ur="ہٹائیں", roman="Hatao"),
"Rest timer" to UiTranslation(ur="آرام کا ٹائمر", roman="Rest timer"),
"Workout timer" to UiTranslation(ur="ورزش کا ٹائمر", roman="Workout timer"),
"Save exercise log" to UiTranslation(ur="ورزش محفوظ کریں", roman="Exercise save karo"),
"Save" to UiTranslation(ur="محفوظ کریں", roman="Save karo"),
"Cancel" to UiTranslation(ur="منسوخ کریں", roman="Cancel karo"),
"Close" to UiTranslation(ur="بند کریں", roman="Band karo"),
"Delete" to UiTranslation(ur="حذف کریں", roman="Delete karo"),
"Edit" to UiTranslation(ur="ترمیم کریں", roman="Edit karo"),
"Reset" to UiTranslation(ur="ری سیٹ کریں", roman="Reset karo"),
"Play" to UiTranslation(ur="چلائیں", roman="Play karo"),
"Pause" to UiTranslation(ur="وقفہ کریں", roman="Pause karo"),
"Resume" to UiTranslation(ur="جاری رکھیں", roman="Resume karo"),
"Stop" to UiTranslation(ur="روکیں", roman="Roko"),
"Speed" to UiTranslation(ur="رفتار", roman="Speed"),
"Listen to explanation" to UiTranslation(ur="وضاحت سنیں", roman="Wazahat suno"),
"Voice-guided workout" to UiTranslation(ur="آواز کی رہنمائی والی ورزش", roman="Voice-guided workout"),
"Progress & coaching" to UiTranslation(ur="پیش رفت اور کوچنگ", roman="Progress aur coaching"),
"PROGRESSIVE OVERLOAD" to UiTranslation(ur="پروگریسیو اوورلوڈ", roman="Progressive overload"),
"PLATEAU" to UiTranslation(ur="پلیٹو", roman="Plateau"),
"DELOAD CHECK" to UiTranslation(ur="ڈی لوڈ چیک", roman="Deload check"),
"WORKING SETS BY MUSCLE GROUP" to UiTranslation(ur="مسل گروپ کے مطابق ورکنگ سیٹس", roman="Muscle group ke hisaab se working sets"),
"PLAN CHECK-OFFS" to UiTranslation(ur="پلان چیک آف", roman="Plan check-offs"),
"PERSONAL BESTS" to UiTranslation(ur="ذاتی بہترین", roman="Personal bests"),
"RECENT TRAINING VOLUME" to UiTranslation(ur="حالیہ ٹریننگ والیوم", roman="Haaliya training volume"),
"STREAK & ACHIEVEMENTS" to UiTranslation(ur="سٹریک اور کامیابیاں", roman="Streak aur achievements"),
"Achievements" to UiTranslation(ur="کامیابیاں", roman="Achievements"),
"Nutrition & recovery" to UiTranslation(ur="غذائیت اور بحالی", roman="Nutrition aur recovery"),
"MUSCLE-GAIN DAILY TARGET" to UiTranslation(ur="مسل گین کا روزانہ ہدف", roman="Muscle gain ka rozana target"),
"TODAY'S MACROS" to UiTranslation(ur="آج کے میکروز", roman="Aaj ke macros"),
"PAKISTANI FOOD QUICK ADD" to UiTranslation(ur="پاکستانی کھانا فوری شامل کریں", roman="Pakistani khana quick add karo"),
"Add food" to UiTranslation(ur="کھانا شامل کریں", roman="Khana add karo"),
"TODAY'S FOOD LOG" to UiTranslation(ur="آج کا کھانے کا لاگ", roman="Aaj ka khane ka log"),
"WATER TRACKER" to UiTranslation(ur="پانی کا ٹریکر", roman="Paani tracker"),
"MUSCLE-GAIN PLATE GUIDE" to UiTranslation(ur="مسل گین پلیٹ گائیڈ", roman="Muscle gain plate guide"),
"WARM-UP SET CALCULATOR" to UiTranslation(ur="وارم اپ سیٹ کیلکولیٹر", roman="Warm-up set calculator"),
"GYM TOOLS" to UiTranslation(ur="جم ٹولز", roman="Gym tools"),
"Plate calculator" to UiTranslation(ur="پلیٹ کیلکولیٹر", roman="Plate calculator"),
"Warm-up calculator" to UiTranslation(ur="وارم اپ کیلکولیٹر", roman="Warm-up calculator"),
"Estimated 1RM (Epley)" to UiTranslation(ur="تخمینہ شدہ 1RM (ایپلی)", roman="Estimated 1RM (Epley)"),
"Unit preference" to UiTranslation(ur="یونٹ کی ترجیح", roman="Unit preference"),
"Training mode" to UiTranslation(ur="ٹریننگ موڈ", roman="Training mode"),
"Readiness check" to UiTranslation(ur="تیاری کا جائزہ", roman="Readiness check"),
"Pain / injury note" to UiTranslation(ur="درد / چوٹ کا نوٹ", roman="Dard / chot ka note"),
"Save readiness" to UiTranslation(ur="تیاری محفوظ کریں", roman="Readiness save karo"),
"Save pain note" to UiTranslation(ur="درد کا نوٹ محفوظ کریں", roman="Dard ka note save karo"),
"Profile & body tracking" to UiTranslation(ur="پروفائل اور جسم کی ٹریکنگ", roman="Profile aur body tracking"),
"BODY MEASUREMENTS" to UiTranslation(ur="جسم کی پیمائشیں", roman="Body measurements"),
"PROGRESS PHOTO" to UiTranslation(ur="پیش رفت کی تصویر", roman="Progress photo"),
"DATA & BACKUP" to UiTranslation(ur="ڈیٹا اور بیک اپ", roman="Data aur backup"),
"Export workout backup" to UiTranslation(ur="ورزش کا بیک اپ ایکسپورٹ کریں", roman="Workout backup export karo"),
"Export workout history (CSV)" to UiTranslation(ur="ورزش کی ہسٹری ایکسپورٹ کریں (CSV)", roman="Workout history export karo (CSV)"),
"Restore from backup" to UiTranslation(ur="بیک اپ سے بحال کریں", roman="Backup se restore karo"),
"Replace current workout history?" to UiTranslation(ur="موجودہ ورزش کی ہسٹری تبدیل کر دیں؟", roman="Maujooda workout history replace kar dein?"),
"Continue to restore" to UiTranslation(ur="بحالی جاری رکھیں", roman="Restore jaari rakho"),
"Delete workout record?" to UiTranslation(ur="ورزش کا ریکارڈ حذف کر دیں؟", roman="Workout record delete kar dein?"),
"No workout logs yet." to UiTranslation(ur="ابھی تک کوئی ورزش لاگ نہیں ہے۔", roman="Abhi tak koi workout log nahi hai."),
"Nothing logged yet." to UiTranslation(ur="ابھی تک کچھ لاگ نہیں ہوا۔", roman="Abhi tak kuch log nahi hua."),
"No exercises match your search." to UiTranslation(ur="آپ کی تلاش سے کوئی ورزش نہیں ملی۔", roman="Tumhari search se koi exercise nahi mili."),
"Complete workouts to build your volume graph." to UiTranslation(ur="والیوم گراف بنانے کے لیے ورزشیں مکمل کریں۔", roman="Volume graph banane ke liye workouts mukammal karo."),
"Log at least two sessions of an exercise to get a comparison." to UiTranslation(ur="موازنہ حاصل کرنے کے لیے کسی ورزش کے کم از کم دو سیشن لاگ کریں۔", roman="Comparison ke liye kisi exercise ke kam az kam do sessions log karo."),
"Measurements are saved locally on this phone." to UiTranslation(ur="پیمائشیں اسی فون پر مقامی طور پر محفوظ ہیں۔", roman="Measurements isi phone par locally save hain."),
"Export and restore are manual. Import replaces current workout history." to UiTranslation(ur="ایکسپورٹ اور ریسٹور دستی ہیں۔ امپورٹ موجودہ ورزش کی ہسٹری کو تبدیل کر دے گا۔", roman="Export aur restore manual hain. Import maujooda workout history ko replace kar dega."),
"Record in centimetres. Recheck under similar conditions every 2-4 weeks." to UiTranslation(ur="سینٹی میٹر میں ریکارڈ کریں۔ ہر 2-4 ہفتوں میں اسی طرح کے حالات میں دوبارہ چیک کریں۔", roman="Centimetres mein record karo. Har 2-4 hafton mein aisi hi conditions mein dobara check karo."),
"Age 21 · Height 182 cm · Full gym" to UiTranslation(ur="عمر 21 · قد 182 سینٹی میٹر · مکمل جم", roman="Age 21 · Height 182 cm · Full gym"),
"60-90 minutes · Friday rest" to UiTranslation(ur="60-90 منٹ · جمعہ آرام", roman="60-90 minutes · Jumma rest"),
"Current body weight (kg)" to UiTranslation(ur="موجودہ جسمانی وزن (kg)", roman="Maujooda body weight (kg)"),
"Muscle gain" to UiTranslation(ur="مسل گین", roman="Muscle gain"),
"Language" to UiTranslation(ur="زبان", roman="Language"),
"English" to UiTranslation(ur="انگریزی", roman="English"),
"Urdu" to UiTranslation(ur="اردو", roman="Urdu"),
"Roman Urdu" to UiTranslation(ur="رومن اردو", roman="Roman Urdu"),
"Sets" to UiTranslation(ur="سیٹس", roman="Sets"),
"Reps" to UiTranslation(ur="ریپس", roman="Reps"),
"Weight kg" to UiTranslation(ur="وزن kg", roman="Weight kg"),
"Type" to UiTranslation(ur="قسم", roman="Type"),
"RPE 1-10" to UiTranslation(ur="RPE 1-10", roman="RPE 1-10"),
"Exercise notes" to UiTranslation(ur="ورزش کے نوٹس", roman="Exercise notes"),
"Servings / portions" to UiTranslation(ur="سرونگز / حصے", roman="Servings / portions"),
"Sleep hours" to UiTranslation(ur="نیند کے گھنٹے", roman="Neend ke ghantay"),
"Energy 0-5" to UiTranslation(ur="توانائی 0-5", roman="Energy 0-5"),
"Soreness 0-10" to UiTranslation(ur="درد 0-10", roman="Soreness 0-10"),
"Record discomfort or movement to avoid" to UiTranslation(ur="تکلیف یا اس حرکت کو ریکارڈ کریں جس سے بچنا ہے", roman="Takleef ya woh movement record karo jisse bachna hai"),
"Rule-based estimate only, not a medical assessment." to UiTranslation(ur="صرف اصول پر مبنی تخمینہ ہے، طبی جائزہ نہیں۔", roman="Sirf rule-based estimate hai, medical assessment nahi."),
"This week's report" to UiTranslation(ur="اس ہفتے کی رپورٹ", roman="Is haftay ki report"),
"Today's guidance" to UiTranslation(ur="آج کی رہنمائی", roman="Aaj ki guidance"),
        "Play in background" to UiTranslation(ur="پس منظر میں چلائیں", roman="Background mein chalao"),
        "Stop background" to UiTranslation(ur="پس منظر بند کریں", roman="Background band karo"),
        "Background playback uses a foreground service with a notification, so speech keeps going when the screen turns off. Stop it from the notification or here." to UiTranslation(ur="پس منظر میں چلانے کے لیے فورگراؤنڈ سروس اور نوٹیفکیشن استعمال ہوتی ہے، اس لیے اسکرین بند ہونے پر بھی آواز چلتی رہتی ہے۔ نوٹیفکیشن یا یہاں سے بند کریں۔", roman="Background playback foreground service aur notification use karta hai, is liye screen band hone par bhi awaz chalti rehti hai. Notification ya yahan se band karo."),
        "TODAY'S WORKOUT" to UiTranslation(ur="آج کا ورک آؤٹ", roman="Aaj ka workout"),
        "WORKOUT TEMPLATES" to UiTranslation(ur="ورک آؤٹ ٹیمپلیٹس", roman="Workout templates"),
        "Empty workout" to UiTranslation(ur="خالی ورک آؤٹ", roman="Khaali workout"),
        "Copy last workout" to UiTranslation(ur="آخری ورک آؤٹ کاپی کریں", roman="Aakhri workout copy karo"),
        "Empty workout starts with no exercises - add your own from the library. Copy last workout reuses the exercises from your most recent logged day." to UiTranslation(ur="خالی ورک آؤٹ میں کوئی ورزش نہیں ہوتی — لائبریری سے اپنی ورزشیں شامل کریں۔ آخری ورک آؤٹ کاپی کرنے سے آپ کے حالیہ دن کی ورزشیں دوبارہ آ جاتی ہیں۔", roman="Khaali workout mein koi exercise nahi hoti — library se apni exercises add karo. Aakhri workout copy karne se tumhare recent din ki exercises dobara aa jati hain."),
        "Edit sets & reps" to UiTranslation(ur="سیٹس اور ریپس تبدیل کریں", roman="Sets aur reps badlo"),
        "Working sets" to UiTranslation(ur="ورکنگ سیٹس", roman="Working sets"),
        "Rep range e.g. 8–12" to UiTranslation(ur="ریپ رینج مثلاً 8–12", roman="Rep range masalan 8–12"),
        "Create custom exercise" to UiTranslation(ur="اپنی ورزش بنائیں", roman="Apni exercise banao"),
        "Exercise name" to UiTranslation(ur="ورزش کا نام", roman="Exercise ka naam"),
        "Target muscle" to UiTranslation(ur="ہدف پٹھا", roman="Target muscle"),
        "Equipment" to UiTranslation(ur="سامان", roman="Equipment"),
        "Rep range" to UiTranslation(ur="ریپ رینج", roman="Rep range"),
        "Save exercise" to UiTranslation(ur="ورزش محفوظ کریں", roman="Exercise save karo"),
        "★ Favorites" to UiTranslation(ur="★ پسندیدہ", roman="★ Favorites"),
        "Edit today's exercise list" to UiTranslation(ur="آج کی ورزش کی فہرست تبدیل کریں", roman="Aaj ki exercise list badlo"),
        "Sets/reps" to UiTranslation(ur="سیٹس/ریپس", roman="Sets/reps"),
        "Replace" to UiTranslation(ur="تبدیل کریں", roman="Badlo"),
        "WORKOUT TIMER" to UiTranslation(ur="ورک آؤٹ ٹائمر", roman="Workout timer"),
        "REST TIMER" to UiTranslation(ur="آرام کا ٹائمر", roman="Rest timer"),
        "MOVEMENT PREVIEW" to UiTranslation(ur="حرکت کا پیش نظارہ", roman="Movement preview"),
        "Illustrative movement cue, not a verified exercise animation. Use the written cues and demonstration." to UiTranslation(ur="یہ صرف ایک مثالی حرکت ہے، تصدیق شدہ ورزش اینیمیشن نہیں۔ تحریری ہدایات اور مظاہرہ استعمال کریں۔", roman="Ye sirf ek misaali harkat hai, verified exercise animation nahi. Tehreeri hidayat aur demo use karo."),
        "Rest guide: 2–3 min for compound lifts; 60–120 sec for isolation. Keep most sets 1–3 reps in reserve." to UiTranslation(ur="آرام کی رہنمائی: مرکب ورزشوں کے لیے 2–3 منٹ؛ الگ پٹھوں کے لیے 60–120 سیکنڈ۔ زیادہ تر سیٹس میں 1–3 ریپس بچا کر رکھیں۔", roman="Rest guide: compound lifts ke liye 2–3 min; isolation ke liye 60–120 sec. Zyada tar sets mein 1–3 reps reserve mein rakho."),
        "TRAIN SMART · TRACK EVERYTHING" to UiTranslation(ur="ہوشیاری سے ٹریننگ کریں · ہر چیز ٹریک کریں", roman="Hoshiyari se training karo · har cheez track karo"),
        "60–90 minute target · Warm up before working sets" to UiTranslation(ur="60–90 منٹ کا ہدف · ورکنگ سیٹس سے پہلے وارم اپ کریں", roman="60–90 minute ka target · Working sets se pehle warm up karo"),
        "+ Add set" to UiTranslation(ur="+ سیٹ شامل کریں", roman="+ Set add karo"),
        "+ Create" to UiTranslation(ur="+ بنائیں", roman="+ Banao"),
        "+ Add" to UiTranslation(ur="+ شامل کریں", roman="+ Add karo"),
        "Light walk, adequate food, hydration and 7–9 hours of sleep." to UiTranslation(ur="ہلکی چہل قدمی، مناسب کھانا، پانی اور 7–9 گھنٹے نیند۔", roman="Halki walk, munasib khana, pani aur 7–9 ghante neend."),
        "WEIGHT kg" to UiTranslation(ur="وزن kg", roman="Wazan kg"),
        "REPS" to UiTranslation(ur="ریپس", roman="Reps"),
        "BODY WEIGHT — WEEKLY AVERAGE" to UiTranslation(ur="جسمانی وزن — ہفتہ وار اوسط", roman="Body weight — weekly average"),
        "STRENGTH BY EXERCISE" to UiTranslation(ur="ہر ورزش کی طاقت", roman="Har exercise ki taqat"),
        "Share weekly report" to UiTranslation(ur="ہفتہ وار رپورٹ شیئر کریں", roman="Weekly report share karo"),
        "CALORIE TARGET" to UiTranslation(ur="کیلوری ہدف", roman="Calorie target"),
        "ADD YOUR OWN FOOD" to UiTranslation(ur="اپنا کھانا شامل کریں", roman="Apna khana add karo"),
        "Save custom food" to UiTranslation(ur="اپنا کھانا محفوظ کریں", roman="Apna khana save karo"),
        "Custom foods are saved on this phone and appear in the quick-add list. Values are your own estimates." to UiTranslation(ur="اپنے کھانے اس فون پر محفوظ ہوتے ہیں اور فوری شامل کرنے کی فہرست میں آ جاتے ہیں۔ مقداریں آپ کے اپنے اندازے ہیں۔", roman="Custom foods is phone par save hote hain aur quick-add list mein aa jate hain. Values tumhare apne andaze hain."),
        "Weekly average smooths daily water / food swings." to UiTranslation(ur="ہفتہ وار اوسط روزانہ پانی / کھانے کے اتار چڑھاؤ کو ہموار کر دیتی ہے۔", roman="Weekly average rozana pani / khane ke utaar chadhao ko smooth kar deta hai."),
        "Best completed set per session, heaviest first. Dates are month-day." to UiTranslation(ur="ہر سیشن کا بہترین مکمل سیٹ، سب سے بھاری پہلے۔ تاریخیں مہینہ-دن ہیں۔", roman="Har session ka best completed set, sab se bhari pehle. Dates month-day hain."),
        "No completed sets with a numeric weight for this exercise yet." to UiTranslation(ur="اس ورزش کے لیے ابھی کوئی مکمل سیٹ عددی وزن کے ساتھ نہیں ہے۔", roman="Is exercise ke liye abhi koi completed set numeric weight ke sath nahi hai."),
        "Log completed sets to see a per-exercise strength graph." to UiTranslation(ur="ہر ورزش کا طاقت کا گراف دیکھنے کے لیے مکمل سیٹس ریکارڈ کریں۔", roman="Har exercise ka strength graph dekhne ke liye completed sets log karo."),
        "Change your body weight once to start the history. Weekly averages appear after the first week." to UiTranslation(ur="تاریخ شروع کرنے کے لیے اپنا جسمانی وزن ایک بار تبدیل کریں۔ ہفتہ وار اوسط پہلے ہفتے کے بعد ظاہر ہوتی ہے۔", roman="History shuru karne ke liye apna body weight ek baar badlo. Weekly averages pehle hafte ke baad nazar aati hain."),
        "Muscle-gain target: about" to UiTranslation(ur="مسلز بڑھانے کا ہدف: تقریباً", roman="Muscle-gain target: taqreeban"),
    )
}

data class UiTranslation(val ur: String, val roman: String)
data class ExerciseTranslationData(val name: String, val cues: List<String>, val breathing: String, val mistakes: List<String>)
data class ExerciseTranslation(val ur: ExerciseTranslationData, val roman: ExerciseTranslationData)

/** Built-in exercise display-name translations. User-created exercise names remain user-entered. */
object ExerciseLanguages {
    private val urduNames = mapOf(
        "Barbell Bench Press" to "باربل بینچ پریس", "Incline Dumbbell Press" to "انکلائن ڈمبل پریس", "Cable Chest Fly" to "کیبل چیسٹ فلائی",
        "Rope Triceps Pushdown" to "روپ ٹرائی سیپس پش ڈاؤن", "Overhead Cable Extension" to "اوورہیڈ کیبل ایکسٹینشن", "Lat Pulldown" to "لیٹ پل ڈاؤن",
        "Chest Supported Row" to "چیسٹ سپورٹڈ رو", "Single Arm Cable Row" to "سنگل آرم کیبل رو", "Reverse Pec Deck" to "ریورس پیک ڈیک",
        "EZ Bar Curl" to "ای زی بار کرل", "Incline Dumbbell Curl" to "انکلائن ڈمبل کرل", "Dumbbell Shoulder Press" to "ڈمبل شولڈر پریس",
        "Dumbbell Lateral Raise" to "ڈمبل لیٹرل ریز", "Barbell Squat" to "باربل اسکواٹ", "Leg Press" to "لیگ پریس",
        "Lying Leg Curl" to "لائنگ لیگ کرل", "Standing Calf Raise" to "اسٹینڈنگ کاف ریز", "Incline Smith Machine Press" to "انکلائن اسمتھ مشین پریس",
        "Flat Machine Chest Press" to "فلیٹ مشین چیسٹ پریس", "Pec Deck Fly" to "پیک ڈیک فلائی", "Straight Bar Triceps Pushdown" to "اسٹریٹ بار ٹرائی سیپس پش ڈاؤن",
        "Overhead Rope Extension" to "اوورہیڈ روپ ایکسٹینشن", "Pull-ups / Assisted Pull-ups" to "پل اپس / اسسٹڈ پل اپس", "T-Bar Row" to "ٹی بار رو",
        "Straight Arm Pulldown" to "اسٹریٹ آرم پل ڈاؤن", "Cable Rear Delt Fly" to "کیبل ریئر ڈیلٹ فلائی", "Hammer Curl" to "ہیمر کرل", "Preacher Curl" to "پریچر کرل"
    )
    private val romanNames = mapOf(
        "Barbell Bench Press" to "Barbell Bench Press", "Incline Dumbbell Press" to "Incline Dumbbell Press", "Cable Chest Fly" to "Cable Chest Fly",
        "Rope Triceps Pushdown" to "Rope Triceps Pushdown", "Overhead Cable Extension" to "Overhead Cable Extension", "Lat Pulldown" to "Lat Pulldown",
        "Chest Supported Row" to "Chest Supported Row", "Single Arm Cable Row" to "Single Arm Cable Row", "Reverse Pec Deck" to "Reverse Pec Deck",
        "EZ Bar Curl" to "EZ Bar Curl", "Incline Dumbbell Curl" to "Incline Dumbbell Curl", "Dumbbell Shoulder Press" to "Dumbbell Shoulder Press",
        "Dumbbell Lateral Raise" to "Dumbbell Lateral Raise", "Barbell Squat" to "Barbell Squat", "Leg Press" to "Leg Press",
        "Lying Leg Curl" to "Lying Leg Curl", "Standing Calf Raise" to "Standing Calf Raise", "Incline Smith Machine Press" to "Incline Smith Machine Press",
        "Flat Machine Chest Press" to "Flat Machine Chest Press", "Pec Deck Fly" to "Pec Deck Fly", "Straight Bar Triceps Pushdown" to "Straight Bar Triceps Pushdown",
        "Overhead Rope Extension" to "Overhead Rope Extension", "Pull-ups / Assisted Pull-ups" to "Pull-ups / Assisted Pull-ups", "T-Bar Row" to "T-Bar Row",
        "Straight Arm Pulldown" to "Straight Arm Pulldown", "Cable Rear Delt Fly" to "Cable Rear Delt Fly", "Hammer Curl" to "Hammer Curl", "Preacher Curl" to "Preacher Curl"
    )
    /** v3.4.0 — full per-exercise translations: cues, breathing and mistakes in Urdu and Roman Urdu for all 35 built-in exercises. */
    val translations: Map<String, ExerciseTranslation> = mapOf(
"Barbell Bench Press" to ExerciseTranslation(
  ur = ExerciseTranslationData(name="باربل بینچ پریس", cues=listOf("پاؤں زمین پر مضبوطی سے جمائے رکھیں، کندھوں کی ہڈیاں پیچھے کھینچیں", "بار کو قابو کے ساتھ سینے کے درمیان تک نیچے لائیں", "بار کو اچھالے بغیر اوپر کی طرف دھکیلیں"), breathing="نیچے لاتے وقت سانس اندر لیں؛ اوپر دھکیلتے وقت سانس باہر نکالیں", mistakes=listOf("بار کو سینے پر اچھالنا", "کمر کے نچلے حصے کو بہت زیادہ خم کرنا", "کلائیاں پیچھے کی طرف مڑ جانا")),
  roman = ExerciseTranslationData(name="Barbell Bench Press", cues=listOf("Pair zameen par jamayein, kandhe peeche kheenchein", "Bar ko control ke saath mid-chest tak neeche layein", "Bar ko bounce kiye baghair upar press karein"), breathing="Neeche laate waqt saans andar lein; press karte waqt saans bahar nikalein", mistakes=listOf("Bar ko chest par bounce karna", "Kamar ke neeche hisse ko zyada arch karna", "Kalaaiyan peeche ki taraf mud jana"))
),
"Incline Dumbbell Press" to ExerciseTranslation(
  ur = ExerciseTranslationData(name="انکلائن ڈمبل پریس", cues=listOf("بینچ کو درمیانے درجے کی ڈھلان پر سیٹ کریں", "ڈمبلز کو اوپری سینے کے برابر نیچے لائیں", "کلائیاں سیدھی رکھتے ہوئے اوپر کی طرف دھکیلیں"), breathing="نیچے لاتے وقت سانس اندر لیں؛ اوپر دھکیلتے وقت سانس باہر نکالیں", mistakes=listOf("بینچ کا بہت زیادہ اونچا ہونا", "ڈمبلز کا آپس میں ٹکرانا")),
  roman = ExerciseTranslationData(name="Incline Dumbbell Press", cues=listOf("Bench ko moderate incline par set karein", "Dumbbells ko upper chest ke paas neeche layein", "Kalaaiyan seedhi rakhte hue upar press karein"), breathing="Neeche laate waqt saans andar lein; upar press karte waqt saans bahar nikalein", mistakes=listOf("Bench ka bohat zyada steep hona", "Dumbbells ka aapas mein takrana"))
),
"Cable Chest Fly" to ExerciseTranslation(
  ur = ExerciseTranslationData(name="کیبل چیسٹ فلائی", cues=listOf("کہنیوں میں ہلکی سی خم رکھیں", "ہاتھوں کو چوڑے دائرے میں ایک ساتھ لائیں", "سینے کے کھنچنے تک آہستہ آہستہ واپس جائیں"), breathing="جب ہاتھ ایک ساتھ آئیں تو سانس باہر نکالیں", mistakes=listOf("اسے پریس بنا لینا", "جھٹکے یا مومینٹم کا استعمال کرنا")),
  roman = ExerciseTranslationData(name="Cable Chest Fly", cues=listOf("Kohniyon mein halki si bend rakhein", "Haathon ko wide arc mein ek saath layein", "Seene ke stretch hone tak aahista wapas jayein"), breathing="Jab haath ek saath aayein to saans bahar nikalein", mistakes=listOf("Ise press bana lena", "Momentum ka istemal karna"))
),
"Rope Triceps Pushdown" to ExerciseTranslation(
  ur = ExerciseTranslationData(name="روپ ٹرائسپس پش ڈاؤن", cues=listOf("کہنیاں جسم کے قریب رکھیں", "کہنیاں سیدھی ہونے تک بازو سیدھے کریں", "نیچے پہنچ کر رسی کے سرے ہلکے سے الگ کریں"), breathing="بازو سیدھے کرتے وقت سانس باہر نکالیں", mistakes=listOf("کندھے جھولانا", "کہنیاں آگے کی طرف سرکنا")),
  roman = ExerciseTranslationData(name="Rope Triceps Pushdown", cues=listOf("Kohniyan jism ke qareeb rakhein", "Kohniyan seedhi hone tak baazu seedhe karein", "Neeche pohanch kar rope ke ends halke se alag karein"), breathing="Baazu seedhe karte waqt saans bahar nikalein", mistakes=listOf("Kandhe jhulana", "Kohniyan aage ki taraf sarakna"))
),
"Overhead Cable Extension" to ExerciseTranslation(
  ur = ExerciseTranslationData(name="اوور ہیڈ کیبل ایکسٹینشن", cues=listOf("کیبل سے پیٹھ کر کے کھڑے ہوں", "اوپری بازو سر کے اوپر مستحکم رکھیں", "کمر کو خم کیے بغیر کہنیاں سیدھی کریں"), breathing="بازو سیدھے کرتے وقت سانس باہر نکالیں", mistakes=listOf("پسلیاں باہر نکالنا", "اوپری بازوؤں کو بہت زیادہ ہلانا")),
  roman = ExerciseTranslationData(name="Overhead Cable Extension", cues=listOf("Cable se peeth kar ke khade hon", "Upar wale baazu sar ke upar steady rakhein", "Kamar ko arch kiye baghair kohniyan seedhi karein"), breathing="Baazu seedhe karte waqt saans bahar nikalein", mistakes=listOf("Pasliyan bahar nikalna", "Upar wale baazuon ko zyada hilana"))
),
"Lat Pulldown" to ExerciseTranslation(
  ur = ExerciseTranslationData(name="لیٹ پل ڈاؤن", cues=listOf("کندھوں سے تھوڑی چوڑی گرفت پکڑیں", "بار کو اوپری سینے کی طرف کھینچیں", "واپسی کو قابو کے ساتھ سر کے اوپر تک کریں"), breathing="نیچے کھینچتے وقت سانس باہر نکالیں", mistakes=listOf("بار کو گردن کے پیچھے کھینچنا", "وزن اٹھانے کے لیے جسم کو جھولانا")),
  roman = ExerciseTranslationData(name="Lat Pulldown", cues=listOf("Kandhon se thodi wide grip pakrein", "Bar ko upper chest ki taraf kheenchein", "Wapsi ko control ke saath sar ke upar tak karein"), breathing="Neeche kheench te waqt saans bahar nikalein", mistakes=listOf("Bar ko gardan ke peeche kheenchna", "Wazan uthane ke liye torso ko jhulana"))
),
"Chest Supported Row" to ExerciseTranslation(
  ur = ExerciseTranslationData(name="چیسٹ سپورٹڈ رو", cues=listOf("سینہ پیڈ سے لگائے رکھیں", "کہنیاں پیچھے کی طرف کھینچیں", "لمحہ بھر رکیں؛ پھر آہستہ آہستہ نیچے لائیں"), breathing="رو کرتے وقت سانس باہر نکالیں", mistakes=listOf("سینہ پیڈ سے اٹھانا", "کندھے اٹھانا")),
  roman = ExerciseTranslationData(name="Chest Supported Row", cues=listOf("Seena pad se lagaye rakhein", "Kohniyan peeche ki taraf kheenchein", "Lamha bhar rukhein; phir aahista neeche layein"), breathing="Row karte waqt saans bahar nikalein", mistakes=listOf("Seena pad se uthana", "Kandhe uthana"))
),
"Single Arm Cable Row" to ExerciseTranslation(
  ur = ExerciseTranslationData(name="سنگل آرم کیبل رو", cues=listOf("جسم کو مضبوطی سے سنبھالیں", "کہنی کو کولہے کی طرف کھینچیں", "قابو کے ساتھ آگے تک پہنچنے دیں"), breathing="کھینچتے وقت سانس باہر نکالیں", mistakes=listOf("جسم کو گھمانا", "مومینٹم کا استعمال کرنا")),
  roman = ExerciseTranslationData(name="Single Arm Cable Row", cues=listOf("Torso ko mazbooti se brace karein", "Kohni ko hip ki taraf kheenchein", "Control ke saath aage tak reach karne dein"), breathing="Kheench te waqt saans bahar nikalein", mistakes=listOf("Torso ko ghumana", "Momentum ka istemal karna"))
),
"Reverse Pec Deck" to ExerciseTranslation(
  ur = ExerciseTranslationData(name="ریورس پیک ڈیک", cues=listOf("ہینڈلز کو کندھے کی اونچائی کے برابر سیٹ کریں", "کہنیوں میں نرمی کے ساتھ بازو کھولیں", "کندھے اٹھائے بغیر رکیں"), breathing="جب بازو کھلیں تو سانس باہر نکالیں", mistakes=listOf("کمر کے نچلے حصے کو بہت زیادہ خم کرنا", "کندھے اٹھانا")),
  roman = ExerciseTranslationData(name="Reverse Pec Deck", cues=listOf("Handles ko shoulder height ke barabar set karein", "Kohniyon mein halki narmi ke saath baazu kholein", "Kandhe uthaye baghair rukhein"), breathing="Jab baazu khulein to saans bahar nikalein", mistakes=listOf("Kamar ke neeche hisse ko zyada arch karna", "Kandhe uthana"))
),
"EZ Bar Curl" to ExerciseTranslation(
  ur = ExerciseTranslationData(name="ای زی بار کرل", cues=listOf("کہنیاں جسم کے قریب رکھیں", "بغیر جھولے کرل کریں", "مکمل طور پر قابو کے ساتھ نیچے لائیں"), breathing="کرل کرتے وقت سانس باہر نکالیں", mistakes=listOf("جسم کو جھولانا", "کہنیاں آگے کی طرف لے جانا")),
  roman = ExerciseTranslationData(name="EZ Bar Curl", cues=listOf("Kohniyan torso ke qareeb rakhein", "Baghair jhule curl karein", "Mukammal tor par control ke saath neeche layein"), breathing="Curl karte waqt saans bahar nikalein", mistakes=listOf("Jism ko jhulana", "Kohniyan aage ki taraf le jana"))
),
"Incline Dumbbell Curl" to ExerciseTranslation(
  ur = ExerciseTranslationData(name="انکلائن ڈمبل کرل", cues=listOf("اوپری کمر بینچ پر رکھیں", "بازو قدرتی طور پر لٹکنے دیں", "کہنیاں آگے بڑھائے بغیر کرل کریں"), breathing="کرل کرتے وقت سانس باہر نکالیں", mistakes=listOf("مومینٹم کا استعمال کرنا", "نیچے کی حد کو کم کرنا")),
  roman = ExerciseTranslationData(name="Incline Dumbbell Curl", cues=listOf("Upar wali kamar bench par rakhein", "Baazu qudrati tor par latakne dein", "Kohniyan aage badhaye baghair curl karein"), breathing="Curl karte waqt saans bahar nikalein", mistakes=listOf("Momentum ka istemal karna", "Neeche ki range ko chhota karna"))
),
"Dumbbell Shoulder Press" to ExerciseTranslation(
  ur = ExerciseTranslationData(name="ڈمبل شولڈر پریس", cues=listOf("کور کو مضبوط کریں اور پسلیاں نیچے رکھیں", "آرام دہ راستے میں سر کے اوپر دھکیلیں", "کندھے کی سطح تک نیچے لائیں"), breathing="اوپر دھکیلتے وقت سانس باہر نکالیں", mistakes=listOf("کمر کو بہت زیادہ خم کرنا", "درد والی حد میں دھکیلنا")),
  roman = ExerciseTranslationData(name="Dumbbell Shoulder Press", cues=listOf("Core ko brace karein aur pasliyan neeche rakhein", "Aaram deh raaste mein sar ke upar press karein", "Kandhe ki level tak neeche layein"), breathing="Upar press karte waqt saans bahar nikalein", mistakes=listOf("Kamar ko zyada arch karna", "Dard wali range mein press karna"))
),
"Dumbbell Lateral Raise" to ExerciseTranslation(
  ur = ExerciseTranslationData(name="ڈمبل لیٹرل ریز", cues=listOf("کہنیاں نرم رکھیں اور تھوڑا سا آگے جھکیں", "بازوؤں کو اطراف میں اٹھائیں", "کندھوں کی اونچائی کے قریب رک جائیں"), breathing="اٹھاتے ہوئے سانس باہر نکالیں", mistakes=listOf("وزن جھٹک کر اٹھانا", "کندھے اوپر چڑھانا")),
  roman = ExerciseTranslationData(name="Dumbbell Lateral Raise", cues=listOf("Kehniyan naram rakhein aur thora sa aagay jhukein", "Bazooon ko sides mein uthayein", "Kandhon ki unchai ke qareeb ruk jayein"), breathing="Uthate hue saans bahar nikalein", mistakes=listOf("Wazan jhatak kar uthana", "Kandhe upar charhana"))
),
"Barbell Squat" to ExerciseTranslation(
  ur = ExerciseTranslationData(name="باربل اسکواٹ", cues=listOf("نیچے جانے سے پہلے پیٹ کو مضبوطی سے کس لیں", "پورا پاؤں زمین پر جما کر رکھیں", "جتنا کنٹرول اور لچک اجازت دے اتنا نیچے جائیں", "پاؤں کے درمیانی حصے سے زور لگا کر اوپر اٹھیں"), breathing="نیچے جاتے ہوئے سانس اندر لیں اور پیٹ کسیں؛ اوپر اٹھتے ہوئے سانس باہر نکالیں", mistakes=listOf("ایڑیاں اٹھنا", "گھٹنوں کا اندر کی طرف جھکنا", "پیٹ کی گرفت چھوٹ جانا")),
  roman = ExerciseTranslationData(name="Barbell Squat", cues=listOf("Neeche jaane se pehle pait ko mazbooti se kas lein", "Poora paon zameen par jama kar rakhein", "Jitna control aur lachak ijazat de utna neeche jayein", "Paon ke darmiyani hisse se zor laga kar upar uthein"), breathing="Neeche jaate hue saans andar lein aur pait kasein; upar uthte hue saans bahar nikalein", mistakes=listOf("Aidiyan uthna", "Ghutnon ka andar ki taraf jhukna", "Pait ki giraft chhoot jaana"))
),
"Leg Press" to ExerciseTranslation(
  ur = ExerciseTranslationData(name="لیگ پریس", cues=listOf("پاؤں کندھوں کی چوڑائی کے برابر رکھیں", "کولہوں کو سہارا دیے ہوئے سلیڈ نیچے لائیں", "گھٹنے سختی سے لاک کیے بغیر دھکیلیں"), breathing="نیچے جاتے ہوئے سانس اندر لیں؛ اوپر جاتے ہوئے سانس باہر نکالیں", mistakes=listOf("کمر کا نیچے سے گول ہونا", "گھٹنوں کا اندر کی طرف جھکنا")),
  roman = ExerciseTranslationData(name="Leg Press", cues=listOf("Paon kandhon ki chorai ke barabar rakhein", "Koolhon ko sahara diye hue sled neeche layein", "Ghutne sakhti se lock kiye baghair dhakelein"), breathing="Neeche jaate hue saans andar lein; upar jaate hue saans bahar nikalein", mistakes=listOf("Kamar ka neeche se gol hona", "Ghutnon ka andar ki taraf jhukna"))
),
"Lying Leg Curl" to ExerciseTranslation(
  ur = ExerciseTranslationData(name="لائینگ لیگ کرل", cues=listOf("گھٹنوں کو مشین کے محور کے ساتھ سیدھ میں رکھیں", "ایڑیوں کو کولہوں کی طرف موڑیں", "آہستہ سے نیچے لائیں"), breathing="موڑتے ہوئے سانس باہر نکالیں", mistakes=listOf("کولہوں کا اٹھنا", "وزن تیزی سے چھوڑ دینا")),
  roman = ExerciseTranslationData(name="Lying Leg Curl", cues=listOf("Ghutnon ko machine ke mehwar ke saath seedh mein rakhein", "Aidiyon ko koolhon ki taraf modein", "Aahista se neeche layein"), breathing="Modte hue saans bahar nikalein", mistakes=listOf("Koolhon ka uthna", "Wazan tezi se chhod dena"))
),
"Standing Calf Raise" to ExerciseTranslation(
  ur = ExerciseTranslationData(name="اسٹینڈنگ کاف ریز", cues=listOf("آرام دہ مکمل رینج استعمال کریں", "نیچے کھنچاؤ والی پوزیشن میں تھوڑا رکیں", "پاؤں کے اگلے حصے پر اوپر اٹھیں"), breathing="اوپر اٹھتے ہوئے سانس باہر نکالیں", mistakes=listOf("اچھلنا", "بہت چھوٹی آدھی حرکت کرنا")),
  roman = ExerciseTranslationData(name="Standing Calf Raise", cues=listOf("Aaram deh mukammal range istemal karein", "Neeche khinchao wali position mein thora rukein", "Paon ke agle hisse par upar uthein"), breathing="Upar uthte hue saans bahar nikalein", mistakes=listOf("Uchhalna", "Bohat chhoti aadhi harkat karna"))
),
"Incline Smith Machine Press" to ExerciseTranslation(
  ur = ExerciseTranslationData(name="انکلائن اسمتھ مشین پریس", cues=listOf("بینچ کو بار کے راستے کے نیچے رکھیں", "بار کو اوپری سینے کی طرف نیچے لائیں", "بغیر جھٹکے کے آسانی سے دھکیلیں"), breathing="نیچے جاتے ہوئے سانس اندر لیں؛ اوپر جاتے ہوئے سانس باہر نکالیں", mistakes=listOf("بینچ کا بہت آگے یا پیچھے ہونا", "بار کو سینے سے اچھالنا")),
  roman = ExerciseTranslationData(name="Incline Smith Machine Press", cues=listOf("Bench ko bar ke raaste ke neeche rakhein", "Bar ko upri seene ki taraf neeche layein", "Baghair jhatke ke aasani se dhakelein"), breathing="Neeche jaate hue saans andar lein; upar jaate hue saans bahar nikalein", mistakes=listOf("Bench ka bohat aagay ya peeche hona", "Bar ko seene se uchhalna"))
),
"Flat Machine Chest Press" to ExerciseTranslation(
  ur = ExerciseTranslationData(name="فلیٹ مشین چیسٹ پریس", cues=listOf("ہینڈلز کو سینے کے درمیان کے برابر رکھیں", "کندھوں کے پٹھوں کو سہارے پر رکھیں", "دھکیلیں اور آہستہ سے واپس لائیں"), breathing="دھکیلتے ہوئے سانس باہر نکالیں", mistakes=listOf("کندھوں کا آگے کی طرف لڑھکنا", "کہنیوں کو زور سے لاک کرنا")),
  roman = ExerciseTranslationData(name="Flat Machine Chest Press", cues=listOf("Handles ko seene ke darmiyan ke barabar rakhein", "Kandhon ke pathon ko sahare par rakhein", "Dhakelein aur aahista se wapas layein"), breathing="Dhakelte hue saans bahar nikalein", mistakes=listOf("Kandhon ka aagay ki taraf ladhakna", "Kehniyon ko zor se lock karna"))
),
"Pec Deck Fly" to ExerciseTranslation(
  ur = ExerciseTranslationData(name="پیک ڈیک فلائی", cues=listOf("کہنیوں اور ہینڈلز کو آرام دہ پوزیشن میں رکھیں", "بازوؤں کو کنٹرول شدہ قوس میں ایک ساتھ لائیں", "جب تک سینے میں کھنچاؤ نہ آئے واپس جائیں"), breathing="بند کرتے ہوئے سانس باہر نکالیں", mistakes=listOf("حد سے زیادہ کھنچاؤ", "جھٹکے سے کام لینا")),
  roman = ExerciseTranslationData(name="Pec Deck Fly", cues=listOf("Kehniyon aur handles ko aaram deh position mein rakhein", "Bazooon ko control shuda qaus mein ek saath layein", "Jab tak seene mein khinchao na aaye wapas jayein"), breathing="Band karte hue saans bahar nikalein", mistakes=listOf("Hadd se zyada khinchao", "Jhatke se kaam lena"))
),
"Straight Bar Triceps Pushdown" to ExerciseTranslation(
  ur = ExerciseTranslationData(name="اسٹریٹ بار ٹرائسپس پش ڈاؤن", cues=listOf("کہنیوں کو جسم کے ساتھ چپکا کر رکھیں", "کہنیوں کو مکمل سیدھا کریں", "آہستہ سے واپس لائیں"), breathing="سیدھا کرتے ہوئے سانس باہر نکالیں", mistakes=listOf("جسم کا وزن بار پر ڈالنا", "کہنیوں کا حرکت کرنا")),
  roman = ExerciseTranslationData(name="Straight Bar Triceps Pushdown", cues=listOf("Kehniyon ko jism ke saath chipka kar rakhein", "Kehniyon ko mukammal seedha karein", "Aahista se wapas layein"), breathing="Seedha karte hue saans bahar nikalein", mistakes=listOf("Jism ka wazan bar par daalna", "Kehniyon ka harkat karna"))
),
"Overhead Rope Extension" to ExerciseTranslation(
  ur = ExerciseTranslationData(name="اوورہیڈ روپ ایکسٹینشن", cues=listOf("اوپری بازوؤں کو آگے/اوپر کی طرف رکھیں", "کنٹرول شدہ کھنچاؤ کے لیے کہنیاں موڑیں", "کمر کو خم کیے بغیر سیدھا کریں"), breathing="سیدھا کرتے ہوئے سانس باہر نکالیں", mistakes=listOf("پسلیوں کا باہر نکلنا", "کندھوں کا حرکت کرنا")),
  roman = ExerciseTranslationData(name="Overhead Rope Extension", cues=listOf("Upri bazooon ko aagay/upar ki taraf rakhein", "Control shuda khinchao ke liye kehniyan modein", "Kamar ko kham kiye baghair seedha karein"), breathing="Seedha karte hue saans bahar nikalein", mistakes=listOf("Pasliyon ka bahar nikalna", "Kandhon ka harkat karna"))
),
"Pull-ups / Assisted Pull-ups" to ExerciseTranslation(
  ur = ExerciseTranslationData(name="پل اپس / اسسٹڈ پل اپس", cues=listOf("کنٹرول شدہ لٹک سے شروع کریں", "سینے کو بار کی طرف کھینچیں", "بغیر گرے نیچے آئیں"), breathing="کھینچتے ہوئے سانس باہر نکالیں", mistakes=listOf("جھٹکے یا جھولے سے اٹھنا", "آدھی حرکت کرنا")),
  roman = ExerciseTranslationData(name="Pull-ups / Assisted Pull-ups", cues=listOf("Control shuda latak se shuru karein", "Seene ko bar ki taraf kheenchein", "Baghair giray neeche aayein"), breathing="Kheenchate hue saans bahar nikalein", mistakes=listOf("Jhatke ya jhoolay se uthna", "Aadhi harkat karna"))
),
"T-Bar Row" to ExerciseTranslation(
  ur = ExerciseTranslationData(name="ٹی بار رو", cues=listOf("دھڑ کو مضبوط رکھیں اور ریڑھ کی ہڈی سیدھی رکھیں", "ہینڈل کو نچلے سینے کی طرف کھینچیں", "کنٹرول کے ساتھ نیچے لائیں"), breathing="کھینچتے ہوئے سانس باہر نکالیں", mistakes=listOf("کمر کا گول ہونا", "دھڑ کو جھٹکا دینا")),
  roman = ExerciseTranslationData(name="T-Bar Row", cues=listOf("Dhad ko mazboot rakhein aur reedh ki haddi seedhi rakhein", "Handle ko nichle seene ki taraf kheenchein", "Control ke saath neeche layein"), breathing="Kheenchate hue saans bahar nikalein", mistakes=listOf("Kamar ka gol hona", "Dhad ko jhatka dena"))
),
"Straight Arm Pulldown" to ExerciseTranslation(
  ur = ExerciseTranslationData(name="اسٹریٹ آرم پل ڈاؤن", cues=listOf("کہنیاں ہلکی سی مڑی رکھیں", "بار کو رانوں کی طرف کھینچیں", "واپسی اوپر جاتے ہوئے کنٹرول رکھیں"), breathing="نیچے کھینچتے ہوئے سانس باہر نکالیں", mistakes=listOf("کہنیاں موڑ کر اسے ٹرائسپس پش ڈاؤن بنا دینا", "ضرورت سے زیادہ آگے جھکنا")),
  roman = ExerciseTranslationData(name="Straight Arm Pulldown", cues=listOf("Kohniyaan halki si muri rakhein", "Bar ko raanon ki taraf kheenchein", "Wapsi upar jaate hue control rakhein"), breathing="Neeche kheenchate hue saans bahar nikaalein", mistakes=listOf("Kohniyaan mor kar isay triceps pushdown bana dena", "Zaroorat se zyada aage jhukna"))
),
"Cable Rear Delt Fly" to ExerciseTranslation(
  ur = ExerciseTranslationData(name="کیبل ریئر ڈیلٹ فلائی", cues=listOf("اگر آرام دہ لگے تو کراس کیبل استعمال کریں", "بازوؤں کو باہر کی طرف لے جائیں", "ٹریپس کو ڈھیلا رکھیں"), breathing="کھولتے ہوئے سانس باہر نکالیں", mistakes=listOf("کندھے اوپر اٹھانا", "جھٹکے سے حرکت کرنا")),
  roman = ExerciseTranslationData(name="Cable Rear Delt Fly", cues=listOf("Agar aaram deh lage to cross cable istemal karein", "Baazuon ko bahar ki taraf le jaayein", "Traps ko dheela rakhein"), breathing="Kholte hue saans bahar nikaalein", mistakes=listOf("Kandhe upar uthana", "Jhatke se harkat karna"))
),
"Hammer Curl" to ExerciseTranslation(
  ur = ExerciseTranslationData(name="ہیمر کرل", cues=listOf("ہتھیلیاں ایک دوسرے کی طرف رکھیں", "بغیر جھولے کرل کریں", "آہستہ نیچے لائیں"), breathing="کرل کرتے ہوئے سانس باہر نکالیں", mistakes=listOf("جسم کو جھولانا", "کلائیاں موڑنا")),
  roman = ExerciseTranslationData(name="Hammer Curl", cues=listOf("Hatheliyaan ek dusre ki taraf rakhein", "Baghair jhoole curl karein", "Aahista neeche laayein"), breathing="Curl karte hue saans bahar nikaalein", mistakes=listOf("Jism ko jhulana", "Kalaiyaan morna"))
),
"Preacher Curl" to ExerciseTranslation(
  ur = ExerciseTranslationData(name="پریچر کرل", cues=listOf("بازوؤں کا اوپری حصہ پیڈ پر رکھیں", "آرام دہ حد تک کرل کریں", "کہنی کو جھٹکے سے سیدھا کیے بغیر نیچے لائیں"), breathing="کرل کرتے ہوئے سانس باہر نکالیں", mistakes=listOf("کہنیاں پیڈ سے اٹھانا", "نیچے جھٹکے سے گرانا")),
  roman = ExerciseTranslationData(name="Preacher Curl", cues=listOf("Baazuon ka upri hissa pad par rakhein", "Aaram deh had tak curl karein", "Kohni ko jhatke se seedha kiye baghair neeche laayein"), breathing="Curl karte hue saans bahar nikaalein", mistakes=listOf("Kohniyaan pad se uthana", "Neeche jhatke se girana"))
),
"Machine Shoulder Press" to ExerciseTranslation(
  ur = ExerciseTranslationData(name="مشین شولڈر پریس", cues=listOf("سیٹ اس طرح ایڈجسٹ کریں کہ ہینڈل کندھوں کے قریب سے شروع ہوں", "کمر کو پیڈ سے لگا کر سہارا لیں", "اوپر آسانی سے دھکیلیں"), breathing="دھکیلتے ہوئے سانس باہر نکالیں", mistakes=listOf("کمر کو زیادہ خم کرنا", "کندھے اوپر اٹھانا")),
  roman = ExerciseTranslationData(name="Machine Shoulder Press", cues=listOf("Seat is tarah adjust karein ke handle kandhon ke qareeb se shuru hon", "Kamar ko pad se laga kar sahara lein", "Upar aasani se dhakelein"), breathing="Dhakelte hue saans bahar nikaalein", mistakes=listOf("Kamar ko zyada kham karna", "Kandhe upar uthana"))
),
"Cable Lateral Raise" to ExerciseTranslation(
  ur = ExerciseTranslationData(name="کیبل لیٹرل ریز", cues=listOf("نچلی پلی کے ساتھ سائیڈ سے کھڑے ہوں", "بازو کو سائیڈ کی طرف اوپر اٹھائیں", "آہستہ نیچے لائیں"), breathing="اٹھاتے ہوئے سانس باہر نکالیں", mistakes=listOf("دھڑ کو جھولانا", "کندھے اوپر اٹھانا")),
  roman = ExerciseTranslationData(name="Cable Lateral Raise", cues=listOf("Nichli pulley ke saath side se khade hon", "Baazu ko side ki taraf upar uthayein", "Aahista neeche laayein"), breathing="Uthate hue saans bahar nikaalein", mistakes=listOf("Dhar ko jhulana", "Kandhe upar uthana"))
),
"Romanian Deadlift" to ExerciseTranslation(
  ur = ExerciseTranslationData(name="رومینین ڈیڈ لفٹ", cues=listOf("گھٹنے ہلکے سے موڑیں اور کور کو سخت کریں", "کولہوں کو پیچھے دھکیلیں؛ وزن جسم کے قریب رکھیں", "جب ہیمسٹرنگ مزید جھکنے نہ دے تو رک جائیں", "کولہوں کو آگے دھکیل کر کھڑے ہوں"), breathing="نیچے جاتے ہوئے سانس اندر لے کر کور کو سخت کریں؛ کھڑے ہوتے ہوئے سانس باہر نکالیں", mistakes=listOf("ہنج کی بجائے اسکواٹ کرنا", "کمر کے نچلے حصے کو گول کرنا", "وزن کا جسم سے دور چلے جانا")),
  roman = ExerciseTranslationData(name="Romanian Deadlift", cues=listOf("Ghutne halke se modein aur core ko sakht karein", "Koolhon ko peeche dhakelein; wazan jism ke qareeb rakhein", "Jab hamstring mazeed jhukne na de to ruk jaayein", "Koolhon ko aage dhakel kar khade hon"), breathing="Neeche jaate hue saans andar le kar core ko sakht karein; khade hote hue saans bahar nikaalein", mistakes=listOf("Hinge ki bajaye squat karna", "Kamar ke nichle hisse ko gol karna", "Wazan ka jism se door chale jana"))
),
"Bulgarian Split Squat" to ExerciseTranslation(
  ur = ExerciseTranslationData(name="بلغارین اسپلٹ اسکواٹ", cues=listOf("پچھلا پاؤں مستحکم بینچ پر رکھیں", "کنٹرول کے ساتھ نیچے جائیں", "اگلا پاؤں مکمل طور پر زمین پر رکھیں"), breathing="نیچے جاتے ہوئے سانس اندر لیں؛ اوپر آتے ہوئے سانس باہر نکالیں", mistakes=listOf("اگلی ایڑی کا اٹھ جانا", "جلدی کرنے سے توازن کھو دینا")),
  roman = ExerciseTranslationData(name="Bulgarian Split Squat", cues=listOf("Pichla paaon mustahkam bench par rakhein", "Control ke saath neeche jaayein", "Agla paaon mukammal tor par zameen par rakhein"), breathing="Neeche jaate hue saans andar lein; upar aate hue saans bahar nikaalein", mistakes=listOf("Agli aedi ka uth jana", "Jaldi karne se tawazun kho dena"))
),
"Leg Extension" to ExerciseTranslation(
  ur = ExerciseTranslationData(name="لیگ ایکسٹینشن", cues=listOf("گھٹنے کو مشین کے محور کے ساتھ سیدھا رکھیں", "ٹانگیں آسانی سے سیدھی کریں", "اسٹیک کو زور سے گرائے بغیر نیچے لائیں"), breathing="سیدھا کرتے ہوئے سانس باہر نکالیں", mistakes=listOf("زور سے لات مارنا", "مشین کی غلط ایڈجسٹمنٹ")),
  roman = ExerciseTranslationData(name="Leg Extension", cues=listOf("Ghutne ko machine ke mehwar ke saath seedha rakhein", "Taangein aasani se seedhi karein", "Stack ko zor se giraye baghair neeche laayein"), breathing="Seedha karte hue saans bahar nikaalein", mistakes=listOf("Zor se laat maarna", "Machine ki ghalat adjustment"))
),
"Seated Leg Curl" to ExerciseTranslation(
  ur = ExerciseTranslationData(name="سیٹڈ لیگ کرل", cues=listOf("تھائی پیڈ کو مضبوطی سے سیٹ کریں", "ایڑیوں کو نیچے/پیچھے کی طرف کرل کریں", "آہستہ واپس لائیں"), breathing="کرل کرتے ہوئے سانس باہر نکالیں", mistakes=listOf("کولہے اٹھانا", "نیچے لاتے ہوئے جلدی کرنا")),
  roman = ExerciseTranslationData(name="Seated Leg Curl", cues=listOf("Thigh pad ko mazbooti se set karein", "Aidiyon ko neeche/peeche ki taraf curl karein", "Aahista wapas laayein"), breathing="Curl karte hue saans bahar nikaalein", mistakes=listOf("Koolhe uthana", "Neeche laate hue jaldi karna"))
),
"Seated Calf Raise" to ExerciseTranslation(
  ur = ExerciseTranslationData(name="سیٹڈ کاف ریز", cues=listOf("پاؤں کا اگلا حصہ پلیٹ فارم پر رکھیں", "کنٹرول کے ساتھ کھچاؤ کے لیے ایڑیاں نیچے لائیں", "ایڑیاں اوپر اٹھائیں اور رک جائیں"), breathing="اوپر اٹھاتے ہوئے سانس باہر نکالیں", mistakes=listOf("اچھلنا", "آدھی رینج کرنا")),
  roman = ExerciseTranslationData(name="Seated Calf Raise", cues=listOf("Paaon ka agla hissa platform par rakhein", "Control ke saath khinchao ke liye aidiyaan neeche laayein", "Aidiyaan upar uthayein aur ruk jaayein"), breathing="Upar uthate hue saans bahar nikaalein", mistakes=listOf("Uchhalna", "Aadhi range karna"))
)
    )
    fun name(name: String, language: String): String = when (language) {
        AppLanguage.UR -> translations[name]?.ur?.name ?: urduNames[name] ?: name
        AppLanguage.ROMAN -> translations[name]?.roman?.name ?: romanNames[name] ?: name
        else -> name
    }
    /** Translated instruction data for an exercise, or null (caller falls back to the English source). */
    fun localized(e: Exercise, language: String): ExerciseTranslationData? = when (language) {
        AppLanguage.UR -> translations[e.name]?.ur
        AppLanguage.ROMAN -> translations[e.name]?.roman
        else -> null
    }
    fun cues(e: Exercise, language: String): List<String> = localized(e, language)?.cues ?: e.cues
    fun breathing(e: Exercise, language: String): String = localized(e, language)?.breathing ?: e.breathing
    fun mistakes(e: Exercise, language: String): List<String> = localized(e, language)?.mistakes ?: e.mistakes
    fun explanation(e: Exercise, language: String): String {
        val title = name(e.name, language)
        val c = cues(e, language)
        val b = breathing(e, language)
        val m = mistakes(e, language)
        return when (language) {
            AppLanguage.UR -> "$title۔ ${c.joinToString("۔ ")}۔ سانس: $b عام غلطیاں: ${m.joinToString("، ")}"
            AppLanguage.ROMAN -> "$title. ${c.joinToString(". ")}. Saans: $b Aam ghaltiyan: ${m.joinToString(", ")}"
            else -> "$title. ${e.cues.joinToString(". ")}. Breathing: ${e.breathing} Common mistakes: ${e.mistakes.joinToString(", ")}"
        }
    }
}
