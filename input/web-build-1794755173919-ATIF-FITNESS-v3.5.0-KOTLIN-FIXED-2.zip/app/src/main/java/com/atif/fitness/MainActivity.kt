package com.atif.fitness

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.media.AudioManager
import android.media.ToneGenerator
import java.util.Locale
import androidx.compose.ui.viewinterop.AndroidView
import android.os.VibrationEffect
import android.os.Vibrator
import android.content.Context
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import android.graphics.BitmapFactory
import android.graphics.drawable.Animatable as DrawableAnimatable
import coil.ImageLoader
import coil.decode.GifDecoder
import coil.compose.AsyncImage
import android.widget.ImageView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.TextStyle
import androidx.compose.material3.LocalTextStyle
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray
import org.json.JSONObject

private val Bg = Color(0xFF101411)
private val Panel = Color(0xFF1A211D)
private val Green = Color(0xFF75E0A0)
private val Muted = Color(0xFF9AA79F)

class MainActivity : ComponentActivity() {
    var speech: TextToSpeech? = null
    var ttsReady = false
    var ttsStatus by mutableStateOf("")
    var speechSpeed by mutableFloatStateOf(1.0f)
    private var speechSentences: List<String> = emptyList()
    private var speechSentenceIndex: Int = 0
    private var speechLanguage: String = AppLanguage.EN
    private var speechGeneration: Int = 0
    var keepSpeechOnExit: Boolean = false
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        speech = TextToSpeech(this) { status ->
            ttsReady = status == TextToSpeech.SUCCESS
            if (!ttsReady) ttsStatus = "Text-to-speech engine could not initialise."
        }
        setContent { AtifFitnessApp(this) }
    }
    fun speak(text: String, language: String) {
        speechSentences = text.split(Regex("(?<=[.!?۔])\\s+")).filter { it.isNotBlank() }
        speechSentenceIndex = 0
        speechLanguage = language
        speechGeneration++
        speakCurrentSentence()
    }
    private fun speakCurrentSentence() {
        val engine = speech ?: return
        if (!ttsReady) { ttsStatus = "Text-to-speech is not ready. Check the device TTS engine."; return }
        if (speechSentenceIndex !in speechSentences.indices) return
        val locale = when(speechLanguage) { AppLanguage.UR -> Locale("ur", "PK"); AppLanguage.ROMAN -> Locale.US; else -> Locale.US }
        val result = engine.setLanguage(locale)
        if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
            ttsStatus = "TTS language ${locale.toLanguageTag()} is missing or unsupported on this device."; return
        }
        ttsStatus = ""
        engine.setSpeechRate(speechSpeed)
        val generation = speechGeneration
        engine.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(id: String?) {}
            override fun onError(id: String?) {}
            override fun onDone(id: String?) {
                runOnUiThread {
                    if (generation == speechGeneration) {
                        speechSentenceIndex++
                        speakCurrentSentence()
                    }
                }
            }
        })
        engine.speak(speechSentences[speechSentenceIndex], TextToSpeech.QUEUE_FLUSH, null, "atif-$generation-$speechSentenceIndex")
    }
    fun pauseSpeech() { speech?.stop() }
    fun resumeSpeech() { speakCurrentSentence() }
    fun stopSpeech() { speechGeneration++; speechSentences = emptyList(); speechSentenceIndex = 0; speech?.stop() }
    /** v3.4.0 — hand playback to the foreground service so it keeps going on screen-off. */
    fun startBackgroundSpeech(text: String, language: String) {
        stopSpeech()
        TtsPlaybackService.start(this, text, language, speechSpeed)
    }
    fun stopBackgroundSpeech() { TtsPlaybackService.stop(this) }
    override fun onDestroy() { speech?.stop(); speech?.shutdown(); speech=null; super.onDestroy() }
}

data class Exercise(
    val name: String, val muscle: String, val sets: Int, val reps: String,
    val cues: List<String>, val mistakes: List<String>, val breathing: String,
    val equipment: String, val gifFileName: String = ""
)
data class DayPlan(val day: String, val title: String, val tag: String, val exercises: List<Exercise>)

private fun exerciseGifFileName(name: String): String =
    name.lowercase(java.util.Locale.ROOT).replace(Regex("[^a-z0-9]+"), "_").trim('_') + ".gif"
private fun ex(n:String,m:String,s:Int,r:String,e:String,c:List<String>,mist:List<String>,b:String)=
    Exercise(n,m,s,r,c,mist,b,e,exerciseGifFileName(n))
private val plans = listOf(
 DayPlan("Saturday","Chest + Triceps","PUSH A", listOf(
  ex("Barbell Bench Press","Chest · Triceps · Front delts",3,"6–10","Barbell + bench", listOf("Feet planted; shoulder blades pulled back","Lower bar under control to mid-chest","Press up without bouncing the bar"), listOf("Bouncing bar off chest","Excessive lower-back arch","Wrists folded backwards"),"Inhale while lowering; exhale while pressing."),
  ex("Incline Dumbbell Press","Upper chest · Triceps",2,"8–12","Incline bench + dumbbells", listOf("Set bench to a moderate incline","Lower dumbbells beside upper chest","Press up while keeping wrists stacked"), listOf("Bench too steep","Dumbbells crashing together"),"Inhale down; exhale up."),
  ex("Cable Chest Fly","Chest",2,"12–15","Cable machine", listOf("Slight bend in elbows","Bring hands together in a wide arc","Return slowly until chest stretches"), listOf("Turning it into a press","Using momentum"),"Exhale as hands come together."),
  ex("Rope Triceps Pushdown","Triceps",2,"10–12","Cable + rope", listOf("Keep elbows near your sides","Extend elbows until arms are straight","Separate rope ends slightly at bottom"), listOf("Swinging shoulders","Elbows drifting forward"),"Exhale while extending."),
  ex("Overhead Cable Extension","Triceps long head",2,"10–15","Cable + rope", listOf("Face away from cable","Keep upper arms steady overhead","Extend elbows without arching back"), listOf("Flaring ribs","Moving upper arms excessively"),"Exhale on extension."))),
 DayPlan("Sunday","Back + Biceps","PULL A", listOf(
  ex("Lat Pulldown","Lats · Biceps",3,"8–12","Lat pulldown machine", listOf("Grip slightly wider than shoulders","Pull bar toward upper chest","Control the return overhead"), listOf("Pulling behind neck","Rocking torso to move weight"),"Exhale while pulling down."),
  ex("Chest Supported Row","Mid back · Lats",3,"8–12","Chest-supported row", listOf("Keep chest against pad","Drive elbows back","Pause briefly; lower slowly"), listOf("Lifting chest off pad","Shrugging shoulders"),"Exhale while rowing."),
  ex("Single Arm Cable Row","Lats · Mid back",2,"10–12","Cable machine", listOf("Brace torso","Pull elbow toward hip","Allow controlled reach forward"), listOf("Rotating torso","Using momentum"),"Exhale on pull."),
  ex("Reverse Pec Deck","Rear delts",2,"12–15","Pec deck", listOf("Set handles around shoulder height","Open arms with soft elbows","Stop without shrugging"), listOf("Overarching lower back","Shrugging"),"Exhale as arms open."),
  ex("EZ Bar Curl","Biceps",3,"8–12","EZ bar", listOf("Keep elbows close to torso","Curl without swinging","Lower fully under control"), listOf("Swinging body","Elbows moving forward"),"Exhale while curling."),
  ex("Incline Dumbbell Curl","Biceps long head",2,"10–12","Incline bench + dumbbells", listOf("Keep upper back on bench","Let arms hang naturally","Curl without moving elbows forward"), listOf("Using momentum","Shortening the bottom range"),"Exhale while curling."))),
 DayPlan("Monday","Shoulders + Legs","LEGS A", listOf(
  ex("Dumbbell Shoulder Press","Deltoids · Triceps",2,"8–12","Dumbbells + bench", listOf("Brace core and keep ribs down","Press overhead in a comfortable path","Lower to shoulder level"), listOf("Overarching back","Pressing through painful range"),"Exhale while pressing."),
  ex("Dumbbell Lateral Raise","Side delts",3,"12–15","Dumbbells", listOf("Soft elbows and slight forward lean","Raise arms out to sides","Stop around shoulder height"), listOf("Swinging weights","Shrugging up"),"Exhale while raising."),
  ex("Barbell Squat","Quads · Glutes",3,"6–10","Barbell + rack", listOf("Brace abdomen before descent","Keep whole foot planted","Descend as far as control and mobility allow","Drive up through mid-foot"), listOf("Heels lifting","Knees collapsing inward","Losing trunk brace"),"Inhale and brace down; exhale through the ascent."),
  ex("Leg Press","Quads · Glutes",2,"10–12","Leg press", listOf("Feet about shoulder width","Lower sled with pelvis supported","Press without locking knees hard"), listOf("Lower back rounding","Knees collapsing inward"),"Inhale down; exhale up."),
  ex("Lying Leg Curl","Hamstrings",3,"10–15","Leg curl machine", listOf("Align knees with machine pivot","Curl heels toward glutes","Lower slowly"), listOf("Hips lifting","Dropping weight quickly"),"Exhale while curling."),
  ex("Standing Calf Raise","Calves",3,"12–15","Calf raise machine", listOf("Use full comfortable range","Pause in stretched bottom position","Rise onto balls of feet"), listOf("Bouncing","Tiny partial reps"),"Exhale while rising."))),
 DayPlan("Tuesday","Chest + Triceps","PUSH B", listOf(
  ex("Incline Smith Machine Press","Upper chest · Triceps",3,"8–12","Smith machine + incline bench", listOf("Set bench under bar path","Lower toward upper chest","Press smoothly without bouncing"), listOf("Bench too far forward/back","Bouncing off chest"),"Inhale down; exhale up."),
  ex("Flat Machine Chest Press","Chest · Triceps",2,"10–12","Chest press machine", listOf("Adjust handles around mid-chest","Keep shoulder blades supported","Press and return slowly"), listOf("Shoulders rolling forward","Locking elbows aggressively"),"Exhale while pressing."),
  ex("Pec Deck Fly","Chest",2,"12–15","Pec deck machine", listOf("Set elbows/handles comfortably","Bring arms together in a controlled arc","Return until chest stretches"), listOf("Excessive stretch","Using momentum"),"Exhale while closing."),
  ex("Straight Bar Triceps Pushdown","Triceps",2,"10–12","Cable + straight bar", listOf("Pin elbows beside torso","Extend elbows fully","Return slowly"), listOf("Leaning bodyweight onto bar","Elbows moving"),"Exhale while extending."),
  ex("Overhead Rope Extension","Triceps long head",2,"12–15","Cable + rope", listOf("Keep upper arms pointing forward/up","Bend elbows for a controlled stretch","Extend without arching back"), listOf("Flaring ribs","Moving shoulders"),"Exhale on extension."))),
 DayPlan("Wednesday","Back + Biceps","PULL B", listOf(
  ex("Pull-ups / Assisted Pull-ups","Lats · Biceps",3,"8–12","Pull-up bar / assisted machine", listOf("Start from controlled hang","Pull chest toward bar","Lower without dropping"), listOf("Kipping or swinging","Half reps"),"Exhale while pulling."),
  ex("T-Bar Row","Mid back · Lats",3,"8–12","T-bar row machine", listOf("Brace torso and maintain neutral spine","Pull handle toward lower chest","Lower with control"), listOf("Rounding back","Jerking torso"),"Exhale while rowing."),
  ex("Straight Arm Pulldown","Lats",2,"12–15","Cable + straight bar", listOf("Keep elbows softly bent","Pull bar toward thighs","Control return overhead"), listOf("Bending elbows into a triceps pushdown","Leaning excessively"),"Exhale while pulling down."),
  ex("Cable Rear Delt Fly","Rear delts",2,"12–15","Cable machine", listOf("Use crossed cables if comfortable","Move arms outward","Keep traps relaxed"), listOf("Shrugging","Swinging"),"Exhale while opening."),
  ex("Hammer Curl","Brachialis · Biceps · Forearms",3,"10–12","Dumbbells", listOf("Keep palms facing each other","Curl without swinging","Lower slowly"), listOf("Body swing","Wrists bending"),"Exhale while curling."),
  ex("Preacher Curl","Biceps",2,"10–12","Preacher bench + EZ bar", listOf("Keep upper arms on pad","Curl through comfortable range","Lower without snapping elbow straight"), listOf("Lifting elbows off pad","Dropping into bottom"),"Exhale while curling."))),
 DayPlan("Thursday","Legs + Shoulders","LEGS B", listOf(
  ex("Machine Shoulder Press","Deltoids · Triceps",2,"8–12","Shoulder press machine", listOf("Adjust seat so handles start near shoulders","Brace back against pad","Press overhead smoothly"), listOf("Overarching back","Shrugging"),"Exhale while pressing."),
  ex("Cable Lateral Raise","Side delts",3,"12–15","Cable machine", listOf("Stand side-on to low pulley","Raise arm out to side","Lower slowly"), listOf("Torso swinging","Shrugging"),"Exhale while raising."),
  ex("Romanian Deadlift","Hamstrings · Glutes",3,"8–10","Barbell / dumbbells", listOf("Soften knees and brace core","Push hips backward; keep weight close","Stop when hamstrings limit the hinge","Stand by driving hips forward"), listOf("Squatting instead of hinging","Rounding lower back","Weight drifting away"),"Inhale and brace on descent; exhale as you stand."),
  ex("Bulgarian Split Squat","Quads · Glutes",2,"10 each leg","Bench + dumbbells", listOf("Set rear foot on stable bench","Descend under control","Keep front foot fully planted"), listOf("Front heel lifting","Losing balance due to rushed reps"),"Inhale down; exhale up."),
  ex("Leg Extension","Quadriceps",2,"12–15","Leg extension machine", listOf("Align knee with machine pivot","Extend legs smoothly","Lower without letting stack slam"), listOf("Kicking explosively","Poor machine alignment"),"Exhale while extending."),
  ex("Seated Leg Curl","Hamstrings",2,"10–15","Seated leg curl machine", listOf("Set thigh pad securely","Curl heels down/back","Return slowly"), listOf("Lifting hips","Rushing eccentric"),"Exhale while curling."),
  ex("Seated Calf Raise","Soleus · Calves",3,"12–15","Seated calf machine", listOf("Place forefoot on platform","Lower heels for a controlled stretch","Raise heels and pause"), listOf("Bouncing","Partial range"),"Exhale while raising.")))
)


data class LoggedSet(val weight: String, val reps: String, val type: String = "Working", val done: Boolean = false, val rpe: String = "")
data class ExerciseLog(val day: String, val exercise: String, val date: String, val sets: List<LoggedSet>, val durationSeconds: Int = 0, val note: String = "")

/** v3.4.0 — KG/LB display conversion. Stored values stay in kg (canonical, so old
 * backups and logs never change meaning); only displayed values convert. */
object WeightUnits {
    const val KG = "kg"
    const val LB = "lb"
    fun current(activity: ComponentActivity): String {
        val tools = activity.getSharedPreferences("atif_tools", 0).getString("unit", null)
        if (tools == KG || tools == LB) return tools
        return activity.getSharedPreferences("atif", 0).getString("unit", KG) ?: KG
    }
    fun kgToLb(kg: Double): Double = kg * 2.20462
    fun lbToKg(lb: Double): Double = lb / 2.20462
    fun displayKg(kg: Double, unit: String): String =
        if (unit == LB) "%.1f lb".format(kgToLb(kg)) else "%.1f kg".format(kg)
    fun displayKgString(kgText: String, unit: String): String {
        val kg = kgText.toDoubleOrNull() ?: return kgText
        return displayKg(kg, unit)
    }
}

/** v3.4.0 — body-weight history, one entry per calendar date, stored locally. */
private fun loadWeightHistory(a: ComponentActivity): List<Pair<String, Double>> = try {
    val arr = JSONArray(a.getSharedPreferences("atif_weight_history", 0).getString("entries", "[]") ?: "[]")
    (0 until arr.length()).mapNotNull { i ->
        val o = arr.optJSONObject(i) ?: return@mapNotNull null
        val w = o.optDouble("weight", Double.NaN)
        if (o.optString("date").isBlank() || w.isNaN()) null else o.optString("date") to w
    }.sortedBy { it.first }
} catch (_: Exception) { emptyList() }
private fun recordWeightHistory(a: ComponentActivity, weightKg: String) {
    val kg = weightKg.toDoubleOrNull() ?: return
    if (kg <= 0.0 || kg > 400.0) return
    val today = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US).format(java.util.Date())
    val entries = loadWeightHistory(a).filterNot { it.first == today } + (today to kg)
    val arr = JSONArray()
    entries.takeLast(365).forEach { (d, w) -> arr.put(JSONObject().put("date", d).put("weight", w)) }
    a.getSharedPreferences("atif_weight_history", 0).edit().putString("entries", arr.toString()).apply()
}

private fun loadLogs(a: ComponentActivity): List<ExerciseLog> = try {
    val arr = JSONArray(a.getSharedPreferences("atif", 0).getString("logs", "[]"))
    (0 until arr.length()).map { i ->
        val o = arr.getJSONObject(i); val sa = o.getJSONArray("sets")
        ExerciseLog(o.getString("day"), o.getString("exercise"), o.getString("date"),
            (0 until sa.length()).map { j -> val x=sa.getJSONObject(j); LoggedSet(x.optString("weight"),x.optString("reps"),x.optString("type","Working"),x.optBoolean("done"),x.optString("rpe")) },
            o.optInt("duration"), o.optString("note"))
    }
} catch (_: Exception) { emptyList() }

private fun saveLogs(a: ComponentActivity, logs: List<ExerciseLog>) {
    val arr = JSONArray()
    logs.forEach { l ->
        val sets = JSONArray()
        l.sets.forEach { x -> sets.put(JSONObject().put("weight",x.weight).put("reps",x.reps).put("type",x.type).put("done",x.done).put("rpe",x.rpe)) }
        arr.put(JSONObject().put("day",l.day).put("exercise",l.exercise).put("date",l.date).put("sets",sets).put("duration",l.durationSeconds).put("note",l.note))
    }
    a.getSharedPreferences("atif",0).edit().putString("logs",arr.toString()).apply()
}
private fun todayStamp(): String = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm", java.util.Locale.getDefault()).format(java.util.Date())



private fun loadCustomExercises(activity: ComponentActivity): List<Exercise> {
    return try {
        val raw = activity.getSharedPreferences("atif_custom_exercises", 0).getString("items", "[]") ?: "[]"
        val arr = JSONArray(raw)
        (0 until arr.length()).mapNotNull { i ->
            val o = arr.optJSONObject(i) ?: return@mapNotNull null
            Exercise(
                name=o.optString("name"), muscle=o.optString("muscle"),
                sets=o.optInt("sets",3), reps=o.optString("reps","8–12"),
                cues=listOf("Use a controlled range of motion","Keep your body stable","Stop if you feel sharp pain"),
                mistakes=listOf("Using momentum","Losing control of the movement"),
                breathing="Breathe steadily; avoid holding your breath.",
                equipment=o.optString("equipment"), gifFileName=exerciseGifFileName(o.optString("name"))
            )
        }.filter { it.name.isNotBlank() }
    } catch (_: Exception) { emptyList() }
}
private fun saveCustomExercises(activity: ComponentActivity, exercises: List<Exercise>) {
    val arr=JSONArray()
    exercises.forEach { e ->
        arr.put(org.json.JSONObject().put("name",e.name).put("muscle",e.muscle)
            .put("sets",e.sets).put("reps",e.reps).put("equipment",e.equipment))
    }
    activity.getSharedPreferences("atif_custom_exercises",0).edit().putString("items",arr.toString()).apply()
}

private fun loadRoutineExercises(activity: ComponentActivity, day: DayPlan): List<Exercise> {
    return try {
        val raw = activity.getSharedPreferences("atif_routines", 0).getString("routine_${day.day}", null)
            ?: return day.exercises
        val library = (plans.flatMap { it.exercises } + loadCustomExercises(activity)).distinctBy { it.name }.associateBy { it.name }
        val parsed = JSONArray(raw)
        val restored = (0 until parsed.length()).mapNotNull { i ->
            when (val item = parsed.opt(i)) {
                is org.json.JSONObject -> {
                    val base = library[item.optString("name")] ?: return@mapNotNull null
                    base.copy(
                        sets = item.optInt("sets", base.sets).coerceIn(1,30),
                        reps = item.optString("reps", base.reps).ifBlank { base.reps }
                    )
                }
                is String -> library[item]
                else -> null
            }
        }
        if (restored.isEmpty()) day.exercises else restored
    } catch (_: Exception) { day.exercises }
}
private fun saveRoutineExercises(activity: ComponentActivity, day: DayPlan, exercises: List<Exercise>) {
    val items = JSONArray()
    exercises.forEach { e ->
        items.put(org.json.JSONObject().put("name",e.name).put("sets",e.sets).put("reps",e.reps))
    }
    activity.getSharedPreferences("atif_routines", 0).edit()
        .putString("routine_${day.day}", items.toString()).apply()
}


private fun loadFavorites(activity: ComponentActivity): Set<String> =
    activity.getSharedPreferences("atif_favorites",0).getStringSet("names", emptySet())?.toSet() ?: emptySet()
private fun saveFavorites(activity: ComponentActivity, names: Set<String>) {
    activity.getSharedPreferences("atif_favorites",0).edit().putStringSet("names",names).apply()
}

@Composable fun AtifFitnessApp(activity: MainActivity) {
    var tab by remember { mutableStateOf("Home") }
    var selectedDay by remember { mutableStateOf(plans[0]) }
    var selectedExercise by remember { mutableStateOf<Exercise?>(null) }
    var completed by remember { mutableStateOf(loadCompleted(activity)) }
    var logs by remember { mutableStateOf(loadLogs(activity)) }
    var weight by remember { mutableStateOf(activity.getSharedPreferences("atif",0).getString("weight","78") ?: "78") }
    var search by remember { mutableStateOf("") }
    var language by remember { mutableStateOf(AppLanguage.current(activity.getSharedPreferences("atif",0))) }
    val previous = { name: String -> logs.lastOrNull { it.exercise == name } }
    MaterialTheme(colorScheme = darkColorScheme(primary=Green, background=Bg, surface=Panel, onSurface=Color.White)) {
      Surface(Modifier.fillMaxSize(), color=Bg) {
        val urduTypeface = FontFamily(Font(R.font.noto_nastaliq_urdu))
        CompositionLocalProvider(
          LocalLayoutDirection provides if(language==AppLanguage.UR) LayoutDirection.Rtl else LayoutDirection.Ltr,
          LocalTextStyle provides LocalTextStyle.current.copy(
            fontFamily = if(language==AppLanguage.UR) urduTypeface else FontFamily.Default,
            fontSize = if(language==AppLanguage.UR) 18.sp else 14.sp
          )
        ) {
        Column {
          Row(Modifier.fillMaxWidth().padding(horizontal=20.dp, vertical=14.dp), verticalAlignment=Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) { Text("ATIF FITNESS", color=Green, fontWeight=FontWeight.ExtraBold, fontSize=20.sp); Text(AppLanguage.text("TRAIN SMART · TRACK EVERYTHING", language), color=Muted, fontSize=9.sp, letterSpacing=1.sp) }
            Icon(Icons.Default.FitnessCenter, null, tint=Green)
          }
          if (selectedExercise != null) {
              val e = selectedExercise!!
              ExerciseDetail(e, selectedDay, { if(!activity.keepSpeechOnExit) activity.stopSpeech(); activity.keepSpeechOnExit=false; selectedExercise=null }, activity, previous(e.name), language,
                { record -> logs = logs.filterNot { it.exercise==record.exercise && it.day==record.day && it.date==record.date } + record; saveLogs(activity,logs); completed=completed+(selectedDay.day+e.name); saveCompleted(activity,completed) })
          } else when(tab) {
             "Home" -> HomeScreen(completed, { day -> selectedDay=day; tab="Workout" }, weight, { weight=it; activity.getSharedPreferences("atif",0).edit().putString("weight",it).apply(); recordWeightHistory(activity, it) }, logs, language)
             "Workout" -> WorkoutScreen(selectedDay,{selectedDay=it},completed,{selectedExercise=it},search,{search=it},logs,activity,language)
             "Progress" -> ProgressScreen(completed,logs,activity,weight,language)
             "Nutrition" -> NutritionScreen(activity,weight,language)
            else -> ProfileScreen(weight,{weight=it;activity.getSharedPreferences("atif",0).edit().putString("weight",it).apply(); recordWeightHistory(activity, it)},logs,activity, language, { language=it;activity.getSharedPreferences("atif",0).edit().putString("app_language",it).apply();activity.stopSpeech() },{restored,newWeight -> logs=restored;saveLogs(activity,restored);weight=newWeight;activity.getSharedPreferences("atif",0).edit().putString("weight",newWeight).apply()},{updated -> logs=updated;saveLogs(activity,updated)})
          }
          NavigationBar(containerColor=Panel, contentColor=Green) {
            listOf("Home","Workout","Progress","Nutrition","Profile").forEach { item ->
              NavigationBarItem(selected=tab==item,onClick={activity.stopSpeech();activity.keepSpeechOnExit=false;tab=item;selectedExercise=null}, modifier=Modifier.heightIn(min=56.dp),
                icon={ Icon(when(item){"Home"->Icons.Default.Home;"Workout"->Icons.Default.FitnessCenter;"Progress"->Icons.Default.Insights;"Nutrition"->Icons.Default.Restaurant;else->Icons.Default.Person},contentDescription="$item tab") },
                label={Text(AppLanguage.text(item,language),fontSize=if(language==AppLanguage.UR)13.sp else 11.sp)},colors=NavigationBarItemDefaults.colors(selectedIconColor=Green,selectedTextColor=Green,indicatorColor=Green.copy(alpha=.12f),unselectedIconColor=Muted,unselectedTextColor=Muted))
            }
          }
        }
        }
      }
    }
}

@Composable private fun Header(title:String,sub:String="",language:String=AppLanguage.EN) { Column(Modifier.padding(horizontal=18.dp,vertical=8.dp)) { Text(AppLanguage.text(title,language),fontSize=23.sp,fontWeight=FontWeight.Bold); if(sub.isNotBlank()) Text(AppLanguage.text(sub,language),color=Muted,fontSize=12.sp) } }
@Composable private fun PanelCard(content:@Composable ColumnScope.()->Unit) { Card(Modifier.fillMaxWidth(),colors=CardDefaults.cardColors(containerColor=Panel),shape=RoundedCornerShape(18.dp)){Column(Modifier.padding(16.dp),content=content)} }
@Composable private fun StatCard(label:String,value:String,modifier:Modifier=Modifier) { Card(modifier,colors=CardDefaults.cardColors(containerColor=Panel),shape=RoundedCornerShape(16.dp)){Column(Modifier.padding(12.dp)){Text(label,color=Muted,fontSize=9.sp);Text(value,fontWeight=FontWeight.Bold,fontSize=17.sp)}} }
@Composable private fun DayCard(day:DayPlan,done:Set<String>,click:()->Unit) { val count=day.exercises.count{done.contains(day.day+it.name)}; Card(Modifier.fillMaxWidth().clickable(onClick=click),colors=CardDefaults.cardColors(containerColor=Panel),shape=RoundedCornerShape(15.dp)){Row(Modifier.padding(14.dp),verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text(day.day.uppercase(),color=Green,fontSize=10.sp,fontWeight=FontWeight.Bold);Text(day.title,fontWeight=FontWeight.SemiBold);Text("${day.tag} · ${day.exercises.size} exercises",color=Muted,fontSize=11.sp)};Text("$count/${day.exercises.size}",color=Green,fontWeight=FontWeight.Bold);Icon(Icons.Default.ChevronRight,null,tint=Muted)}}}

@Composable private fun ColumnScope.HomeScreen(done:Set<String>,open:(DayPlan)->Unit,weight:String,onWeight:(String)->Unit,logs:List<ExerciseLog>,language:String) {
 val totalSets=logs.sumOf{it.sets.count{set->set.done}}
 val latest=logs.lastOrNull()
 LazyColumn(Modifier.weight(1f),contentPadding=PaddingValues(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
  item{Text(AppLanguage.text("YOUR FITNESS DASHBOARD", language),color=Green,fontSize=10.sp,fontWeight=FontWeight.Bold,letterSpacing=1.5.sp);Text(AppLanguage.text("Build muscle. Track progress.", language),fontSize=24.sp,fontWeight=FontWeight.Bold);Text(AppLanguage.text("Intermediate · Muscle gain · 6 days/week", language),color=Muted,fontSize=12.sp)}
  item{Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){StatCard("BODY WEIGHT","$weight kg",Modifier.weight(1f));StatCard("LOGGED SETS","$totalSets",Modifier.weight(1f));StatCard("SESSIONS","${logs.map{it.date.take(10)}.distinct().size}",Modifier.weight(1f))}}
   item {
     val todayPlan = plans.firstOrNull { it.day.equals(java.text.SimpleDateFormat("EEEE", java.util.Locale.US).format(java.util.Date()), true) } ?: plans.first()
     val doneToday = todayPlan.exercises.count { done.contains(todayPlan.day + it.name) }
     val ratio = doneToday.toFloat() / todayPlan.exercises.size.coerceAtLeast(1)
     Card(Modifier.fillMaxWidth(), colors=CardDefaults.cardColors(containerColor=Green), shape=RoundedCornerShape(24.dp)) {
       Row(Modifier.padding(18.dp), verticalAlignment=Alignment.CenterVertically) {
         Column(Modifier.weight(1f)) {
           Text(AppLanguage.text("TODAY'S WORKOUT", language), color=Bg.copy(alpha=.72f), fontSize=11.sp, fontWeight=FontWeight.Bold)
           Text(todayPlan.title, color=Bg, fontSize=23.sp, fontWeight=FontWeight.ExtraBold)
           Text("${todayPlan.tag} · ${todayPlan.exercises.size} exercises", color=Bg.copy(alpha=.8f), fontSize=13.sp)
           Button(onClick={open(todayPlan)}, modifier=Modifier.padding(top=12.dp).heightIn(min=52.dp), colors=ButtonDefaults.buttonColors(containerColor=Bg, contentColor=Green)) { Text(AppLanguage.text("Start workout", language)) }
         }
         Box(contentAlignment=Alignment.Center, modifier=Modifier.size(92.dp)) {
           CircularProgressIndicator(progress={ratio}, modifier=Modifier.fillMaxSize(), strokeWidth=8.dp, color=Bg, trackColor=Bg.copy(alpha=.18f))
           Text("${(ratio*100).toInt()}%", color=Bg, fontSize=19.sp, fontWeight=FontWeight.Bold)
         }
       }
     }
   }
  item{PanelCard{
    Text(AppLanguage.text("WORKOUT TEMPLATES", language), color = Green, fontWeight = FontWeight.Bold)
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
      OutlinedButton(onClick = { open(DayPlan("Today", "Empty workout", "CUSTOM", emptyList())) }, modifier = Modifier.weight(1f).heightIn(min = 52.dp)) { Text(AppLanguage.text("Empty workout", language)) }
      OutlinedButton(onClick = {
        val lastDate = logs.maxOfOrNull { it.date.take(10) }
        val names = logs.filter { it.date.take(10) == lastDate }.map { it.exercise }.distinct()
        val lib = (plans.flatMap { it.exercises }).distinctBy { it.name }.associateBy { it.name }
        val copied = names.mapNotNull { lib[it] }
        open(DayPlan("Today", "Copy of last workout", "CUSTOM", copied))
      }, modifier = Modifier.weight(1f).heightIn(min = 52.dp), enabled = logs.isNotEmpty()) { Text(AppLanguage.text("Copy last workout", language)) }
    }
    Text(AppLanguage.text("Empty workout starts with no exercises - add your own from the library. Copy last workout reuses the exercises from your most recent logged day.", language), color = Muted, fontSize = 11.sp)
  }}
  item{Text(AppLanguage.text("WEEKLY PLAN", language),fontWeight=FontWeight.Bold,fontSize=17.sp)}
  items(plans){day->DayCard(day,done){open(day)}}
  item{PanelCard{Text(AppLanguage.text("FRIDAY · REST & RECOVERY", language),color=Green,fontWeight=FontWeight.Bold);Text(AppLanguage.text("Light walk, adequate food, hydration and 7–9 hours of sleep.", language),color=Muted,fontSize=13.sp)}}
 }
}

@Composable private fun ColumnScope.WorkoutScreen(day:DayPlan,onDay:(DayPlan)->Unit,done:Set<String>,open:(Exercise)->Unit,search:String,onSearch:(String)->Unit,logs:List<ExerciseLog>,activity:ComponentActivity,language:String){
 var editableExercises by remember(day.day){mutableStateOf(loadRoutineExercises(activity,day))}
 fun updateExercises(next: List<Exercise>) { editableExercises=next; saveRoutineExercises(activity,day,next) }
 var showAddExercise by remember{mutableStateOf(false)}
 var prescriptionIndex by remember{mutableIntStateOf(-1)}
 var prescriptionSets by remember{mutableStateOf("3")}
 var prescriptionReps by remember{mutableStateOf("8–12")}
 var replaceIndex by remember{mutableIntStateOf(-1)}
 var librarySearch by remember{mutableStateOf("")}
 val customExercises by remember { mutableStateOf(loadCustomExercises(activity).toMutableList()) }
 val exerciseLibrary=(plans.flatMap{it.exercises}+customExercises).distinctBy{it.name}
 var favorites by remember { mutableStateOf(loadFavorites(activity)) }
 var favoritesOnly by remember { mutableStateOf(false) }
 var showCreateExercise by remember { mutableStateOf(false) }
 var customName by remember { mutableStateOf("") }
 var customMuscle by remember { mutableStateOf("") }
 var customEquipment by remember { mutableStateOf("") }
 var customSets by remember { mutableStateOf("3") }
 var customReps by remember { mutableStateOf("8–12") }
 if(prescriptionIndex>=0) AlertDialog(
   onDismissRequest={prescriptionIndex=-1},
   title={Text(AppLanguage.text("Edit sets & reps", language))},
   text={Column(verticalArrangement=Arrangement.spacedBy(8.dp)) {
     OutlinedTextField(prescriptionSets,{prescriptionSets=it.filter(Char::isDigit).take(2)},label={Text(AppLanguage.text("Working sets", language))},singleLine=true)
     OutlinedTextField(prescriptionReps,{prescriptionReps=it},label={Text(AppLanguage.text("Rep range e.g. 8–12", language))},singleLine=true)
   }},
   confirmButton={TextButton(onClick={
     val idx=prescriptionIndex
     if(idx in editableExercises.indices) {
       val next=editableExercises.toMutableList()
       next[idx]=next[idx].copy(sets=(prescriptionSets.toIntOrNull()?:next[idx].sets).coerceIn(1,30),reps=prescriptionReps.trim().ifBlank{next[idx].reps})
       updateExercises(next)
     }
     prescriptionIndex=-1
   }){Text(AppLanguage.text("Save", language))}},
   dismissButton={TextButton(onClick={prescriptionIndex=-1}){Text(AppLanguage.text("Cancel", language))}}
 )
 if(showCreateExercise) AlertDialog(
   onDismissRequest={showCreateExercise=false},
   title={Text(AppLanguage.text("Create custom exercise", language))},
   text={Column(verticalArrangement=Arrangement.spacedBy(8.dp)) {
     OutlinedTextField(customName,{customName=it},label={Text(AppLanguage.text("Exercise name", language))},singleLine=true)
     OutlinedTextField(customMuscle,{customMuscle=it},label={Text(AppLanguage.text("Target muscle", language))},singleLine=true)
     OutlinedTextField(customEquipment,{customEquipment=it},label={Text(AppLanguage.text("Equipment", language))},singleLine=true)
     Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
       OutlinedTextField(customSets,{customSets=it.filter(Char::isDigit).take(2)},Modifier.weight(1f),label={Text(AppLanguage.text("Sets", language))},singleLine=true)
       OutlinedTextField(customReps,{customReps=it},Modifier.weight(1f),label={Text(AppLanguage.text("Rep range", language))},singleLine=true)
     }
   }},
   confirmButton={TextButton(onClick={
     val name=customName.trim()
     if(name.isNotBlank() && customMuscle.isNotBlank()) {
       val item=Exercise(name,customMuscle.trim(),(customSets.toIntOrNull()?:3).coerceIn(1,20),customReps.ifBlank{"8–12"},
         listOf("Use a controlled range of motion","Keep your body stable","Stop if you feel sharp pain"),
         listOf("Using momentum","Losing control of the movement"),
         "Breathe steadily; avoid holding your breath.",customEquipment.ifBlank{"Bodyweight"},exerciseGifFileName(name))
       if((plans.flatMap{it.exercises}+customExercises).none{it.name.equals(name,true)}) {
         customExercises.add(item); saveCustomExercises(activity,customExercises)
         updateExercises(editableExercises+item)
       }
       customName="";customMuscle="";customEquipment="";customSets="3";customReps="8–12";showCreateExercise=false
     }
   }){Text(AppLanguage.text("Save exercise", language))}},
   dismissButton={TextButton(onClick={showCreateExercise=false}){Text(AppLanguage.text("Cancel", language))}}
 )
 if(showAddExercise || replaceIndex>=0) AlertDialog(
   onDismissRequest={showAddExercise=false;replaceIndex=-1;librarySearch=""},
   title={Row(verticalAlignment=Alignment.CenterVertically) {
     Text(if(replaceIndex>=0) "Replace exercise" else "Add exercise",modifier=Modifier.weight(1f))
     TextButton(onClick={showCreateExercise=true}){Text(AppLanguage.text("+ Create", language))}
   }},
   text={Column {
     OutlinedTextField(librarySearch,{librarySearch=it},label={Text(AppLanguage.text("Search exercise library", language))},singleLine=true)
     LazyColumn(Modifier.heightIn(max=320.dp)){
       items(exerciseLibrary.filter{it.name.contains(librarySearch,true)||it.muscle.contains(librarySearch,true)}.take(80)){candidate->
         TextButton(onClick={
           if(replaceIndex>=0) updateExercises(editableExercises.toMutableList().also{it[replaceIndex]=candidate})
           else updateExercises(editableExercises+candidate)
           showAddExercise=false;replaceIndex=-1;librarySearch=""
         },modifier=Modifier.fillMaxWidth().heightIn(min=48.dp)){Text(candidate.name)}
       }
     }
   }},
   confirmButton={TextButton(onClick={showAddExercise=false;replaceIndex=-1}){Text(AppLanguage.text("Close", language))}}
 )
 Column(Modifier.weight(1f)){Header("Workout plan","Your six-day PPL × 2 program · tap an exercise to log sets",language)
  OutlinedTextField(search,onSearch,Modifier.fillMaxWidth().padding(horizontal=16.dp),singleLine=true,label={Text(AppLanguage.text("Search exercises", language))},leadingIcon={Icon(Icons.Default.Search,null)})
  Row(Modifier.fillMaxWidth().padding(horizontal=16.dp),verticalAlignment=Alignment.CenterVertically) {
    FilterChip(selected=favoritesOnly,onClick={favoritesOnly=!favoritesOnly},label={Text(AppLanguage.text("★ Favorites", language))})
    Spacer(Modifier.weight(1f))
    Text("${favorites.size} saved",color=Muted,fontSize=11.sp)
  }
  Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal=14.dp,vertical=8.dp),horizontalArrangement=Arrangement.spacedBy(8.dp)){plans.forEach{p->FilterChip(selected=p==day,onClick={onDay(p)},label={Text(p.day.take(3))},colors=FilterChipDefaults.filterChipColors(selectedContainerColor=Green,selectedLabelColor=Bg))}}
  LazyColumn(Modifier.weight(1f),contentPadding=PaddingValues(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){
   item{PanelCard{Text(day.tag,color=Green,fontWeight=FontWeight.Bold,fontSize=10.sp);Text(day.title,fontSize=22.sp,fontWeight=FontWeight.Bold);Text(AppLanguage.text("60–90 minute target · Warm up before working sets", language),color=Muted,fontSize=12.sp)}}
   item {
     Row(horizontalArrangement=Arrangement.spacedBy(8.dp),verticalAlignment=Alignment.CenterVertically) {
       Text(AppLanguage.text("Edit today's exercise list", language),fontWeight=FontWeight.Bold,modifier=Modifier.weight(1f))
       TextButton(onClick={updateExercises(day.exercises);activity.getSharedPreferences("atif_routines",0).edit().remove("routine_${day.day}").apply()},modifier=Modifier.heightIn(min=48.dp)){Text(AppLanguage.text("Reset", language))}
       Button(onClick={showAddExercise=true},modifier=Modifier.heightIn(min=48.dp),colors=ButtonDefaults.buttonColors(containerColor=Green,contentColor=Bg)){Text(AppLanguage.text("+ Add", language))}
     }
   }
   val shown=editableExercises.filter{(it.name.contains(search,true)||it.muscle.contains(search,true)||it.equipment.contains(search,true)) && (!favoritesOnly || favorites.contains(it.name))}
   items(shown){e->
     val originalIndex=editableExercises.indexOf(e); val isDone=done.contains(day.day+e.name);val prev=logs.lastOrNull{it.exercise==e.name};Card(colors=CardDefaults.cardColors(containerColor=Panel),shape=RoundedCornerShape(15.dp)){Column(Modifier.padding(12.dp)){
       Row(verticalAlignment=Alignment.CenterVertically,modifier=Modifier.fillMaxWidth()){
        Column(Modifier.weight(1f).clickable{open(e)}){Text(e.name,fontWeight=FontWeight.Bold);Text(e.muscle,color=Muted,fontSize=11.sp);Text("${e.sets} sets · ${e.reps} reps",color=Green,fontSize=12.sp);if(prev!=null)Text("Last: "+(prev.sets.lastOrNull{it.done}?.let{"${it.weight} kg × ${it.reps}"}?:"Logged"),color=Muted,fontSize=10.sp)}
         if(isDone)Icon(Icons.Default.CheckCircle,null,tint=Green)
         TextButton(onClick={favorites=if(favorites.contains(e.name))favorites-e.name else favorites+e.name;saveFavorites(activity,favorites)}){Text(if(favorites.contains(e.name))"★" else "☆",fontSize=20.sp,color=Green)}
         Icon(Icons.Default.ChevronRight,null,tint=Muted)
       }
       Row(horizontalArrangement=Arrangement.spacedBy(4.dp),verticalAlignment=Alignment.CenterVertically){
         TextButton(onClick={if(originalIndex>0)updateExercises(editableExercises.toMutableList().also{val v=it.removeAt(originalIndex);it.add(originalIndex-1,v)})},enabled=originalIndex>0,modifier=Modifier.heightIn(min=44.dp)){Text("↑")}
         TextButton(onClick={if(originalIndex<editableExercises.lastIndex)updateExercises(editableExercises.toMutableList().also{val v=it.removeAt(originalIndex);it.add(originalIndex+1,v)})},enabled=originalIndex<editableExercises.lastIndex,modifier=Modifier.heightIn(min=44.dp)){Text("↓")}
         TextButton(onClick={prescriptionIndex=originalIndex;prescriptionSets=e.sets.toString();prescriptionReps=e.reps},modifier=Modifier.heightIn(min=44.dp)){Text(AppLanguage.text("Sets/reps", language))}
         TextButton(onClick={replaceIndex=originalIndex},modifier=Modifier.heightIn(min=44.dp)){Text(AppLanguage.text("Replace", language))}
         TextButton(onClick={updateExercises(editableExercises.filterIndexed{idx,_->idx!=originalIndex})},modifier=Modifier.heightIn(min=44.dp)){Text(AppLanguage.text("Remove", language),color=Color(0xFFFF8A80))}
       }
     }}}

   if(shown.isEmpty())item{Text(AppLanguage.text("No exercises match your search.", language),color=Muted)}
   item{Text(AppLanguage.text("Rest guide: 2–3 min for compound lifts; 60–120 sec for isolation. Keep most sets 1–3 reps in reserve.", language),color=Muted,fontSize=12.sp)}
  }
 }
}

@Composable private fun ColumnScope.ExerciseDetail(e:Exercise,day:DayPlan,onBack:()->Unit,activity:MainActivity,previous:ExerciseLog?,language:String,onSave:(ExerciseLog)->Unit){
 val defaultSets=previous?.sets?.takeIf{it.isNotEmpty()}?.map { it.copy(done=false) } ?: List(e.sets){LoggedSet("",e.reps.substringBefore("–"))}
 var entries by remember(e.name,day.day){mutableStateOf(defaultSets)}
 var note by remember(e.name,day.day){mutableStateOf("")}
 val timerPrefs=activity.getSharedPreferences("atif_timer",0)
 val timerKey="${day.day}_${e.name}".replace(" ","_")
 var seconds by remember(e.name,day.day){mutableIntStateOf(timerPrefs.getInt("rest_remaining_$timerKey",90))}
 var restDeadline by remember(e.name,day.day){mutableLongStateOf(timerPrefs.getLong("rest_deadline_$timerKey",0L))}
 var restRunning by remember(e.name,day.day){mutableStateOf(restDeadline>System.currentTimeMillis())}
 var sessionElapsed by remember(e.name,day.day){mutableIntStateOf(timerPrefs.getInt("session_elapsed_$timerKey",0))}
 var sessionRunning by remember(e.name,day.day){mutableStateOf(timerPrefs.getBoolean("session_running_$timerKey",true))}
 var sessionStartedAt by remember(e.name,day.day){mutableLongStateOf(timerPrefs.getLong("session_started_$timerKey",System.currentTimeMillis()))}
 var voiceGuided by remember { mutableStateOf(false) }
 var speechPaused by remember { mutableStateOf(false) }
 var currentExplanation by remember { mutableStateOf("") }
 var lastSpokenCountdown by remember { mutableIntStateOf(-1) }
 DisposableEffect(e.name) { onDispose { activity.stopSpeech() } }

 LaunchedEffect(restRunning,restDeadline){
   while(restRunning){
     val left=((restDeadline-System.currentTimeMillis()).coerceAtLeast(0L)/1000L).toInt()
     seconds=left
     timerPrefs.edit().putInt("rest_remaining_$timerKey",left).apply()
     if(left<=0){restRunning=false;restDeadline=0L;timerPrefs.edit().remove("rest_deadline_$timerKey").putInt("rest_remaining_$timerKey",0).apply(); if(voiceGuided){activity.speak("Rest finished, start next set",language);try{ToneGenerator(AudioManager.STREAM_NOTIFICATION,100).startTone(ToneGenerator.TONE_PROP_ACK,350);val vib=activity.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator;vib.vibrate(VibrationEffect.createOneShot(220,VibrationEffect.DEFAULT_AMPLITUDE))}catch(_:Exception){}};break}
     if(voiceGuided && left in listOf(30,10) && lastSpokenCountdown!=left){lastSpokenCountdown=left;activity.speak("$left seconds left",language)}
     kotlinx.coroutines.delay(250)
   }
 }
 LaunchedEffect(sessionRunning){
   while(sessionRunning){
     sessionElapsed=((timerPrefs.getInt("session_elapsed_$timerKey",sessionElapsed))+((System.currentTimeMillis()-sessionStartedAt)/1000L).toInt()).coerceAtLeast(0)
     timerPrefs.edit().putInt("session_elapsed_$timerKey",sessionElapsed).apply()
     sessionStartedAt=System.currentTimeMillis()
     timerPrefs.edit().putLong("session_started_$timerKey",sessionStartedAt).apply()
     kotlinx.coroutines.delay(1000)
   }
 }
 val completedSets=entries.count{it.done}
 Column(Modifier.weight(1f)){
  Row(Modifier.fillMaxWidth().clickable{onBack()}.padding(16.dp),verticalAlignment=Alignment.CenterVertically){Icon(Icons.Default.ArrowBack,null,tint=Green);Text("  ${day.day} · Exercise logger",fontWeight=FontWeight.Bold)}
  LazyColumn(Modifier.weight(1f),contentPadding=PaddingValues(horizontal=16.dp,vertical=4.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
   item{PanelCard{Text(e.muscle.uppercase(),color=Green,fontSize=10.sp,fontWeight=FontWeight.Bold);Text(ExerciseLanguages.name(e.name,language),fontSize=if(language==AppLanguage.UR)26.sp else 23.sp,fontWeight=FontWeight.Bold);Text("${e.sets} working sets · ${e.reps} reps · ${e.equipment}",color=Muted,fontSize=12.sp);if(previous!=null)Text("Previous session: ${previous.date}",color=Green,fontSize=11.sp)}}
   item{ExerciseGifDemo(e, language)}
   item{PanelCard {
     Text(AppLanguage.text("Listen to explanation",language),fontWeight=FontWeight.Bold,color=Green)
     Row(horizontalArrangement=Arrangement.spacedBy(6.dp),modifier=Modifier.fillMaxWidth()) {
       Button(onClick={currentExplanation=ExerciseLanguages.explanation(e,language);speechPaused=false;activity.speak(currentExplanation,language)},modifier=Modifier.weight(1f),colors=ButtonDefaults.buttonColors(containerColor=Green,contentColor=Bg)){Text(AppLanguage.text("Play",language))}
       OutlinedButton(onClick={speechPaused=false;activity.stopSpeech()},modifier=Modifier.weight(1f)){Text(AppLanguage.text("Stop",language))}
       OutlinedButton(onClick={if(!speechPaused){activity.pauseSpeech();speechPaused=true}else{speechPaused=false;activity.resumeSpeech()}},modifier=Modifier.weight(1f)){Text(if(speechPaused)AppLanguage.text("Resume",language) else AppLanguage.text("Pause",language))}
     }
     Row(verticalAlignment=Alignment.CenterVertically){Text(AppLanguage.text("Speed",language),color=Muted);listOf(.75f,1f,1.25f).forEach{v->TextButton(onClick={activity.speechSpeed=v}){Text("${v}x",color=if(activity.speechSpeed==v)Green else Color.White)}}}
     Row(horizontalArrangement=Arrangement.spacedBy(6.dp),modifier=Modifier.fillMaxWidth()){
       OutlinedButton(onClick={currentExplanation=ExerciseLanguages.explanation(e,language);activity.startBackgroundSpeech(currentExplanation,language)},modifier=Modifier.weight(1f)){Text(AppLanguage.text("Play in background",language))}
       OutlinedButton(onClick={activity.stopBackgroundSpeech()},modifier=Modifier.weight(1f)){Text(AppLanguage.text("Stop background",language))}
     }
     Text(AppLanguage.text("Background playback uses a foreground service with a notification, so speech keeps going when the screen turns off. Stop it from the notification or here.",language),color=Muted,fontSize=10.sp)
     Row(verticalAlignment=Alignment.CenterVertically){Text(AppLanguage.text("Voice-guided workout",language),Modifier.weight(1f));Switch(voiceGuided,{voiceGuided=it})}
     if(activity.ttsStatus.isNotBlank()) Text(activity.ttsStatus,color=Color(0xFFFF8A80),fontSize=11.sp)
   }}
   item{PanelCard{Text(AppLanguage.text("HOW TO PERFORM",language),fontWeight=FontWeight.Bold);ExerciseLanguages.cues(e,language).forEachIndexed{i,c->Text("${i+1}. $c",Modifier.padding(top=8.dp),fontSize=13.sp)};Spacer(Modifier.height(8.dp));Text(AppLanguage.text("BREATHING",language),color=Green,fontWeight=FontWeight.Bold,fontSize=11.sp);Text(ExerciseLanguages.breathing(e,language),fontSize=13.sp)}}
   item{PanelCard{Text(AppLanguage.text("COMMON MISTAKES",language),fontWeight=FontWeight.Bold);ExerciseLanguages.mistakes(e,language).forEach{Text("• $it",Modifier.padding(top=7.dp),color=Muted,fontSize=13.sp)};Text(AppLanguage.text("Use a controlled range of motion. Stop if you feel sharp pain.",language),Modifier.padding(top=8.dp),color=Muted,fontSize=11.sp)}}
   item{PanelCard{
    Row(verticalAlignment=Alignment.CenterVertically){Text(AppLanguage.text("SET LOGGER",language),fontWeight=FontWeight.Bold);Spacer(Modifier.weight(1f));Text("$completedSets/${entries.size} done",color=Green,fontSize=12.sp)}
    if(previous!=null){val p=previous.sets.lastOrNull{it.done};if(p!=null)Text("Last performance: ${WeightUnits.displayKgString(p.weight,WeightUnits.current(activity))} × ${p.reps}",color=Muted,fontSize=11.sp,modifier=Modifier.padding(top=4.dp))}
    entries.forEachIndexed{i,set->
      Column(Modifier.fillMaxWidth().padding(top=10.dp).background(Bg,RoundedCornerShape(12.dp)).padding(10.dp)){
       Row(verticalAlignment=Alignment.CenterVertically){Text("SET ${i+1}",fontWeight=FontWeight.Bold,color=Green);Spacer(Modifier.weight(1f));Checkbox(set.done,{v->entries=entries.toMutableList().also{it[i]=it[i].copy(done=v)};if(v){if(voiceGuided){activity.speak("Set ${i+1}, ${entries[i].weight}kg, ${entries[i].reps} reps. Rest 90 seconds",language)};seconds=90;lastSpokenCountdown=-1;restDeadline=System.currentTimeMillis()+90_000L;restRunning=true;timerPrefs.edit().putInt("rest_remaining_$timerKey",90).putLong("rest_deadline_$timerKey",restDeadline).apply(); try { val vib=activity.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator; vib.vibrate(VibrationEffect.createOneShot(120,VibrationEffect.DEFAULT_AMPLITUDE)) } catch (_:Exception) {} }},colors=CheckboxDefaults.colors(checkedColor=Green))}
       Row(horizontalArrangement=Arrangement.spacedBy(8.dp),verticalAlignment=Alignment.CenterVertically){
        Column(Modifier.weight(1f)){
          Text(AppLanguage.text("WEIGHT kg", language),color=Muted,fontSize=11.sp)
          OutlinedTextField(set.weight,{v->entries=entries.toMutableList().also{it[i]=it[i].copy(weight=v)}},singleLine=true,
            keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Decimal))
          Row(verticalAlignment=Alignment.CenterVertically){
            TextButton(onClick={val n=(set.weight.toDoubleOrNull()?:0.0)-2.5;entries=entries.toMutableList().also{it[i]=it[i].copy(weight=n.coerceAtLeast(0.0).toString())}}){Text("-2.5")}
            TextButton(onClick={val n=(set.weight.toDoubleOrNull()?:0.0)+2.5;entries=entries.toMutableList().also{it[i]=it[i].copy(weight=n.toString())}}){Text("+2.5")}
          }
        }
        Column(Modifier.weight(1f)){
          Text(AppLanguage.text("REPS", language),color=Muted,fontSize=11.sp)
          OutlinedTextField(set.reps,{v->entries=entries.toMutableList().also{it[i]=it[i].copy(reps=v)}},singleLine=true,
            keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Number))
          Row(verticalAlignment=Alignment.CenterVertically){
            TextButton(onClick={val n=(set.reps.toIntOrNull()?:0)-1;entries=entries.toMutableList().also{it[i]=it[i].copy(reps=n.coerceAtLeast(0).toString())}}){Text("-1")}
            TextButton(onClick={val n=(set.reps.toIntOrNull()?:0)+1;entries=entries.toMutableList().also{it[i]=it[i].copy(reps=n.toString())}}){Text("+1")}
          }
        }
       }
       Row(verticalAlignment=Alignment.CenterVertically){
         Text(AppLanguage.text("Type", language),color=Muted,fontSize=11.sp);Spacer(Modifier.width(8.dp));var expanded by remember(i){mutableStateOf(false)}
         Box{OutlinedButton(onClick={expanded=true},modifier=Modifier.heightIn(min=48.dp)){Text(set.type)};DropdownMenu(expanded,{expanded=false}){
           listOf("Warmup","Working","Dropset","Failure","AMRAP","Superset").forEach{DropdownMenuItem(text={Text(it)},onClick={entries=entries.toMutableList().also{xs->xs[i]=xs[i].copy(type=it)};expanded=false})}
         }}
         Spacer(Modifier.weight(1f))
         Column {
           Text(AppLanguage.text("RPE 1-10", language),color=Muted,fontSize=11.sp)
           OutlinedTextField(set.rpe,{v->entries=entries.toMutableList().also{it[i]=it[i].copy(rpe=v)}},
             modifier=Modifier.width(84.dp),singleLine=true,keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Number))
         }
         TextButton(onClick={entries=entries.toMutableList().also{it.removeAt(i)}}, modifier=Modifier.heightIn(min=48.dp)){Text(AppLanguage.text("Remove", language),color=Color(0xFFFF8A80))}
       }
      }
    }
    Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){OutlinedButton(onClick={entries=entries+LoggedSet("",e.reps.substringBefore("–"))},modifier=Modifier.weight(1f).heightIn(min=52.dp)){Text(AppLanguage.text("+ Add set", language))};OutlinedButton(onClick={entries=entries+LoggedSet(entries.lastOrNull()?.weight.orEmpty(),entries.lastOrNull()?.reps?:e.reps.substringBefore("–"))},modifier=Modifier.weight(1f).heightIn(min=52.dp)){Text(AppLanguage.text("Repeat last", language))}}
    OutlinedTextField(note,{note=it},Modifier.fillMaxWidth().padding(top=8.dp),label={Text(AppLanguage.text("Exercise notes", language))},minLines=2)
   }}
   item{PanelCard{
     Text(AppLanguage.text("WORKOUT TIMER", language),fontWeight=FontWeight.Bold)
     Text("${sessionElapsed/60}:${(sessionElapsed%60).toString().padStart(2,'0')}",fontSize=30.sp,fontWeight=FontWeight.Bold,color=Green)
     Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){
       Button(onClick={
         if(sessionRunning){sessionRunning=false;timerPrefs.edit().putBoolean("session_running_$timerKey",false).apply()}
         else {sessionStartedAt=System.currentTimeMillis();sessionRunning=true;timerPrefs.edit().putBoolean("session_running_$timerKey",true).putLong("session_started_$timerKey",sessionStartedAt).apply()}
       },colors=ButtonDefaults.buttonColors(containerColor=Green,contentColor=Bg)){Text(if(sessionRunning)"Pause workout" else "Resume workout")}
     }
     Spacer(Modifier.height(10.dp))
     Text(AppLanguage.text("REST TIMER", language),fontWeight=FontWeight.Bold)
     Text("${seconds/60}:${(seconds%60).toString().padStart(2,'0')}",fontSize=34.sp,fontWeight=FontWeight.Bold,color=Green)
     Row(horizontalArrangement=Arrangement.spacedBy(6.dp)){listOf(30,60,90,120,180).forEach{v->TextButton(onClick={seconds=v;restRunning=false;restDeadline=0L;timerPrefs.edit().putInt("rest_remaining_$timerKey",v).remove("rest_deadline_$timerKey").apply()}){Text("${v}s")}}
     }
     Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){
       Button(onClick={
         if(restRunning){seconds=((restDeadline-System.currentTimeMillis()).coerceAtLeast(0L)/1000L).toInt();restRunning=false;restDeadline=0L;timerPrefs.edit().putInt("rest_remaining_$timerKey",seconds).remove("rest_deadline_$timerKey").apply()}
         else {restDeadline=System.currentTimeMillis()+seconds*1000L;restRunning=true;timerPrefs.edit().putLong("rest_deadline_$timerKey",restDeadline).apply()}
       },colors=ButtonDefaults.buttonColors(containerColor=Green,contentColor=Bg)){Text(if(restRunning)"Pause rest" else "Start / Resume rest")}
       OutlinedButton(onClick={seconds+=30; if(restRunning){restDeadline+=30_000L;timerPrefs.edit().putLong("rest_deadline_$timerKey",restDeadline).apply()} else timerPrefs.edit().putInt("rest_remaining_$timerKey",seconds).apply()}){Text("+30s")}
       OutlinedButton(onClick={seconds=90;restRunning=false;restDeadline=0L;timerPrefs.edit().putInt("rest_remaining_$timerKey",90).remove("rest_deadline_$timerKey").apply()}){Text(AppLanguage.text("Reset", language))}
     }
   }}
   item{Button(onClick={onSave(ExerciseLog(day.day,e.name,todayStamp(),entries,sessionElapsed.coerceAtLeast(1),note));if(voiceGuided){val idx=day.exercises.indexOfFirst{it.name==e.name};val next=day.exercises.getOrNull(idx+1);if(next!=null){activity.keepSpeechOnExit=true;activity.speak("Next exercise: ${ExerciseLanguages.name(next.name,language)}",language)}};sessionRunning=false;timerPrefs.edit().putBoolean("session_running_$timerKey",false).remove("rest_deadline_$timerKey").remove("rest_remaining_$timerKey").remove("session_elapsed_$timerKey").remove("session_started_$timerKey").apply();onBack()},modifier=Modifier.fillMaxWidth().heightIn(min=58.dp),colors=ButtonDefaults.buttonColors(containerColor=Green,contentColor=Bg)){Text(AppLanguage.text("Save exercise log",language))}}
  }
 }
}

@Composable private fun ExerciseGifDemo(exercise: Exercise, language: String) {
    val context = LocalContext.current
    val imageLoader = remember(context) {
        ImageLoader.Builder(context)
            .components { add(GifDecoder.Factory()) }
            .build()
    }
    val assetPath = "exercise_gifs/${exercise.gifFileName}"
    var gifAvailable by remember(exercise.gifFileName) {
        mutableStateOf(runCatching { context.assets.open(assetPath).use { } ; true }.getOrDefault(false))
    }
    var playing by remember(exercise.gifFileName) { mutableStateOf(true) }
    var gifDrawable by remember(exercise.gifFileName) { mutableStateOf<DrawableAnimatable?>(null) }

    LaunchedEffect(playing, gifDrawable) {
        val drawable = gifDrawable ?: return@LaunchedEffect
        if (playing) drawable.start() else drawable.stop()
    }
    DisposableEffect(exercise.gifFileName) {
        onDispose { gifDrawable?.stop() }
    }

    PanelCard {
        Text("WATCH DEMO", color = Green, fontWeight = FontWeight.Bold, fontSize = 12.sp)
        Text(ExerciseLanguages.name(exercise.name, language), fontWeight = FontWeight.Bold, fontSize = 18.sp)
        if (gifAvailable) {
            AsyncImage(
                model = "file:///android_asset/$assetPath",
                imageLoader = imageLoader,
                contentDescription = "${exercise.name} exercise demonstration",
                modifier = Modifier.fillMaxWidth().aspectRatio(16f / 9f)
                    .background(Color(0xFF111A14), RoundedCornerShape(12.dp)),
                contentScale = androidx.compose.ui.layout.ContentScale.Fit,
                onSuccess = { state ->
                    gifDrawable = state.result.drawable as? DrawableAnimatable
                    if (playing) gifDrawable?.start()
                },
                onError = {
                    gifAvailable = false
                    gifDrawable = null
                }
            )
            OutlinedButton(
                onClick = { playing = !playing },
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(if (playing) Icons.Default.Pause else Icons.Default.PlayArrow, contentDescription = null)
                Text(if (playing) " Pause" else " Play")
            }
        } else {
            AnimationCard(language)
            Text("GIF not available for this exercise yet", color = Muted, fontSize = 12.sp)
        }
    }
}

@Composable private fun AnimationCard(language:String=AppLanguage.EN){
 val transition=rememberInfiniteTransition(label="rep")
 val angle by transition.animateFloat(-24f,24f,infiniteRepeatable(tween(950,easing=FastOutSlowInEasing),RepeatMode.Reverse),label="arm")
 PanelCard{Row(verticalAlignment=Alignment.CenterVertically){Text(AppLanguage.text("MOVEMENT PREVIEW", language),fontWeight=FontWeight.Bold,fontSize=11.sp);Spacer(Modifier.weight(1f));Text("LOOP",color=Green,fontSize=10.sp)};Box(Modifier.fillMaxWidth().height(130.dp).background(Color(0xFF111A14),RoundedCornerShape(14.dp)),contentAlignment=Alignment.Center){Column(horizontalAlignment=Alignment.CenterHorizontally){Box(Modifier.size(24.dp).background(Green,CircleShape));Box(Modifier.padding(top=3.dp).width(8.dp).height(42.dp).background(Green,RoundedCornerShape(5.dp)));Row(verticalAlignment=Alignment.CenterVertically){Box(Modifier.width(43.dp).height(7.dp).rotate(angle).background(Green,RoundedCornerShape(5.dp)));Box(Modifier.width(43.dp).height(7.dp).rotate(-angle).background(Green,RoundedCornerShape(5.dp)))}}};Text(AppLanguage.text("Illustrative movement cue, not a verified exercise animation. Use the written cues and demonstration.", language),color=Muted,fontSize=11.sp)}
}


@Composable private fun GymToolsAndReadinessCard(activity:ComponentActivity, bodyWeight:String, language:String=AppLanguage.EN) {
 val prefs=activity.getSharedPreferences("atif_tools",0)
 var barWeight by remember { mutableStateOf("20") }
 var targetWeight by remember { mutableStateOf("60") }
 var plateSizes by remember { mutableStateOf("20,15,10,5,2.5,1.25") }
 var workingWeight by remember { mutableStateOf("60") }
 var reps by remember { mutableStateOf("8") }
 var unit by remember { mutableStateOf(prefs.getString("unit","kg") ?: "kg") }
 var mode by remember { mutableStateOf(prefs.getString("training_mode","Normal") ?: "Normal") }
 var sleep by remember { mutableStateOf(prefs.getString("readiness_sleep","7") ?: "7") }
 var soreness by remember { mutableStateOf(prefs.getString("readiness_soreness","2") ?: "2") }
 var energy by remember { mutableStateOf(prefs.getString("readiness_energy","4") ?: "4") }
 var painNote by remember { mutableStateOf(prefs.getString("pain_note","") ?: "") }
 val target=targetWeight.toDoubleOrNull()?:0.0
 val bar=barWeight.toDoubleOrNull()?:20.0
 val perSide=((target-bar)/2.0).coerceAtLeast(0.0)
 val plates=plateSizes.split(",").mapNotNull{it.trim().toDoubleOrNull()}.filter{it>0}.sortedDescending()
 var remainder=perSide
 val chosen=mutableListOf<Double>()
 plates.forEach { p -> while(remainder+0.0001>=p){chosen.add(p);remainder-=p} }
 val w=workingWeight.toDoubleOrNull()?:0.0
 val r=reps.toIntOrNull()?.coerceAtLeast(1)?:1
 val oneRm=w*(1.0+r/30.0)
 val score=(sleep.toDoubleOrNull()?.coerceIn(0.0,10.0)?:0.0)+(energy.toDoubleOrNull()?.coerceIn(0.0,5.0)?:0.0)-(soreness.toDoubleOrNull()?.coerceIn(0.0,10.0)?:0.0)*0.7
 val readiness=when{score>=9->"Good readiness";score>=5->"Moderate readiness";else->"Low readiness"}
 PanelCard {
  Text(AppLanguage.text("GYM TOOLS", language),color=Green,fontWeight=FontWeight.Bold)
  Text(AppLanguage.text("Plate calculator", language),fontWeight=FontWeight.SemiBold)
  Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){
   OutlinedTextField(barWeight,{barWeight=it.filter{c->c.isDigit()||c=='.'}},Modifier.weight(1f),label={Text("Bar weight ($unit)")} ,singleLine=true)
   OutlinedTextField(targetWeight,{targetWeight=it.filter{c->c.isDigit()||c=='.'}},Modifier.weight(1f),label={Text("Total target ($unit)")} ,singleLine=true)
  }
  OutlinedTextField(plateSizes,{plateSizes=it},Modifier.fillMaxWidth(),label={Text("Available plates ($unit), comma separated")} ,singleLine=true)
  Text(if(target<bar) "Target is below bar weight." else "Each side: "+chosen.joinToString(" + "){"${it}$unit"}+(if(remainder>0.01)" · ${"%.2f".format(remainder)}$unit unmatched" else ""),color=Green,fontSize=12.sp)
  Divider(color=Bg)
  Text(AppLanguage.text("Warm-up calculator", language),fontWeight=FontWeight.SemiBold)
  OutlinedTextField(workingWeight,{workingWeight=it.filter{c->c.isDigit()||c=='.'}},label={Text("Working weight ($unit)")} ,singleLine=true)
  Text("Suggested ramp-up: ${"%.1f".format(w*.4)}kg × 8, ${"%.1f".format(w*.6)}kg × 5, ${"%.1f".format(w*.8)}kg × 3, then ${"%.1f".format(w)}kg working sets.",color=Muted,fontSize=12.sp)
  Divider(color=Bg)
  Text(AppLanguage.text("Estimated 1RM (Epley)", language),fontWeight=FontWeight.SemiBold)
  Row(horizontalArrangement=Arrangement.spacedBy(8.dp),verticalAlignment=Alignment.CenterVertically){
   OutlinedTextField(workingWeight,{workingWeight=it.filter{c->c.isDigit()||c=='.'}},Modifier.weight(1f),label={Text("Weight ($unit)")} ,singleLine=true)
   OutlinedTextField(reps,{reps=it.filter(Char::isDigit).take(2)},Modifier.weight(1f),label={Text(AppLanguage.text("Reps", language))},singleLine=true)
  }
  Text("Estimated 1RM: ${"%.1f".format(oneRm)} $unit",color=Green,fontWeight=FontWeight.Bold)
  Divider(color=Bg)
  Text(AppLanguage.text("Unit preference", language),fontWeight=FontWeight.SemiBold)
  Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){listOf("kg","lb").forEach{FilterChip(selected=unit==it,onClick={unit=it;prefs.edit().putString("unit",it).apply();activity.getSharedPreferences("atif",0).edit().putString("unit",it).apply()},label={Text(it.uppercase())})}}
  Text("Loads are stored in kg. Displayed weights, volume and PRs convert to $unit; tool inputs are entered in $unit.",color=Muted,fontSize=10.sp)
  Divider(color=Bg)
  Text(AppLanguage.text("Training mode", language),fontWeight=FontWeight.SemiBold)
  Row(horizontalArrangement=Arrangement.spacedBy(6.dp),modifier=Modifier.horizontalScroll(rememberScrollState())){listOf("Normal","Exam","Ramadan","Travel").forEach{FilterChip(selected=mode==it,onClick={mode=it;prefs.edit().putString("training_mode",it).apply()},label={Text(it)})}}
  Text(when(mode){"Exam"->"Exam mode: keep sessions short, reduce optional accessory volume and protect study/sleep time. This is guidance only; it does not automatically rewrite your routine.";"Ramadan"->"Ramadan mode: consider lower intensity, shorter sessions and training after iftar or when hydration is possible.";"Travel"->"Travel mode: choose bodyweight or available equipment and avoid assuming full gym access.";else->"Normal training mode."},color=Muted,fontSize=11.sp)
  Divider(color=Bg)
  Text(AppLanguage.text("Readiness check", language),fontWeight=FontWeight.SemiBold)
  Row(horizontalArrangement=Arrangement.spacedBy(6.dp)){
   OutlinedTextField(sleep,{sleep=it.filter{c->c.isDigit()||c=='.'}},Modifier.weight(1f),label={Text(AppLanguage.text("Sleep hours", language))},singleLine=true)
   OutlinedTextField(soreness,{soreness=it.filter(Char::isDigit)},Modifier.weight(1f),label={Text(AppLanguage.text("Soreness 0-10", language))},singleLine=true)
   OutlinedTextField(energy,{energy=it.filter(Char::isDigit)},Modifier.weight(1f),label={Text(AppLanguage.text("Energy 0-5", language))},singleLine=true)
  }
  Text(readiness,color=if(score>=9)Green else Color(0xFFFFC266),fontWeight=FontWeight.Bold)
  Text(AppLanguage.text("Rule-based estimate only, not a medical assessment.", language),color=Muted,fontSize=10.sp)
  Button(onClick={prefs.edit().putString("readiness_sleep",sleep).putString("readiness_soreness",soreness).putString("readiness_energy",energy).apply()},modifier=Modifier.fillMaxWidth(),colors=ButtonDefaults.buttonColors(containerColor=Green,contentColor=Bg)){Text(AppLanguage.text("Save readiness", language))}
  Divider(color=Bg)
  Text(AppLanguage.text("Pain / injury note", language),fontWeight=FontWeight.SemiBold)
  OutlinedTextField(painNote,{painNote=it},Modifier.fillMaxWidth(),label={Text(AppLanguage.text("Record discomfort or movement to avoid", language))},minLines=2)
  Button(onClick={prefs.edit().putString("pain_note",painNote).apply()},modifier=Modifier.fillMaxWidth(),colors=ButtonDefaults.buttonColors(containerColor=Panel,contentColor=Green)){Text(AppLanguage.text("Save pain note", language))}
 }
}

@Composable private fun WeeklyReportCard(logs:List<ExerciseLog>, activity: ComponentActivity? = null, language:String=AppLanguage.EN) {
 val fmt=java.text.SimpleDateFormat("yyyy-MM-dd",java.util.Locale.US)
 val cal=java.util.Calendar.getInstance()
 cal.set(java.util.Calendar.DAY_OF_WEEK,cal.firstDayOfWeek)
 cal.set(java.util.Calendar.HOUR_OF_DAY,0);cal.set(java.util.Calendar.MINUTE,0);cal.set(java.util.Calendar.SECOND,0)
 val start=fmt.format(cal.time)
 val weekly=logs.filter{it.date>=start}
 val sets=weekly.flatMap{it.sets}.filter{it.done}
 val volume=sets.sumOf{(it.weight.toDoubleOrNull()?:0.0)*(it.reps.toDoubleOrNull()?:0.0)}
 val sessions=weekly.map{it.date}.distinct().size
 val pr=logs.flatMap{l->l.sets.filter{it.done}.mapNotNull{s->s.weight.toDoubleOrNull()?.let{Triple(l.exercise,it,s.reps.toIntOrNull()?:0)}}}
  .groupBy{it.first}.mapNotNull{(name,items)->items.maxByOrNull{it.second}?.let{name to it.second}}
 PanelCard {
  Text("THIS WEEK'S REPORT",color=Green,fontWeight=FontWeight.Bold)
  Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){
   StatCard("SESSIONS","$sessions",Modifier.weight(1f))
   StatCard("WORKING SETS","${sets.size}",Modifier.weight(1f))
   StatCard("VOLUME","${volume.toLong()} kg",Modifier.weight(1f))
  }
  Text("Best recorded loads",fontWeight=FontWeight.SemiBold)
  if(pr.isEmpty())Text("Log completed sets to build your report.",color=Muted,fontSize=11.sp)
  else pr.sortedByDescending{it.second}.take(5).forEach{Text("${it.first}: ${it.second} kg",color=Muted,fontSize=11.sp)}
  Text("Report is calculated from dates stored in your workout history. It does not infer missed workouts.",color=Muted,fontSize=10.sp)
  OutlinedButton(onClick={
    val text = "ATIF FITNESS - this week's report\nSessions: $sessions\nWorking sets: ${sets.size}\nVolume: ${volume.toLong()} kg\n" + pr.sortedByDescending{it.second}.take(5).joinToString("\n") { "${it.first}: ${it.second} kg" }
    val send = Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_SUBJECT, "ATIF FITNESS weekly report"); putExtra(Intent.EXTRA_TEXT, text) }
    activity?.startActivity(Intent.createChooser(send, "Share weekly report"))
  }, modifier = Modifier.fillMaxWidth()) { Text(AppLanguage.text("Share weekly report", language)) }
 }
}


@Composable private fun TrainingMilestonesCard(logs:List<ExerciseLog>, language:String=AppLanguage.EN) {
 val dates=logs.map{it.date.take(10)}.distinct().sortedDescending()
 val today=java.text.SimpleDateFormat("yyyy-MM-dd",java.util.Locale.US).format(java.util.Date())
 val yesterdayCal=java.util.Calendar.getInstance().apply{add(java.util.Calendar.DAY_OF_YEAR,-1)}
 val yesterday=java.text.SimpleDateFormat("yyyy-MM-dd",java.util.Locale.US).format(yesterdayCal.time)
 var streak=0
 var expected=if(dates.firstOrNull()==today) today else if(dates.firstOrNull()==yesterday) yesterday else ""
 if(expected.isNotBlank()) {
   val cursor=java.text.SimpleDateFormat("yyyy-MM-dd",java.util.Locale.US)
   for(d in dates) {
     if(d==expected) {
       streak++
       val parsed=cursor.parse(expected) ?: break
       val c=java.util.Calendar.getInstance().apply{time=parsed;add(java.util.Calendar.DAY_OF_YEAR,-1)}
       expected=cursor.format(c.time)
     } else if(d<expected) break
   }
 }
 val sessions=dates.size
 val completedSets=logs.flatMap{it.sets}.count{it.done}
 val volume=logs.flatMap{it.sets}.filter{it.done}.sumOf{(it.weight.toDoubleOrNull()?:0.0)*(it.reps.toDoubleOrNull()?:0.0)}
 val badges=listOf(
   Triple("First session",sessions>=1,"Log your first workout"),
   Triple("10 sessions",sessions>=10,"Build a training habit"),
   Triple("25 sessions",sessions>=25,"Keep showing up"),
   Triple("50 sessions",sessions>=50,"Consistent training"),
   Triple("100 sessions",sessions>=100,"Long-term commitment"),
   Triple("10,000 kg volume",volume>=10000,"Completed-set load × reps")
 )
 PanelCard {
   Text(AppLanguage.text("STREAK & ACHIEVEMENTS", language),color=Green,fontWeight=FontWeight.Bold)
   Row(horizontalArrangement=Arrangement.spacedBy(8.dp),modifier=Modifier.fillMaxWidth()) {
     StatCard("CURRENT STREAK","$streak days",Modifier.weight(1f))
     StatCard("TOTAL SESSIONS","$sessions",Modifier.weight(1f))
     StatCard("COMPLETED SETS","$completedSets",Modifier.weight(1f))
   }
   Text(AppLanguage.text("Achievements", language),fontWeight=FontWeight.SemiBold,modifier=Modifier.padding(top=10.dp))
   badges.forEach{(name,unlocked,description)->
     Row(Modifier.fillMaxWidth().padding(top=7.dp),verticalAlignment=Alignment.CenterVertically) {
       Text(if(unlocked) "✓" else "○",color=if(unlocked)Green else Muted,fontWeight=FontWeight.Bold)
       Column(Modifier.weight(1f).padding(start=9.dp)) {
         Text(name,fontSize=12.sp,fontWeight=FontWeight.SemiBold,color=if(unlocked)Green else Color.White)
         Text(description,fontSize=10.sp,color=Muted)
       }
       Text(if(unlocked)"UNLOCKED" else "LOCKED",fontSize=9.sp,color=Muted)
     }
   }
   Text("Streak uses consecutive calendar dates with at least one saved exercise log. It is a motivation metric, not a training target.",color=Muted,fontSize=10.sp,modifier=Modifier.padding(top=8.dp))
 }
}

@Composable private fun WeightHistoryCard(activity: ComponentActivity, language:String=AppLanguage.EN) {
    val history = loadWeightHistory(activity)
    val weekly = history.groupBy { it.first.take(7) + "W" + (java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US).parse(it.first)?.let { d -> val c = java.util.Calendar.getInstance().apply { time = d }; c.get(java.util.Calendar.WEEK_OF_YEAR) } ?: 0) }
        .toSortedMap().mapValues { (_, v) -> v.map { it.second }.average() }.toList().takeLast(8)
    PanelCard {
        Text(AppLanguage.text("BODY WEIGHT — WEEKLY AVERAGE", language), color = Green, fontWeight = FontWeight.Bold)
        if (weekly.isEmpty()) Text(AppLanguage.text("Change your body weight once to start the history. Weekly averages appear after the first week.", language), color = Muted, fontSize = 12.sp)
        else {
            val maxV = (weekly.maxOfOrNull { it.second } ?: 1.0).coerceAtLeast(1.0)
            val minV = (weekly.minOfOrNull { it.second } ?: 0.0).coerceAtLeast(0.0)
            Row(Modifier.fillMaxWidth().height(120.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.Bottom) {
                weekly.forEach { (label, avg) ->
                    val h = ((avg - minV).coerceAtLeast(0.0) / (maxV - minV).coerceAtLeast(1.0) * 80.0 + 20.0).toFloat()
                    Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Alignment.Bottom) {
                        Text("%.1f".format(avg), fontSize = 9.sp, color = Green)
                        Box(Modifier.fillMaxWidth().height(h.dp).background(Green, RoundedCornerShape(topStart = 6.dp, topEnd = 6.dp)))
                        Text(label.takeLast(2), fontSize = 9.sp, color = Muted)
                    }
                }
            }
            Text("Weekly average smooths daily water / food swings. Latest average: ${"%.1f".format(weekly.last().second)} kg.", color = Muted, fontSize = 11.sp, modifier = Modifier.padding(top = 6.dp))
        }
    }
}

@Composable private fun ExerciseStrengthCard(logs: List<ExerciseLog>, activity: ComponentActivity, language:String=AppLanguage.EN) {
    val names = logs.map { it.exercise }.distinct().sorted()
    var selected by remember { mutableStateOf(names.firstOrNull() ?: "") }
    val sessions = logs.filter { it.exercise == selected }.sortedBy { it.date }
        .map { l -> l.date.take(10) to (l.sets.filter { it.done }.mapNotNull { it.weight.toDoubleOrNull() }.maxOrNull() ?: 0.0) }
        .filter { it.second > 0.0 }.takeLast(10)
    PanelCard {
        Text(AppLanguage.text("STRENGTH BY EXERCISE", language), color = Green, fontWeight = FontWeight.Bold)
        if (names.isEmpty()) Text(AppLanguage.text("Log completed sets to see a per-exercise strength graph.", language), color = Muted, fontSize = 12.sp)
        else {
            var expanded by remember { mutableStateOf(false) }
            Box {
                OutlinedButton(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth()) {
                    Text(ExerciseLanguages.name(selected, language)); Spacer(Modifier.weight(1f)); Icon(Icons.Default.ArrowDropDown, null)
                }
                DropdownMenu(expanded, { expanded = false }) {
                    names.forEach { n -> DropdownMenuItem(text = { Text(n) }, onClick = { selected = n; expanded = false }) }
                }
            }
            if (sessions.isEmpty()) Text(AppLanguage.text("No completed sets with a numeric weight for this exercise yet.", language), color = Muted, fontSize = 12.sp)
            else {
                val unit = WeightUnits.current(activity)
                val maxV = (sessions.maxOfOrNull { it.second } ?: 1.0).coerceAtLeast(1.0)
                Row(Modifier.fillMaxWidth().height(120.dp).padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.Bottom) {
                    sessions.forEach { (date, best) ->
                        Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Alignment.Bottom) {
                            Text(WeightUnits.displayKg(best, unit), fontSize = 8.sp, color = Green)
                            Box(Modifier.fillMaxWidth().height(((best / maxV) * 90.0 + 10.0).toFloat().dp).background(Green, RoundedCornerShape(topStart = 5.dp, topEnd = 5.dp)))
                            Text(date.substring(5), fontSize = 8.sp, color = Muted)
                        }
                    }
                }
                Text(AppLanguage.text("Best completed set per session, heaviest first. Dates are month-day.", language), color = Muted, fontSize = 10.sp, modifier = Modifier.padding(top = 6.dp))
            }
        }
    }
}

@Composable private fun ColumnScope.ProgressScreen(done:Set<String>,logs:List<ExerciseLog>,activity:ComponentActivity,weight:String,language:String){
 val allSets=logs.flatMap{it.sets}.filter{it.done}
 val volume=allSets.sumOf{(it.weight.toDoubleOrNull()?:0.0)*(it.reps.toDoubleOrNull()?:0.0)}
 val total=plans.sumOf{it.exercises.size};val pct=if(total==0)0 else done.size*100/total
 val prs=logs.flatMap{l->l.sets.filter{it.done}.mapNotNull{s->s.weight.toDoubleOrNull()?.let{Triple(l.exercise,it,s.reps.toIntOrNull()?:0)}}}.groupBy{it.first}
 val latestByExercise=logs.groupBy{it.exercise}
 val overload=latestByExercise.mapNotNull { (name, sessions) ->
   val sorted=sessions.sortedBy{it.date}
   if(sorted.size<2) null else {
     val a=sorted[sorted.lastIndex-1].sets.filter{it.done}
     val b=sorted.last().sets.filter{it.done}
     val oldTop=a.mapNotNull{it.reps.toIntOrNull()}.maxOrNull()?:0
     val newTop=b.mapNotNull{it.reps.toIntOrNull()}.maxOrNull()?:0
     val oldLoad=a.mapNotNull{it.weight.toDoubleOrNull()}.maxOrNull()?:0.0
     val newLoad=b.mapNotNull{it.weight.toDoubleOrNull()}.maxOrNull()?:0.0
     Triple(name,oldTop,newTop to (newLoad-oldLoad))
   }
 }
 val plateau=latestByExercise.filterValues{it.size>=3}.filter{(_,ss)->
   val last=ss.sortedBy{it.date}.takeLast(3)
   val scores=last.map{l->l.sets.filter{it.done}.sumOf{(it.weight.toDoubleOrNull()?:0.0)*(it.reps.toDoubleOrNull()?:0.0)}}
   scores.size==3 && scores.maxOrNull()!!-scores.minOrNull()!!<0.001
 }.keys
 val muscleSets=logs.flatMap{l->l.sets.filter{it.done}.map{l.exercise}}.groupingBy{exercise->plans.flatMap{it.exercises}.firstOrNull{it.name==exercise}?.muscle?.substringBefore(" · ")?: "Other"}.eachCount()
 LazyColumn(Modifier.weight(1f),contentPadding=PaddingValues(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
  item{Header("Progress & coaching","Training trends, overload guidance and recovery signals",language)}
  item{WeeklyReportCard(logs, activity, language)}
  item{TrainingMilestonesCard(logs,language)}
  item{Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){StatCard("LOGGED SETS","${allSets.size}",Modifier.weight(1f));StatCard("TOTAL VOLUME",WeightUnits.displayKg(volume,WeightUnits.current(activity)),Modifier.weight(1f));StatCard("EXERCISES","${logs.map{it.exercise}.distinct().size}",Modifier.weight(1f))}}
  item{PanelCard{Text(AppLanguage.text("PROGRESSIVE OVERLOAD", language),color=Green,fontWeight=FontWeight.Bold);Text("Double progression",fontSize=18.sp,fontWeight=FontWeight.Bold);Text("Keep the same load while building reps inside the target range. When every working set reaches the top of the range with clean form, increase the load by the smallest practical amount next time.",color=Muted,fontSize=12.sp);overload.takeLast(5).forEach{(name,old,new)->Text("$name · reps $old → ${new.first}; load change ${"%.1f".format(new.second)} kg",Modifier.padding(top=7.dp),fontSize=11.sp,color=Green)};if(overload.isEmpty())Text(AppLanguage.text("Log at least two sessions of an exercise to get a comparison.", language),color=Muted,fontSize=11.sp)}}
  item{PanelCard{Text("PLATEAU / DELOAD CHECK",fontWeight=FontWeight.Bold);if(plateau.isEmpty())Text("No clear plateau detected from the available logs. This is a simple flag, not a diagnosis.",color=Muted,fontSize=12.sp) else {Text("Similar logged volume across 3 sessions:",color=Muted,fontSize=12.sp);plateau.forEach{Text("• $it",color=Green,fontSize=12.sp)};Text("Consider checking sleep, food, technique and fatigue. If performance and recovery are poor, discuss a lighter deload week rather than forcing more load.",color=Muted,fontSize=11.sp)}}}
  item{PanelCard{Text(AppLanguage.text("WORKING SETS BY MUSCLE GROUP", language),fontWeight=FontWeight.Bold);if(muscleSets.isEmpty())Text("Log working sets to see muscle-group totals.",color=Muted,fontSize=12.sp) else muscleSets.toList().sortedByDescending{it.second}.forEach{(muscle,count)->Column(Modifier.padding(top=8.dp)){Row{Text(muscle,Modifier.weight(1f),fontSize=12.sp);Text("$count sets",color=Green,fontSize=12.sp)};LinearProgressIndicator(progress={(count.toFloat()/(muscleSets.values.maxOrNull()?:1)).coerceIn(0f,1f)},Modifier.fillMaxWidth().padding(top=4.dp),color=Green,trackColor=Bg)}}}}
  item{PanelCard{Text(AppLanguage.text("PLAN CHECK-OFFS", language),color=Green,fontWeight=FontWeight.Bold);Text("${done.size} / $total exercises checked",fontSize=20.sp,fontWeight=FontWeight.Bold);LinearProgressIndicator(progress={pct/100f},modifier=Modifier.fillMaxWidth().padding(vertical=10.dp),color=Green,trackColor=Bg)}}
  item{PanelCard{Text(AppLanguage.text("PERSONAL BESTS", language),fontWeight=FontWeight.Bold);if(prs.isEmpty())Text("Log completed sets with weight and reps to build your records.",color=Muted,fontSize=12.sp) else prs.entries.sortedBy{it.key}.forEach{(name,items)->val best=items.maxByOrNull{it.second}!!;Text("$name · ${WeightUnits.displayKg(best.second,WeightUnits.current(activity))} × ${best.third} reps",Modifier.padding(top=7.dp),fontSize=12.sp,color=Green)}}}
  item{ExerciseStrengthCard(logs,activity,language)}
  item{PanelCard{Text(AppLanguage.text("RECENT TRAINING VOLUME", language),fontWeight=FontWeight.Bold);val daily=logs.groupBy{it.date.take(10)}.toSortedMap().values.toList().takeLast(7);val volumes=daily.map{d->d.sumOf{l->l.sets.filter{it.done}.sumOf{(it.weight.toDoubleOrNull()?:0.0)*(it.reps.toDoubleOrNull()?:0.0)}}};if(volumes.isEmpty())Text(AppLanguage.text("Complete workouts to build your volume graph.", language),color=Muted,fontSize=12.sp) else Row(Modifier.fillMaxWidth().height(120.dp),horizontalArrangement=Arrangement.spacedBy(8.dp),verticalAlignment=Alignment.Bottom){val maxV=(volumes.maxOrNull()?:1.0).coerceAtLeast(1.0);volumes.forEachIndexed{i,v->Column(Modifier.weight(1f),horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.Bottom){Box(Modifier.fillMaxWidth().height((100.0*v/maxV).toFloat().coerceAtLeast(4f).dp).background(Green,RoundedCornerShape(topStart=6.dp,topEnd=6.dp)));Text("${i+1}",fontSize=9.sp,color=Muted)}}};Text("Estimated load × reps, based only on completed sets with numeric values.",color=Muted,fontSize=10.sp)}}
   item {
     val kg = weight.toDoubleOrNull() ?: 78.0
     val protein = (kg * 1.8).toInt()
     val lastDate = logs.maxOfOrNull { it.date.take(10) }
     PanelCard {
       Text("ATIF COACH", color=Green, fontWeight=FontWeight.Bold)
       Text(AppLanguage.text("Today's guidance", language), fontSize=18.sp, fontWeight=FontWeight.Bold)
       Text(
         when {
           lastDate == null -> "Log your first workout to unlock training guidance."
           lastDate == java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US).format(java.util.Date()) -> "You trained today. Prioritize food, fluids and sleep, then recover."
           else -> "Follow your planned split if you feel recovered. Do not cram missed sessions into one day."
         }, color=Muted, fontSize=13.sp
       )
       Text("Protein guide: about $protein g/day based on your current body weight.", color=Muted, fontSize=13.sp, modifier=Modifier.padding(top=6.dp))
       Text("Rule-based guidance from on-device logs. It cannot measure soreness, sleep or readiness.", color=Muted, fontSize=11.sp, modifier=Modifier.padding(top=6.dp))
     }
   }
 }
}
private data class FoodItem(val name:String,val kcal:Int,val protein:Double,val carbs:Double,val fat:Double,val unit:String)
private val pakFoods=listOf(
 FoodItem("Egg, 1 large",72,6.3,0.4,4.8,"egg"),
 FoodItem("Milk, 250 ml",150,8.0,12.0,8.0,"glass"),
 FoodItem("Chicken breast, cooked 100 g",165,31.0,0.0,3.6,"100 g"),
 FoodItem("Chicken karahi, 1 serving",320,27.0,8.0,19.0,"serving"),
 FoodItem("Daal, 1 cup",230,15.0,40.0,1.0,"cup"),
 FoodItem("Roti, medium",120,3.5,24.0,1.5,"roti"),
 FoodItem("Cooked rice, 1 cup",205,4.3,45.0,0.4,"cup"),
 FoodItem("Plain dahi, 200 g",120,7.0,9.0,6.0,"bowl"),
 FoodItem("Banana, medium",105,1.3,27.0,0.4,"banana"),
 FoodItem("Peanuts, 30 g",170,7.0,6.0,14.0,"portion"),
 FoodItem("Whey protein, 1 scoop",120,24.0,3.0,1.5,"scoop")
)
private fun loadCustomFoods(activity: ComponentActivity): List<FoodItem> = try {
    val arr = JSONArray(activity.getSharedPreferences("atif_custom_foods", 0).getString("items", "[]") ?: "[]")
    (0 until arr.length()).mapNotNull { i ->
        val o = arr.optJSONObject(i) ?: return@mapNotNull null
        FoodItem(o.optString("name"), o.optInt("kcal"), o.optDouble("protein"), o.optDouble("carbs"), o.optDouble("fat"), o.optString("unit", "serving"))
    }.filter { it.name.isNotBlank() }
} catch (_: Exception) { emptyList() }
private fun saveCustomFoods(activity: ComponentActivity, foods: List<FoodItem>) {
    val arr = JSONArray()
    foods.forEach { f -> arr.put(JSONObject().put("name", f.name).put("kcal", f.kcal).put("protein", f.protein).put("carbs", f.carbs).put("fat", f.fat).put("unit", f.unit)) }
    activity.getSharedPreferences("atif_custom_foods", 0).edit().putString("items", arr.toString()).apply()
}

@Composable private fun ColumnScope.NutritionScreen(activity:ComponentActivity,weight:String,language:String){
 val prefs=activity.getSharedPreferences("atif",0)
 val today=java.text.SimpleDateFormat("yyyy-MM-dd",java.util.Locale.US).format(java.util.Date())
 var diary by remember { mutableStateOf(prefs.getString("food_day","")?.let{if(it==today)prefs.getString("food_json","[]") else "[]"} ?: "[]") }
 var water by remember { mutableStateOf(if(prefs.getString("water_day","")==today)prefs.getInt("water_glasses",0) else 0) }
 var foodIndex by remember{mutableIntStateOf(0)}
 var servings by remember{mutableStateOf("1")}
 var customFoods by remember{mutableStateOf(loadCustomFoods(activity))}
 val allFoods = remember(customFoods) { pakFoods + customFoods }
 var newFoodName by remember{mutableStateOf("")}
 var newFoodKcal by remember{mutableStateOf("")}
 var newFoodProtein by remember{mutableStateOf("")}
 var newFoodCarbs by remember{mutableStateOf("")}
 var newFoodFat by remember{mutableStateOf("")}
 val entries=remember(diary){try{val a=JSONArray(diary);(0 until a.length()).map{a.getJSONObject(it)}}catch(_:Exception){emptyList()}}
 val kcal=entries.sumOf{it.optDouble("kcal")};val protein=entries.sumOf{it.optDouble("protein")};val carbs=entries.sumOf{it.optDouble("carbs")};val fat=entries.sumOf{it.optDouble("fat")}
 val kg=weight.toDoubleOrNull()?:78.0
 val proteinTarget=kg*1.8
 val waterTarget=kg*0.035
 fun saveDiary(v:String){diary=v;prefs.edit().putString("food_day",today).putString("food_json",v).apply()}
 LazyColumn(Modifier.weight(1f),contentPadding=PaddingValues(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
  item{Header("Nutrition & recovery","Pakistani food estimates, daily macros and hydration",language)}
  item{PanelCard{Text(AppLanguage.text("MUSCLE-GAIN DAILY TARGET", language),color=Green,fontWeight=FontWeight.Bold);Text("${proteinTarget.toInt()}–${(kg*2.0).toInt()} g protein",fontSize=22.sp,fontWeight=FontWeight.Bold);Text("Based on current body weight (${kg.toInt()} kg), using a 1.8–2.0 g/kg planning range. Calories should be adjusted using 2–3 weeks of weight trend.",color=Muted,fontSize=11.sp)}}
  item{PanelCard{Text(AppLanguage.text("CALORIE TARGET", language),color=Green,fontWeight=FontWeight.Bold);val calorieTarget=((kg*33.0)+300.0).toInt();Text("${kcal.toInt()} / $calorieTarget kcal",fontSize=22.sp,fontWeight=FontWeight.Bold);LinearProgressIndicator(progress={(kcal/calorieTarget.toFloat()).coerceIn(0f,1f)},Modifier.fillMaxWidth().padding(top=8.dp),color=Green,trackColor=Bg);Text(AppLanguage.text("Muscle-gain target: about",language)+" ${kg.toInt()} kg x 33 kcal + 300 kcal surplus. This is a planning estimate, not a prescription; adjust from 2-3 weeks of weight trend.",color=Muted,fontSize=11.sp)}}
  item{PanelCard{Text(AppLanguage.text("ADD YOUR OWN FOOD", language),fontWeight=FontWeight.Bold);OutlinedTextField(newFoodName,{newFoodName=it},Modifier.fillMaxWidth(),singleLine=true,label={Text("Food name")});Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){OutlinedTextField(newFoodKcal,{newFoodKcal=it.filter{c->c.isDigit()}},Modifier.weight(1f),singleLine=true,label={Text("kcal")});OutlinedTextField(newFoodProtein,{newFoodProtein=it.filter{c->c.isDigit()||c=='.'}},Modifier.weight(1f),singleLine=true,label={Text("protein g")})};Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){OutlinedTextField(newFoodCarbs,{newFoodCarbs=it.filter{c->c.isDigit()||c=='.'}},Modifier.weight(1f),singleLine=true,label={Text("carbs g")});OutlinedTextField(newFoodFat,{newFoodFat=it.filter{c->c.isDigit()||c=='.'}},Modifier.weight(1f),singleLine=true,label={Text("fat g")})};Button(onClick={val n=newFoodName.trim();val k=newFoodKcal.toIntOrNull();if(n.isNotBlank() && k!=null && k>0){val item=FoodItem(n,k,newFoodProtein.toDoubleOrNull()?:0.0,newFoodCarbs.toDoubleOrNull()?:0.0,newFoodFat.toDoubleOrNull()?:0.0,"serving");customFoods=customFoods+item;saveCustomFoods(activity,customFoods);newFoodName="";newFoodKcal="";newFoodProtein="";newFoodCarbs="";newFoodFat=""}},modifier=Modifier.fillMaxWidth(),colors=ButtonDefaults.buttonColors(containerColor=Green,contentColor=Bg)){Text(AppLanguage.text("Save custom food", language))};Text(AppLanguage.text("Custom foods are saved on this phone and appear in the quick-add list. Values are your own estimates.", language),color=Muted,fontSize=10.sp)}}
  item{PanelCard{Text(AppLanguage.text("TODAY'S MACROS", language),fontWeight=FontWeight.Bold);Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){StatCard("CALORIES","${kcal.toInt()} kcal",Modifier.weight(1f));StatCard("PROTEIN","${protein.toInt()} g",Modifier.weight(1f))};Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){StatCard("CARBS","${carbs.toInt()} g",Modifier.weight(1f));StatCard("FAT","${fat.toInt()} g",Modifier.weight(1f))};LinearProgressIndicator(progress={(protein/proteinTarget).toFloat().coerceIn(0f,1f)},Modifier.fillMaxWidth().padding(top=8.dp),color=Green,trackColor=Bg);Text("${protein.toInt()} / ${proteinTarget.toInt()} g protein",color=Muted,fontSize=11.sp)}}
  item{PanelCard{Text(AppLanguage.text("PAKISTANI FOOD QUICK ADD", language),fontWeight=FontWeight.Bold);var expanded by remember{mutableStateOf(false)};Box{OutlinedButton(onClick={expanded=true},modifier=Modifier.fillMaxWidth()){Text(allFoods[foodIndex].name);Spacer(Modifier.weight(1f));Icon(Icons.Default.ArrowDropDown,null)};DropdownMenu(expanded,{expanded=false}){allFoods.forEachIndexed{i,f->DropdownMenuItem(text={Text(f.name)},onClick={foodIndex=i;expanded=false})}}};OutlinedTextField(servings,{servings=it.filter{c->c.isDigit()||c=='.'}},modifier=Modifier.fillMaxWidth(),singleLine=true,label={Text(AppLanguage.text("Servings / portions", language))});Button(onClick={val n=servings.toDoubleOrNull()?:1.0;if(n>0){val f=allFoods[foodIndex];val a=JSONArray(diary);a.put(JSONObject().put("name",f.name).put("kcal",f.kcal*n).put("protein",f.protein*n).put("carbs",f.carbs*n).put("fat",f.fat*n));saveDiary(a.toString());servings="1"}},modifier=Modifier.fillMaxWidth(),colors=ButtonDefaults.buttonColors(containerColor=Green,contentColor=Bg)){Text(AppLanguage.text("Add food", language))};Text("Values are approximate averages. Recipe, oil, portion size and cooking method can change them substantially.",color=Muted,fontSize=10.sp)}}
  item{PanelCard{Text(AppLanguage.text("TODAY'S FOOD LOG", language),fontWeight=FontWeight.Bold);if(entries.isEmpty())Text(AppLanguage.text("Nothing logged yet.", language),color=Muted,fontSize=12.sp) else entries.forEachIndexed{i,o->Row(Modifier.fillMaxWidth().padding(top=8.dp),verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text(o.optString("name"),fontSize=12.sp,fontWeight=FontWeight.SemiBold);Text("${o.optDouble("kcal").toInt()} kcal · ${o.optDouble("protein").toInt()} g protein",fontSize=10.sp,color=Muted)};TextButton(onClick={val a=JSONArray(diary);a.remove(i);saveDiary(a.toString())}){Text(AppLanguage.text("Remove", language),color=Color(0xFFFF8A80))}}}}}
  item{PanelCard{Text(AppLanguage.text("WATER TRACKER", language),fontWeight=FontWeight.Bold);Text("Planning target: ${"%.1f".format(waterTarget)} L/day (35 ml/kg baseline; adjust for heat, sweat and medical advice).",color=Muted,fontSize=11.sp);Text("${water*250} ml / ${ (waterTarget*1000).toInt()} ml",fontSize=22.sp,color=Green,fontWeight=FontWeight.Bold);LinearProgressIndicator(progress={(water*250/(waterTarget*1000)).toFloat().coerceIn(0f,1f)},Modifier.fillMaxWidth().padding(vertical=8.dp),color=Green,trackColor=Bg);Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){OutlinedButton(onClick={water=(water-1).coerceAtLeast(0);prefs.edit().putString("water_day",today).putInt("water_glasses",water).apply()}){Text("− 250 ml")};Button(onClick={water++;prefs.edit().putString("water_day",today).putInt("water_glasses",water).apply()},colors=ButtonDefaults.buttonColors(containerColor=Green,contentColor=Bg)){Text("+ 250 ml")}}}}
  item{PanelCard{Text(AppLanguage.text("MUSCLE-GAIN PLATE GUIDE", language),fontWeight=FontWeight.Bold);Text("A simple starting template for a main meal:",color=Muted,fontSize=11.sp);Row(Modifier.fillMaxWidth().padding(vertical=12.dp),horizontalArrangement=Arrangement.spacedBy(6.dp)){Box(Modifier.weight(2f).height(66.dp).background(Color(0xFF426B4E),RoundedCornerShape(10.dp)),contentAlignment=Alignment.Center){Text("½ plate\\nvegetables",color=Color.White,fontSize=11.sp,textAlign=androidx.compose.ui.text.style.TextAlign.Center)};Column(Modifier.weight(2f),verticalArrangement=Arrangement.spacedBy(6.dp)){Box(Modifier.fillMaxWidth().height(30.dp).background(Color(0xFF8C6746),RoundedCornerShape(8.dp)),contentAlignment=Alignment.Center){Text("¼ protein",color=Color.White,fontSize=10.sp)};Box(Modifier.fillMaxWidth().height(30.dp).background(Color(0xFF6B769A),RoundedCornerShape(8.dp)),contentAlignment=Alignment.Center){Text("¼ carbs",color=Color.White,fontSize=10.sp)}}};Text("For muscle gain, include a clear protein source at each meal and add rice/roti portions to meet energy needs. Adjust portions using body-weight trends, not a rigid plate rule.",color=Muted,fontSize=11.sp)}}
  item{PanelCard{Text(AppLanguage.text("WARM-UP SET CALCULATOR", language),fontWeight=FontWeight.Bold);var working by remember{mutableStateOf("60")};Text("Enter your planned working weight (kg). Warm-up sets are not working sets.",color=Muted,fontSize=11.sp);OutlinedTextField(working,{working=it},modifier=Modifier.fillMaxWidth(),singleLine=true,label={Text("Working weight (kg)")});val w=working.toDoubleOrNull()?:0.0;listOf("40%" to .4,"60%" to .6,"75%" to .75,"90%" to .9).forEach{(label,p)->Text("$label · ${"%.1f".format(w*p)} kg × ${if(p<.6)8 else if(p<.75)5 else if(p<.9)3 else 1} reps",Modifier.padding(top=5.dp),color=Green,fontSize=12.sp)};Text("Illustrative ramp-up only. Use fewer sets for light lifts and avoid tiring yourself before work sets.",color=Muted,fontSize=10.sp)}}
  item{Text("Food and hydration values are estimates, not medical or dietetic prescriptions. The diary is stored locally on this phone and resets its daily view at midnight.",color=Muted,fontSize=10.sp)}
 }
}
@Composable private fun ColumnScope.ProfileScreen(weight:String,onWeight:(String)->Unit,logs:List<ExerciseLog>,activity:ComponentActivity,language:String,onLanguageChange:(String)->Unit,onRestore:(List<ExerciseLog>,String)->Unit,onLogsChanged:(List<ExerciseLog>)->Unit){
 val prefs=activity.getSharedPreferences("atif",0)
 var chest by remember{mutableStateOf(prefs.getString("measure_chest","")?:"")}
 var waist by remember{mutableStateOf(prefs.getString("measure_waist","")?:"")}
 var hips by remember{mutableStateOf(prefs.getString("measure_hips","")?:"")}
 var arm by remember{mutableStateOf(prefs.getString("measure_arm","")?:"")}
 var thigh by remember{mutableStateOf(prefs.getString("measure_thigh","")?:"")}
 var photoUri by remember{mutableStateOf(prefs.getString("progress_photo","")?:"")}
 val photoPicker=rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()){uri->
   if(uri!=null){try{activity.contentResolver.takePersistableUriPermission(uri,Intent.FLAG_GRANT_READ_URI_PERMISSION)}catch(_:Exception){};photoUri=uri.toString();prefs.edit().putString("progress_photo",photoUri).apply()}
 }
 var restoreMessage by remember { mutableStateOf("") }
 var editingLog by remember { mutableStateOf<ExerciseLog?>(null) }
 var editWeight by remember { mutableStateOf("") }
 var editReps by remember { mutableStateOf("") }
 var editSetIndex by remember { mutableIntStateOf(0) }
 var pendingDelete by remember { mutableStateOf<ExerciseLog?>(null) }
 var pendingBackupJson by remember { mutableStateOf("") }
 var showRestoreConfirm by remember { mutableStateOf(false) }
 val exportPicker=rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")){uri->
   if(uri!=null){
     try{activity.contentResolver.openOutputStream(uri)?.bufferedWriter()?.use{it.write(pendingBackupJson)} ?: error("Could not write backup file");restoreMessage="Backup exported successfully."}
     catch(e:Exception){restoreMessage="Export failed: ${e.message ?: "Storage error"}"}
   }
 }

 var pendingCsv by remember { mutableStateOf("") }
 val csvPicker=rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/csv")){uri->
   if(uri!=null) {
     try { activity.contentResolver.openOutputStream(uri)?.bufferedWriter()?.use{it.write(pendingCsv)} ?: error("Could not write CSV"); restoreMessage="CSV workout history exported." }
     catch(e:Exception) { restoreMessage="CSV export failed: ${e.message ?: "Storage error"}" }
   }
 }
 val backupPicker=rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()){uri->
   if(uri!=null) {
     try {
       val raw=activity.contentResolver.openInputStream(uri)?.bufferedReader()?.use{it.readText()} ?: error("Could not read backup")
       val root=JSONObject(raw)
       if(root.optString("app")!="ATIF FITNESS") error("This is not an ATIF FITNESS backup")
       val arr=root.optJSONArray("logs") ?: JSONArray()
       val restored=(0 until arr.length()).map { i ->
         val o=arr.getJSONObject(i); val sa=o.optJSONArray("sets")?:JSONArray()
         ExerciseLog(o.optString("day"),o.optString("exercise"),o.optString("date"),
           (0 until sa.length()).map{j->val x=sa.getJSONObject(j);LoggedSet(x.optString("weight"),x.optString("reps"),x.optString("type","Working"),x.optBoolean("done"),x.optString("rpe"))},
           o.optInt("duration"),o.optString("note"))
       }
       val newWeight=root.optString("bodyWeightKg",weight)
       onRestore(restored,newWeight)
       val m=root.optJSONObject("measurementsCm")
       if(m!=null) listOf("chest","waist","hips","arm","thigh").forEach{k->prefs.edit().putString("measure_$k",m.optString(k,"")).apply()}
       root.optString("nutritionDiary","[]").takeIf{it.isNotBlank()}?.let{prefs.edit().putString("food_json",it).putString("food_day",root.optString("nutritionDate","")).apply()}
       prefs.edit().putInt("water_glasses",root.optInt("waterGlasses",0)).apply()
       root.optJSONArray("favorites")?.let { favArr -> saveFavorites(activity, (0 until favArr.length()).map { favArr.optString(it) }.filter { it.isNotBlank() }.toSet()) }
       root.optString("unit","").takeIf { it == "kg" || it == "lb" }?.let { prefs.edit().putString("unit", it).apply() }
       root.optString("trainingMode","").takeIf { it.isNotBlank() }?.let { prefs.edit().putString("training_mode", it).apply() }
       restoreMessage="Backup restored: ${restored.size} exercise records."
     } catch(e:Exception) { restoreMessage="Restore failed: ${e.message ?: "Invalid backup"}" }
   }
 }
 if(editingLog!=null) AlertDialog(
   onDismissRequest={editingLog=null},
   title={Text("Edit workout set")},
   text={Column(verticalArrangement=Arrangement.spacedBy(8.dp)){
     Text("${editingLog!!.exercise} · Set ${editSetIndex+1}")
     OutlinedTextField(editWeight,{editWeight=it},label={Text("Weight (kg)")},singleLine=true)
     OutlinedTextField(editReps,{editReps=it},label={Text(AppLanguage.text("Reps", language))},singleLine=true)
     Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){
       TextButton(onClick={if(editSetIndex>0){editSetIndex--;editWeight=editingLog!!.sets[editSetIndex].weight;editReps=editingLog!!.sets[editSetIndex].reps}}){Text("Previous set")}
       TextButton(onClick={if(editSetIndex<editingLog!!.sets.lastIndex){editSetIndex++;editWeight=editingLog!!.sets[editSetIndex].weight;editReps=editingLog!!.sets[editSetIndex].reps}}){Text("Next set")}
     }
   }},
   confirmButton={TextButton(onClick={
     val current=editingLog!!
     val changed=current.copy(sets=current.sets.toMutableList().also{it[editSetIndex]=it[editSetIndex].copy(weight=editWeight,reps=editReps)})
     onLogsChanged(logs.map{if(it===current || (it.date==current.date && it.day==current.day && it.exercise==current.exercise)) changed else it})
     editingLog=null
   }){Text("Save changes")}},
   dismissButton={TextButton(onClick={editingLog=null}){Text(AppLanguage.text("Cancel", language))}}
 )
 if(pendingDelete!=null) AlertDialog(
   onDismissRequest={pendingDelete=null},
   title={Text(AppLanguage.text("Delete workout record?", language))},
   text={Text("This removes ${pendingDelete!!.exercise} from your workout history. This cannot be undone.")},
   confirmButton={TextButton(onClick={val target=pendingDelete!!;onLogsChanged(logs.filterNot{it.date==target.date && it.day==target.day && it.exercise==target.exercise});pendingDelete=null}){Text(AppLanguage.text("Delete", language))}},
   dismissButton={TextButton(onClick={pendingDelete=null}){Text(AppLanguage.text("Cancel", language))}}
 )
 LazyColumn(Modifier.weight(1f),contentPadding=PaddingValues(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
  item{Header(AppLanguage.text("Profile & body tracking",language),if(language==AppLanguage.UR) "آپ کی تربیت اور جسمانی پیمائش" else if(language==AppLanguage.ROMAN) "Tumhari training aur body measurements" else "Your training settings and physique measurements")}
  item{PanelCard { Text(AppLanguage.text("Language",language),fontWeight=FontWeight.Bold,color=Green); listOf("en" to "English","ur" to "اردو","roman" to "Roman Urdu").forEach{(code,label)->Row(Modifier.fillMaxWidth().clickable{onLanguageChange(code)}.padding(vertical=8.dp),verticalAlignment=Alignment.CenterVertically){RadioButton(selected=language==code,onClick={onLanguageChange(code)});Text(label,Modifier.padding(start=8.dp),fontSize=if(code=="ur")18.sp else 14.sp)}};Text(if(language=="ur")"اردو کے لیے فون میں Urdu TTS voice installed ہونی چاہیے۔" else "Language preference is stored locally on this phone.",color=Muted,fontSize=11.sp)} }
  item{GymToolsAndReadinessCard(activity,weight,language)}
   item {
     PanelCard {
       Text("RECENT WORKOUT HISTORY", fontWeight=FontWeight.Bold)
       if (logs.isEmpty()) Text(AppLanguage.text("No workout logs yet.", language), color=Muted, fontSize=13.sp)
       else logs.sortedByDescending { it.date }.take(12).forEach { record ->
         Column(Modifier.fillMaxWidth().padding(top=9.dp)) {
           Text(record.date, color=Green, fontSize=11.sp, fontWeight=FontWeight.Bold)
           Text("${record.day} · ${record.exercise}", fontWeight=FontWeight.SemiBold, fontSize=14.sp)
           record.sets.forEachIndexed { index, set ->
             Text("Set ${index+1}: ${set.weight} kg × ${set.reps} · ${set.type}${if(set.done) " ✓" else ""}", color=Muted, fontSize=13.sp)
           }
           Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
             TextButton(onClick={editingLog=record;editSetIndex=0;editWeight=record.sets.firstOrNull()?.weight.orEmpty();editReps=record.sets.firstOrNull()?.reps.orEmpty()}) { Text(AppLanguage.text("Edit", language)) }
             TextButton(onClick={pendingDelete=record}) { Text(AppLanguage.text("Delete", language),color=Color(0xFFFF8A80)) }
           }
         }
       }
     }
   }
  item{PanelCard{Text("ATIF · INTERMEDIATE",color=Green,fontWeight=FontWeight.Bold);Text(AppLanguage.text("Muscle gain", language),fontSize=22.sp,fontWeight=FontWeight.Bold);Text(AppLanguage.text("Age 21 · Height 182 cm · Full gym", language),color=Muted,fontSize=12.sp);Text(AppLanguage.text("Current body weight (kg)", language),Modifier.padding(top=12.dp));OutlinedTextField(weight,onWeight,Modifier.fillMaxWidth(),singleLine=true);Text("60–90 minutes · Friday rest",color=Muted,fontSize=12.sp)}}
  item{PanelCard{Text(AppLanguage.text("BODY MEASUREMENTS", language),fontWeight=FontWeight.Bold);Text("Record in centimetres. Recheck under similar conditions every 2–4 weeks.",color=Muted,fontSize=11.sp);val fields=listOf("Chest" to chest,"Waist" to waist,"Hips" to hips,"Arm" to arm,"Thigh" to thigh);fields.forEach{(label,value)->OutlinedTextField(value,{v->when(label){"Chest"->chest=v;"Waist"->waist=v;"Hips"->hips=v;"Arm"->arm=v;"Thigh"->thigh=v};prefs.edit().putString("measure_${label.lowercase()}",v).apply()},modifier=Modifier.fillMaxWidth().padding(top=6.dp),singleLine=true,label={Text("$label (cm)")})};Text(AppLanguage.text("Measurements are saved locally on this phone.", language),color=Muted,fontSize=10.sp)}}
  item{WeightHistoryCard(activity,language)}
  item{PanelCard{Text(AppLanguage.text("PROGRESS PHOTO", language),fontWeight=FontWeight.Bold);Text("Choose a private progress photo from your device. It stays in your selected storage location; this app saves its access reference.",color=Muted,fontSize=11.sp);Button(onClick={photoPicker.launch(arrayOf("image/*"))},modifier=Modifier.fillMaxWidth(),colors=ButtonDefaults.buttonColors(containerColor=Green,contentColor=Bg)){Text(if(photoUri.isBlank())"Choose progress photo" else "Change progress photo")};if(photoUri.isNotBlank()){AndroidView(factory={ctx->ImageView(ctx).apply{adjustViewBounds=true;scaleType=ImageView.ScaleType.FIT_CENTER;setImageURI(Uri.parse(photoUri))}},modifier=Modifier.fillMaxWidth().height(260.dp),update={it.setImageURI(Uri.parse(photoUri))});TextButton(onClick={photoUri="";prefs.edit().remove("progress_photo").apply()}){Text("Remove photo",color=Color(0xFFFF8A80))}}}}
  item{PanelCard{Text(AppLanguage.text("DATA & BACKUP", language),fontWeight=FontWeight.Bold);Text("Export your workout logs and body weight as a portable backup.",Modifier.padding(top=8.dp),color=Muted,fontSize=12.sp);Button(onClick={
      val arr=JSONArray()
      logs.forEach { l -> val sets=JSONArray();l.sets.forEach { x -> sets.put(JSONObject().put("weight",x.weight).put("reps",x.reps).put("type",x.type).put("done",x.done).put("rpe",x.rpe)) };arr.put(JSONObject().put("day",l.day).put("exercise",l.exercise).put("date",l.date).put("sets",sets).put("duration",l.durationSeconds).put("note",l.note)) }
      val backup=JSONObject().put("app","ATIF FITNESS").put("version","3.5.0").put("bodyWeightKg",weight)
        .put("measurementsCm",JSONObject().put("chest",chest).put("waist",waist).put("hips",hips).put("arm",arm).put("thigh",thigh))
        .put("nutritionDate",prefs.getString("food_day","")).put("nutritionDiary",prefs.getString("food_json","[]"))
        .put("waterGlasses",prefs.getInt("water_glasses",0)).put("favorites",JSONArray(loadFavorites(activity).toList())).put("unit",prefs.getString("unit","kg")).put("trainingMode",prefs.getString("training_mode","Normal")).put("logs",arr).toString(2)
      pendingBackupJson=backup
      exportPicker.launch("atif-fitness-backup-${java.text.SimpleDateFormat("yyyyMMdd-HHmm",java.util.Locale.US).format(java.util.Date())}.json")
    },modifier=Modifier.fillMaxWidth().heightIn(min=56.dp),colors=ButtonDefaults.buttonColors(containerColor=Green,contentColor=Bg)){Text(AppLanguage.text("Export workout backup", language))}

    OutlinedButton(onClick={
      fun q(v:String)="\""+v.replace("\"","\"\"")+"\""
      val rows=mutableListOf("date,day,exercise,set,weight_kg,reps,set_type,completed,rpe,duration_seconds,note")
      logs.sortedBy{it.date}.forEach{l->l.sets.forEachIndexed{i,x->
        rows.add(listOf(q(l.date),q(l.day),q(l.exercise),(i+1).toString(),q(x.weight),q(x.reps),q(x.type),x.done.toString(),q(x.rpe),l.durationSeconds.toString(),q(l.note)).joinToString(","))
      }}
      pendingCsv=rows.joinToString("\n")
      csvPicker.launch("atif-fitness-workout-history.csv")
    },modifier=Modifier.fillMaxWidth().heightIn(min=54.dp)){Text(AppLanguage.text("Export workout history (CSV)", language))}
    OutlinedButton(onClick={showRestoreConfirm=true},modifier=Modifier.fillMaxWidth().heightIn(min=54.dp)){Text(AppLanguage.text("Restore from backup", language))}
    if(showRestoreConfirm) AlertDialog(
      onDismissRequest={showRestoreConfirm=false},
      title={Text(AppLanguage.text("Replace current workout history?", language))},
      text={Text("Restore replaces the current workout records. First export a backup of this phone's data. Continue only after saving that JSON file.")},
      confirmButton={TextButton(onClick={showRestoreConfirm=false;backupPicker.launch(arrayOf("application/json","text/plain"))}){Text(AppLanguage.text("Continue to restore", language))}},
      dismissButton={TextButton(onClick={showRestoreConfirm=false}){Text(AppLanguage.text("Cancel", language))}}
    )
    if(restoreMessage.isNotBlank()) Text(restoreMessage,color=if(restoreMessage.startsWith("Backup restored"))Green else Color(0xFFFF8A80),fontSize=11.sp)
    Text(AppLanguage.text("Export and restore are manual. Import replaces current workout history.", language),color=Muted,fontSize=10.sp)}}
 }
}
private fun loadCompleted(a:ComponentActivity):Set<String> = try{JSONArray(a.getSharedPreferences("atif",0).getString("done","[]")).let{arr->(0 until arr.length()).map{arr.getString(it)}.toSet()}}catch(_:Exception){emptySet()}
private fun saveCompleted(a:ComponentActivity,s:Set<String>){a.getSharedPreferences("atif",0).edit().putString("done",JSONArray(s.toList()).toString()).apply()}
