# ATIF FITNESS — Native Android starter project

This is an Android Studio project written in Kotlin + Jetpack Compose. It is not a website and does not use Lovable.

## Included in this starter build
- Native Android UI with Home, Workout, Progress, Nutrition and Profile tabs
- Saturday–Thursday PPL × 2 workout plan; Friday rest day
- Exercise-specific sets, rep ranges, coaching cues, breathing cues and common mistakes
- Exercise video search shortcut (opens YouTube search for the exact exercise)
- Animated movement cue panel (generic visual cue, not a biomechanically exact exercise animation)
- Set logging UI and rest timer
- Local persistence for exercise completion check-offs
- Dark theme and user profile defaults (21 years, 78 kg, 182 cm)

## Important limitations
- This is a starter project, not a finished production APK.
- The animation is a generic movement cue. It must not be treated as an accurate demonstration of each exercise.
- Video button opens a YouTube search, not a bundled/licensed video.
- Camera-based form checking, pose estimation, cloud backup/login, permanent set-by-set history, meal database, progress photos and production QA are not implemented yet.

## Build APK
1. Install Android Studio (Ladybug or newer) on a computer.
2. Open this folder as an existing project.
3. Allow Gradle sync and install Android SDK Platform 35 if prompted.
4. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Debug APK output: `app/build/outputs/apk/debug/app-debug.apk`.

Package: `com.atif.fitness`  
Minimum Android: 8.0 (API 26)
