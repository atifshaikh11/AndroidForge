package com.atif.fitness

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray
import org.json.JSONObject

private val Bg = Color(0xFF101411)
private val Panel = Color(0xFF1A211D)
private val Green = Color(0xFF75E0A0)
private val Muted = Color(0xFF9AA79F)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AtifFitnessApp(this) }
    }
}

data class Exercise(
    val name: String, val muscle: String, val sets: Int, val reps: String,
    val cues: List<String>, val mistakes: List<String>, val breathing: String,
    val equipment: String, val videoQuery: String
)
data class DayPlan(val day: String, val title: String, val tag: String, val exercises: List<Exercise>)

private fun ex(n:String,m:String,s:Int,r:String,e:String,c:List<String>,mist:List<String>,b:String)=Exercise(n,m,s,r,c,mist,b,e,n+" correct form tutorial")
private val plans = listOf(
 DayPlan("Saturday","Chest + Triceps","PUSH A", listOf(
  ex("Barbell Bench Press","Chest · Triceps · Front delts",3,"6–10","Barbell + bench", listOf("Feet planted; shoulder blades pulled back","Lower bar under control to mid-chest","Press up without bouncing the bar"), listOf("Bouncing bar off chest","Excessive lower-back arch","Wrists folded backwards"),"Inhale while lowering; exhale while pressing."),
  ex("Incline Dumbbell Press","Upper chest · Triceps",2,"8–12","Incline bench + dumbbells", listOf("Set bench to a moderate incline","Lower dumbbells beside upper chest","Press up while keeping wrists stacked"), listOf("Bench too steep","Dumbbells crashing together"),"Inhale down; exhale up."),
  ex("Cable Chest Fly","Chest",2,"12–15","Cable machine", listOf("Slight bend in elbows","Bring hands together in a wide arc","Return slowly until chest stretches"), listOf("Turning it into a press","Using momentum"),"Exhale as hands come together."),
  ex("Rope Triceps Pushdown","Triceps",2,"10–12","Cable + rope", listOf("Keep elbows near your sides","Extend elbows until arms are straight","Separate rope ends slightly at bottom"), listOf("Swinging shoulders","Elbows drifting forward"),"Exhale while extending."),
  ex("Overhead Cable Extension","Triceps long head",2,"10–15","Cable + rope", listOf("Face away from cable","Keep upper arms steady overhead","Extend elbows without arching back"), listOf("Flaring ribs","Moving upper arms excessively"),"Exhale on extension."))),
 DayPlan("Sunday","Back + Biceps","PULL A", listOf(
  ex("Lat Pulldown","Lats · Biceps",3,"8–12","Lat pulldown machine", listOf("Grip slightly wider than shoulders","Pull bar toward upper chest","Control the return overhead"), listOf("Pulling behind neck","Rocking torso to move weight"),"Exhale while pulling down."),
  ex("Chest Supported Row","Mid back · Lats",3,"8–12","Chest-supported row", listOf("Keep chest against pad","Drive elbows back","Pause briefly; lower slowly"), listOf("Lifting chest off pad","Shrugging shoulders"),"Exhale while rowing."),
  ex("Single Arm Cable Row","Lats · Mid back",2,"10–12","Cable machine", listOf("Brace torso","Pull elbow toward hip","Allow controlled reach forward"), listOf("Rotating torso","Using momentum"),"Exhale on pull."),
  ex("Reverse Pec Deck","Rear delts",2,"12–15","Pec deck", listOf("Set handles around shoulder height","Open arms with soft elbows","Stop without shrugging"), listOf("Overarching lower back","Shrugging"),"Exhale as arms open."),
  ex("EZ Bar Curl","Biceps",3,"8–12","EZ bar", listOf("Keep elbows close to torso","Curl without swinging","Lower fully under control"), listOf("Swinging body","Elbows moving forward"),"Exhale while curling."),
  ex("Incline Dumbbell Curl","Biceps long head",2,"10–12","Incline bench + dumbbells", listOf("Keep upper back on bench","Let arms hang naturally","Curl without moving elbows forward"), listOf("Using momentum","Shortening the bottom range"),"Exhale while curling."))),
 DayPlan("Monday","Shoulders + Legs","LEGS A", listOf(
  ex("Dumbbell Shoulder Press","Deltoids · Triceps",2,"8–12","Dumbbells + bench", listOf("Brace core and keep ribs down","Press overhead in a comfortable path","Lower to shoulder level"), listOf("Overarching back","Pressing through painful range"),"Exhale while pressing."),
  ex("Dumbbell Lateral Raise","Side delts",3,"12–15","Dumbbells", listOf("Soft elbows and slight forward lean","Raise arms out to sides","Stop around shoulder height"), listOf("Swinging weights","Shrugging up"),"Exhale while raising."),
  ex("Barbell Squat","Quads · Glutes",3,"6–10","Barbell + rack", listOf("Brace abdomen before descent","Keep whole foot planted","Descend as far as control and mobility allow","Drive up through mid-foot"), listOf("Heels lifting","Knees collapsing inward","Losing trunk brace"),"Inhale and brace down; exhale through the ascent."),
  ex("Leg Press","Quads · Glutes",2,"10–12","Leg press", listOf("Feet about shoulder width","Lower sled with pelvis supported","Press without locking knees hard"), listOf("Lower back rounding","Knees collapsing inward"),"Inhale down; exhale up."),
  ex("Lying Leg Curl","Hamstrings",3,"10–15","Leg curl machine", listOf("Align knees with machine pivot","Curl heels toward glutes","Lower slowly"), listOf("Hips lifting","Dropping weight quickly"),"Exhale while curling."),
  ex("Standing Calf Raise","Calves",3,"12–15","Calf raise machine", listOf("Use full comfortable range","Pause in stretched bottom position","Rise onto balls of feet"), listOf("Bouncing","Tiny partial reps"),"Exhale while rising."))),
 DayPlan("Tuesday","Chest + Triceps","PUSH B", listOf(
  ex("Incline Smith Machine Press","Upper chest · Triceps",3,"8–12","Smith machine + incline bench", listOf("Set bench under bar path","Lower toward upper chest","Press smoothly without bouncing"), listOf("Bench too far forward/back","Bouncing off chest"),"Inhale down; exhale up."),
  ex("Flat Machine Chest Press","Chest · Triceps",2,"10–12","Chest press machine", listOf("Adjust handles around mid-chest","Keep shoulder blades supported","Press and return slowly"), listOf("Shoulders rolling forward","Locking elbows aggressively"),"Exhale while pressing."),
  ex("Pec Deck Fly","Chest",2,"12–15","Pec deck machine", listOf("Set elbows/handles comfortably","Bring arms together in a controlled arc","Return until chest stretches"), listOf("Excessive stretch","Using momentum"),"Exhale while closing."),
  ex("Straight Bar Triceps Pushdown","Triceps",2,"10–12","Cable + straight bar", listOf("Pin elbows beside torso","Extend elbows fully","Return slowly"), listOf("Leaning bodyweight onto bar","Elbows moving"),"Exhale while extending."),
  ex("Overhead Rope Extension","Triceps long head",2,"12–15","Cable + rope", listOf("Keep upper arms pointing forward/up","Bend elbows for a controlled stretch","Extend without arching back"), listOf("Flaring ribs","Moving shoulders"),"Exhale on extension."))),
 DayPlan("Wednesday","Back + Biceps","PULL B", listOf(
  ex("Pull-ups / Assisted Pull-ups","Lats · Biceps",3,"8–12","Pull-up bar / assisted machine", listOf("Start from controlled hang","Pull chest toward bar","Lower without dropping"), listOf("Kipping or swinging","Half reps"),"Exhale while pulling."),
  ex("T-Bar Row","Mid back · Lats",3,"8–12","T-bar row machine", listOf("Brace torso and maintain neutral spine","Pull handle toward lower chest","Lower with control"), listOf("Rounding back","Jerking torso"),"Exhale while rowing."),
  ex("Straight Arm Pulldown","Lats",2,"12–15","Cable + straight bar", listOf("Keep elbows softly bent","Pull bar toward thighs","Control return overhead"), listOf("Bending elbows into a triceps pushdown","Leaning excessively"),"Exhale while pulling down."),
  ex("Cable Rear Delt Fly","Rear delts",2,"12–15","Cable machine", listOf("Use crossed cables if comfortable","Move arms outward","Keep traps relaxed"), listOf("Shrugging","Swinging"),"Exhale while opening."),
  ex("Hammer Curl","Brachialis · Biceps · Forearms",3,"10–12","Dumbbells", listOf("Keep palms facing each other","Curl without swinging","Lower slowly"), listOf("Body swing","Wrists bending"),"Exhale while curling."),
  ex("Preacher Curl","Biceps",2,"10–12","Preacher bench + EZ bar", listOf("Keep upper arms on pad","Curl through comfortable range","Lower without snapping elbow straight"), listOf("Lifting elbows off pad","Dropping into bottom"),"Exhale while curling."))),
 DayPlan("Thursday","Legs + Shoulders","LEGS B", listOf(
  ex("Machine Shoulder Press","Deltoids · Triceps",2,"8–12","Shoulder press machine", listOf("Adjust seat so handles start near shoulders","Brace back against pad","Press overhead smoothly"), listOf("Overarching back","Shrugging"),"Exhale while pressing."),
  ex("Cable Lateral Raise","Side delts",3,"12–15","Cable machine", listOf("Stand side-on to low pulley","Raise arm out to side","Lower slowly"), listOf("Torso swinging","Shrugging"),"Exhale while raising."),
  ex("Romanian Deadlift","Hamstrings · Glutes",3,"8–10","Barbell / dumbbells", listOf("Soften knees and brace core","Push hips backward; keep weight close","Stop when hamstrings limit the hinge","Stand by driving hips forward"), listOf("Squatting instead of hinging","Rounding lower back","Weight drifting away"),"Inhale and brace on descent; exhale as you stand."),
  ex("Bulgarian Split Squat","Quads · Glutes",2,"10 each leg","Bench + dumbbells", listOf("Set rear foot on stable bench","Descend under control","Keep front foot fully planted"), listOf("Front heel lifting","Losing balance due to rushed reps"),"Inhale down; exhale up."),
  ex("Leg Extension","Quadriceps",2,"12–15","Leg extension machine", listOf("Align knee with machine pivot","Extend legs smoothly","Lower without letting stack slam"), listOf("Kicking explosively","Poor machine alignment"),"Exhale while extending."),
  ex("Seated Leg Curl","Hamstrings",2,"10–15","Seated leg curl machine", listOf("Set thigh pad securely","Curl heels down/back","Return slowly"), listOf("Lifting hips","Rushing eccentric"),"Exhale while curling."),
  ex("Seated Calf Raise","Soleus · Calves",3,"12–15","Seated calf machine", listOf("Place forefoot on platform","Lower heels for a controlled stretch","Raise heels and pause"), listOf("Bouncing","Partial range"),"Exhale while raising.")))
)

@Composable fun AtifFitnessApp(activity: ComponentActivity) {
    var tab by remember { mutableStateOf("Home") }
    var selectedDay by remember { mutableStateOf(plans[0]) }
    var selectedExercise by remember { mutableStateOf<Exercise?>(null) }
    var completed by remember { mutableStateOf(loadCompleted(activity)) }
    var weight by remember { mutableStateOf("78") }
    var totalSessions by remember { mutableIntStateOf(0) }
    MaterialTheme(colorScheme = darkColorScheme(primary=Green, background=Bg, surface=Panel, onBackground=Color.White, onSurface=Color.White)) {
      Surface(Modifier.fillMaxSize(), color=Bg) {
        Column {
          Row(Modifier.fillMaxWidth().padding(horizontal=20.dp, vertical=16.dp), verticalAlignment=Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) { Text("ATIF FITNESS", color=Green, fontWeight=FontWeight.ExtraBold, fontSize=20.sp); Text("YOUR PERSONAL TRAINING COMPANION", color=Muted, fontSize=9.sp, letterSpacing=1.sp) }
            Icon(Icons.Default.FitnessCenter, null, tint=Green)
          }
          if (selectedExercise != null) ExerciseDetail(selectedExercise!!, { selectedExercise=null }, activity, completed, { id -> completed=completed+(selectedDay.day+id); saveCompleted(activity,completed) })
          else when(tab) {
            "Home" -> HomeScreen(completed, { day -> selectedDay=day; tab="Workout" }, weight, {weight=it})
            "Workout" -> WorkoutScreen(selectedDay, {selectedDay=it}, completed, { selectedExercise=it }, { id -> completed=completed+id; saveCompleted(activity,completed) })
            "Progress" -> ProgressScreen(completed)
            "Nutrition" -> NutritionScreen()
            else -> ProfileScreen(weight, {weight=it})
          }
          NavigationBar(containerColor=Panel, contentColor=Green) {
            listOf("Home","Workout","Progress","Nutrition","Profile").forEach { item ->
              NavigationBarItem(selected=tab==item, onClick={tab=item;selectedExercise=null}, icon={ Icon(when(item){"Home"->Icons.Default.Home;"Workout"->Icons.Default.FitnessCenter;"Progress"->Icons.Default.Insights;"Nutrition"->Icons.Default.Restaurant;else->Icons.Default.Person},null) }, label={Text(item,fontSize=10.sp)}, colors=NavigationBarItemDefaults.colors(selectedIconColor=Green, selectedTextColor=Green, indicatorColor=Green.copy(alpha=.12f), unselectedIconColor=Muted, unselectedTextColor=Muted))
            }
          }
        }
      }
    }
}

@Composable private fun Header(title:String, sub:String="") { Column(Modifier.padding(horizontal=18.dp, vertical=8.dp)) { Text(title,fontSize=23.sp,fontWeight=FontWeight.Bold); if(sub.isNotBlank()) Text(sub,color=Muted,fontSize=12.sp) } }
@Composable private fun PanelCard(content:@Composable ColumnScope.()->Unit) { Card(Modifier.fillMaxWidth(), colors=CardDefaults.cardColors(containerColor=Panel), shape=RoundedCornerShape(18.dp)) { Column(Modifier.padding(16.dp), content=content) } }

@Composable private fun ColumnScope.HomeScreen(done:Set<String>, open:(DayPlan)->Unit, weight:String, onWeight:(String)->Unit) {
 LazyColumn(Modifier.weight(1f), contentPadding=PaddingValues(16.dp), verticalArrangement=Arrangement.spacedBy(12.dp)) {
  item { Text("YOUR FITNESS DASHBOARD",color=Green,fontSize=10.sp,fontWeight=FontWeight.Bold,letterSpacing=1.5.sp); Text("Build muscle. Track progress.",fontSize=24.sp,fontWeight=FontWeight.Bold); Text("Intermediate · Muscle gain · 6 days/week",color=Muted,fontSize=12.sp) }
  item { Row(horizontalArrangement=Arrangement.spacedBy(10.dp)) { StatCard("WEIGHT", "$weight kg", Modifier.weight(1f)); StatCard("BMI", "23.5", Modifier.weight(1f)); StatCard("SPLIT", "PPL × 2", Modifier.weight(1f)) } }
  item { PanelCard { Text("TODAY'S TRAINING",color=Green,fontSize=10.sp,fontWeight=FontWeight.Bold); val today=plans.first(); Text(today.title,fontSize=20.sp,fontWeight=FontWeight.Bold); Text("${today.exercises.size} exercises · 60–90 min target",color=Muted,fontSize=12.sp); Button(onClick={open(today)}, modifier=Modifier.fillMaxWidth(), colors=ButtonDefaults.buttonColors(containerColor=Green,contentColor=Bg)) { Text("Open workout") } } }
  item { Text("WEEKLY PLAN",fontWeight=FontWeight.Bold,fontSize=17.sp) }
  items(plans) { day -> DayCard(day, done, {open(day)}) }
  item { PanelCard { Text("FRIDAY · REST & RECOVERY",color=Green,fontWeight=FontWeight.Bold); Text("Light walk, adequate food, hydration and 7–9 hours of sleep.",color=Muted,fontSize=13.sp) } }
 }
}
@Composable private fun StatCard(label:String,value:String,modifier:Modifier=Modifier) { Card(modifier,colors=CardDefaults.cardColors(containerColor=Panel),shape=RoundedCornerShape(16.dp)) { Column(Modifier.padding(12.dp)) { Text(label,color=Muted,fontSize=9.sp); Text(value,fontWeight=FontWeight.Bold,fontSize=17.sp) } } }
@Composable private fun DayCard(day:DayPlan,done:Set<String>,click:()->Unit) { val count=day.exercises.count{done.contains(day.day+it.name)}; Card(Modifier.fillMaxWidth().clickable(onClick=click),colors=CardDefaults.cardColors(containerColor=Panel),shape=RoundedCornerShape(15.dp)) { Row(Modifier.padding(14.dp),verticalAlignment=Alignment.CenterVertically) { Column(Modifier.weight(1f)) { Text(day.day.uppercase(),color=Green,fontSize=10.sp,fontWeight=FontWeight.Bold); Text(day.title,fontWeight=FontWeight.SemiBold); Text(day.tag+" · ${day.exercises.size} exercises",color=Muted,fontSize=11.sp) }; Text("$count/${day.exercises.size}",color=Green,fontWeight=FontWeight.Bold); Icon(Icons.Default.ChevronRight,null,tint=Muted) } } }

@Composable private fun ColumnScope.WorkoutScreen(day:DayPlan,onDay:(DayPlan)->Unit,done:Set<String>,open:(Exercise)->Unit,mark:(String)->Unit) {
 Column(Modifier.weight(1f)) { Header("Workout plan","Your six-day PPL × 2 program")
  Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal=14.dp),horizontalArrangement=Arrangement.spacedBy(8.dp)) { plans.forEach { p -> FilterChip(selected=p==day,onClick={onDay(p)},label={Text(p.day.take(3))}, colors=FilterChipDefaults.filterChipColors(selectedContainerColor=Green,selectedLabelColor=Bg)) } }
  LazyColumn(Modifier.weight(1f),contentPadding=PaddingValues(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)) {
   item { PanelCard { Text(day.tag,color=Green,fontWeight=FontWeight.Bold,fontSize=10.sp); Text(day.title,fontSize=22.sp,fontWeight=FontWeight.Bold); Text("60–90 minute target · Warm up before working sets",color=Muted,fontSize=12.sp) } }
   items(day.exercises) { e -> val isDone=done.contains(day.day+e.name); Card(Modifier.fillMaxWidth().clickable{open(e)},colors=CardDefaults.cardColors(containerColor=Panel),shape=RoundedCornerShape(15.dp)) { Row(Modifier.padding(14.dp),verticalAlignment=Alignment.CenterVertically) { Column(Modifier.weight(1f)) { Text(e.name,fontWeight=FontWeight.Bold); Text(e.muscle,color=Muted,fontSize=11.sp); Text("${e.sets} sets · ${e.reps} reps",color=Green,fontSize=12.sp) }; Checkbox(isDone,{if(it)mark(day.day+e.name)},colors=CheckboxDefaults.colors(checkedColor=Green)); Icon(Icons.Default.ChevronRight,null,tint=Muted) } } }
   item { Text("Rest: 2–3 min for compound lifts; 60–120 sec for isolation work. Keep most sets 1–3 reps in reserve.",color=Muted,fontSize=12.sp) }
  }
 }
}

@Composable private fun ColumnScope.ExerciseDetail(e:Exercise,onBack:()->Unit,activity:ComponentActivity,done:Set<String>,mark:(String)->Unit) {
 var setWeights by remember { mutableStateOf(List(e.sets){""}) }; var setReps by remember { mutableStateOf(List(e.sets){e.reps.substringBefore("–")}) }; var checked by remember { mutableStateOf(List(e.sets){false}) }
 var seconds by remember { mutableIntStateOf(90) }; var running by remember { mutableStateOf(false) }
 LaunchedEffect(running) { while(running && seconds>0) { kotlinx.coroutines.delay(1000); seconds-- }; if(seconds==0) running=false }
 Column(Modifier.weight(1f)) {
  Row(Modifier.fillMaxWidth().clickable{onBack()}.padding(16.dp),verticalAlignment=Alignment.CenterVertically) { Icon(Icons.Default.ArrowBack,null,tint=Green); Text("  Exercise guide",fontWeight=FontWeight.Bold) }
  LazyColumn(Modifier.weight(1f),contentPadding=PaddingValues(horizontal=16.dp, vertical=4.dp),verticalArrangement=Arrangement.spacedBy(12.dp)) {
   item { PanelCard { Text(e.muscle.uppercase(),color=Green,fontSize=10.sp,fontWeight=FontWeight.Bold); Text(e.name,fontSize=23.sp,fontWeight=FontWeight.Bold); Text("${e.sets} working sets · ${e.reps} reps · ${e.equipment}",color=Muted,fontSize=12.sp) } }
   item { AnimationCard() }
   item { PanelCard { Text("HOW TO PERFORM",fontWeight=FontWeight.Bold); e.cues.forEachIndexed{i,s-> Text("${i+1}. $s",Modifier.padding(top=8.dp),fontSize=13.sp)}; Spacer(Modifier.height(10.dp)); Text("BREATHING",color=Green,fontWeight=FontWeight.Bold,fontSize=11.sp); Text(e.breathing,fontSize=13.sp) } }
   item { PanelCard { Text("COMMON MISTAKES",fontWeight=FontWeight.Bold); e.mistakes.forEach { Text("• $it",Modifier.padding(top=7.dp),color=Muted,fontSize=13.sp) } } }
   item { Button(onClick={ val url="https://www.youtube.com/results?search_query="+Uri.encode(e.videoQuery); activity.startActivity(Intent(Intent.ACTION_VIEW,Uri.parse(url))) },modifier=Modifier.fillMaxWidth(),colors=ButtonDefaults.buttonColors(containerColor=Green,contentColor=Bg)) { Icon(Icons.Default.PlayCircle,null); Text("  Watch exercise video") } }
   item { PanelCard { Text("LOG YOUR SETS",fontWeight=FontWeight.Bold); Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween) { Text("SET",color=Muted,fontSize=10.sp); Text("WEIGHT (KG)",color=Muted,fontSize=10.sp); Text("REPS",color=Muted,fontSize=10.sp); Text("DONE",color=Muted,fontSize=10.sp) }; repeat(e.sets) { i -> Row(verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.spacedBy(6.dp)) { Text("${i+1}",Modifier.width(24.dp)); OutlinedTextField(setWeights[i],{v->setWeights=setWeights.toMutableList().also{it[i]=v}},Modifier.weight(1f),singleLine=true,label={Text("kg")}); OutlinedTextField(setReps[i],{v->setReps=setReps.toMutableList().also{it[i]=v}},Modifier.weight(1f),singleLine=true,label={Text("reps")}); Checkbox(checked[i],{v->checked=checked.toMutableList().also{it[i]=v}}) } } } }
   item { PanelCard { Text("REST TIMER",fontWeight=FontWeight.Bold); Text("${seconds/60}:${(seconds%60).toString().padStart(2,'0')}",fontSize=32.sp,fontWeight=FontWeight.Bold,color=Green); Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) { Button(onClick={seconds=90;running=false},colors=ButtonDefaults.buttonColors(containerColor=Panel)){Text("Reset")}; Button(onClick={running=!running},colors=ButtonDefaults.buttonColors(containerColor=Green,contentColor=Bg)){Text(if(running)"Pause" else "Start")}; OutlinedButton(onClick={seconds+=30}){Text("+30s")} } } }
   item { Button(onClick={mark(e.name);onBack()},modifier=Modifier.fillMaxWidth(),colors=ButtonDefaults.buttonColors(containerColor=Green,contentColor=Bg)){Text("Mark exercise complete")} }
  }
 }
}

@Composable private fun AnimationCard() {
 val transition= rememberInfiniteTransition(label="rep")
 val angle by transition.animateFloat(initialValue=-24f,targetValue=24f,animationSpec=infiniteRepeatable(tween(950,easing=FastOutSlowInEasing),RepeatMode.Reverse),label="arm")
 PanelCard {
  Row(verticalAlignment=Alignment.CenterVertically) { Text("MOVEMENT PREVIEW",fontWeight=FontWeight.Bold,fontSize=11.sp); Spacer(Modifier.weight(1f)); Text("LOOP",color=Green,fontSize=10.sp) }
  Box(Modifier.fillMaxWidth().height(142.dp).background(Color(0xFF111A14),RoundedCornerShape(14.dp)),contentAlignment=Alignment.Center) {
   Column(horizontalAlignment=Alignment.CenterHorizontally) {
    Box(Modifier.size(24.dp).background(Green,CircleShape))
    Box(Modifier.padding(top=3.dp).width(8.dp).height(48.dp).background(Green,RoundedCornerShape(5.dp)))
    Row(verticalAlignment=Alignment.CenterVertically) {
     Box(Modifier.width(43.dp).height(7.dp).rotate(angle).background(Green,RoundedCornerShape(5.dp)))
     Box(Modifier.width(43.dp).height(7.dp).rotate(-angle).background(Green,RoundedCornerShape(5.dp)))
    }
   }
  }
  Text("Animated movement cue only. Follow the written exercise-specific instructions and watch the demonstration video for the full technique.",color=Muted,fontSize=11.sp)
 }
}

@Composable private fun ColumnScope.ProgressScreen(done:Set<String>) { val total=plans.sumOf{it.exercises.size}; val pct=if(total==0)0 else done.size*100/total; LazyColumn(Modifier.weight(1f),contentPadding=PaddingValues(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)) { item{Header("Progress","Track consistency and training volume")}; item{PanelCard{Text("THIS WEEK",color=Green,fontWeight=FontWeight.Bold);Text("${done.size} / $total exercises logged",fontSize=22.sp,fontWeight=FontWeight.Bold); LinearProgressIndicator(progress={pct/100f},modifier=Modifier.fillMaxWidth().padding(vertical=10.dp),color=Green,trackColor=Bg);Text("$pct% of planned exercise check-offs",color=Muted,fontSize=12.sp)}}; item{PanelCard{Text("TRAINING PRINCIPLES",fontWeight=FontWeight.Bold);Text("• Record working-set weight and reps.\n• Increase load only when all sets reach the top of the rep range with good form.\n• Review weekly body-weight averages, not single-day changes.\n• Reduce volume if performance and recovery consistently decline.",Modifier.padding(top=8.dp),fontSize=13.sp)}} } }
@Composable private fun ColumnScope.NutritionScreen() { var protein by remember{mutableStateOf("150")}; var water by remember{mutableStateOf("2.5")}; LazyColumn(Modifier.weight(1f),contentPadding=PaddingValues(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){item{Header("Nutrition","Initial muscle-gain targets")};item{PanelCard{Text("PROTEIN TARGET",color=Green,fontWeight=FontWeight.Bold);Text("140–160 g / day",fontSize=23.sp,fontWeight=FontWeight.Bold);Text("A practical range for 78 kg body weight.",color=Muted,fontSize=12.sp)}};item{PanelCard{Text("DAILY TRACKER",fontWeight=FontWeight.Bold);Text("Protein consumed (g)",Modifier.padding(top=10.dp),color=Muted);OutlinedTextField(protein,{protein=it},modifier=Modifier.fillMaxWidth());Text("Water consumed (L)",Modifier.padding(top=8.dp),color=Muted);OutlinedTextField(water,{water=it},modifier=Modifier.fillMaxWidth());Text("Calorie target: set after estimating maintenance from activity and food intake.",Modifier.padding(top=8.dp),color=Muted,fontSize=11.sp)}};item{Text("Nutrition values are user-entered in this starter build; persistent meal logging and food database are planned for the next development stage.",color=Muted,fontSize=11.sp)}} }
@Composable private fun ColumnScope.ProfileScreen(weight:String,onWeight:(String)->Unit) { LazyColumn(Modifier.weight(1f),contentPadding=PaddingValues(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){item{Header("Profile","Your training settings")};item{PanelCard{Text("ATIF · INTERMEDIATE",color=Green,fontWeight=FontWeight.Bold);Text("Muscle gain",fontSize=22.sp,fontWeight=FontWeight.Bold);Text("Age 21 · Height 182 cm · Weight 78 kg",color=Muted,fontSize=12.sp);Text("Update current weight (kg)",Modifier.padding(top=12.dp));OutlinedTextField(weight,onWeight,modifier=Modifier.fillMaxWidth());Text("Full gym · 60–90 minutes · Friday rest",color=Muted,fontSize=12.sp)}};item{PanelCard{Text("APP NOTES",fontWeight=FontWeight.Bold);Text("This starter version stores exercise check-offs locally on this device. Cloud sync, camera-based pose estimation, body measurements, photo history and fully offline exercise videos need additional implementation.",Modifier.padding(top=8.dp),color=Muted,fontSize=12.sp)}}} }

private fun loadCompleted(a:ComponentActivity):Set<String> = try { JSONArray(a.getSharedPreferences("atif",0).getString("done","[]")).let{arr->(0 until arr.length()).map{arr.getString(it)}.toSet()} } catch(_:Exception){ emptySet() }
private fun saveCompleted(a:ComponentActivity,s:Set<String>) { a.getSharedPreferences("atif",0).edit().putString("done",JSONArray(s.toList()).toString()).apply() }
